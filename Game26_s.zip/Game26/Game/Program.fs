﻿open System
open System.Windows.Forms
open System.Drawing
open Main
open MyGraphics
open MyInput

let gettime() = (float)System.Environment.TickCount
let mutable realfps = 0
let mutable now = gettime()
let mutable nextsecond = gettime()
let mutable nextframe = gettime()
let fps = 30.0
let wait = 1000. / fps

let form = new Form()
form.ClientSize <- new Size(320, 240)
let g = new MyGraphics(form)
let key = new MyInput(form)
form.Show()

//ｹﾞｰﾑループ
while form.Created do
    now <- gettime()
    if now > nextframe then
        nextframe <- nextframe + wait
        if now < nextframe then
            realfps <- realfps + 1
            key.setKey()
            key.setMouse()
            update(g,key)
            g.render()
    if now > nextsecond then
        nextsecond <- nextsecond + 1000.0
        form.Text <- "FPS:" + (realfps.ToString())
        realfps <- 0
    Threading.Thread.Sleep(10)
    Application.DoEvents()

(*

//ゲームループ(元)
while form.Created do
    now <- gettime()
    if now < nextframe then update (form)
    else(
        nextframe <- nextframe + wait
        if now < nextframe then
            (
            realfps <- realfps + 1
            draw (g);
            )
        )
    if now < nextsecond then () else
    (
        nextsecond <- nextsecond + 1000.;
        form.Text <- "FPS:" + (realfps.ToString())
        realfps <- 0;
    )
    Application.DoEvents()
done
*)
