﻿//グラフィックス関連モジュール
module MyGraphics
open System.Windows.Forms
open System.Drawing

type MyGraphics(form:Form) =
    
    let currentContext = BufferedGraphicsManager.Current 
    let myBuffer = currentContext.Allocate(form.CreateGraphics(),form.DisplayRectangle)
    let g = myBuffer.Graphics
    let mutable color = Color.White
    let mutable fontSize = 12
    let brush = new SolidBrush(color)
    let fontM = new Font("ＭＳ ゴシック", float32(12), FontStyle.Bold)
    let fontS = new Font("ＭＳ ゴシック", float32(8))

    member u.render() = myBuffer.Render()
    member u.clear(c) = g.Clear(c)

    member u.setColor c = color <- c
    member u.setRgb r g b = color <- Color.FromArgb(r,g,b)

    //文字列表示
    member u.dStr x y str =
        brush.Color <- color
        g.DrawString(str.ToString(), fontM , brush, float32(x), float32(y))

    //小さめ文字test
    member u.dStrS x y str =
        brush.Color <- color
        g.DrawString(str.ToString(), fontS, brush, float32(x), float32(y))

    //矩形表示
    member u.dRect x y w h =
        g.DrawRectangle(new Pen(color), float32(x), float32(y), float32(w-1), float32(h-1))

    //矩形表示(塗りつぶし)
    member u.fRect x y w h =
        g.FillRectangle(new SolidBrush(color), float32(x), float32(y), float32(w), float32(h))

    //正方形表示
    member u.dBox x y size = u.dRect x y size size

    //正方形表示(塗りつぶし)
    member u.fBox x y size = u.fRect x y size size

    //直線描画
    member u.dLine (x1:int) y1 x2 y2 =
        g.DrawLine( new Pen(color), x1, y1, x2, y2 )

    //多角形描画
    member u.dPoly (a:(int*int)List) =
        let p = Array.init a.Length ( fun i ->
            let (x,y) = a.[i]
            new Point( x,y ) )
        g.DrawPolygon(new Pen(color),p)

    //多角形描画(塗りつぶし)
    member u.fPoly (a:(int*int)List) =
        let p = Array.init a.Length ( fun i ->
            let (x,y) = a.[i]
            new Point( x,y ) )
        g.FillPolygon(new SolidBrush(color),p)