﻿//ゲームのメインの処理
module Main

open System
open System.Drawing
open System.Windows.Forms
open System.Collections.Generic
open System.IO
open System.Diagnostics

open MyGraphics; open MyInput; open MyIO

let rnd = new Random()
let sw = new Stopwatch()

let mutable pos = 0
let mutable text = []
let mutable miss = 0 //ミス回数
let mutable missList = [||] //ミス位置記録
let mutable runk = -1 //順位
let mutable playCnt = 0 //プレイ回数
let mutable mesStr = ""
let len = 100
let timeFormat t = ( int(t) / 1000 ).ToString() + "." + String.Format( "{0:D2}" , int(t) % 1000 / 10 ).ToString()

type State = |Init |Title |Main |Score |Fin
let mutable state = Init

let mutable savedata:( DateTime * int * int ) list = [] 

let update(g:MyGraphics , key:MyInput) =
    if key.kPush(Keys.Escape) then state <- Init

    match state with
    //初期処理
    |Init ->
        if File.Exists("save.dat") then
            savedata <- loadValue "save.dat"
            playCnt <- savedata.Length

        text <- List.init len (fun i -> char(rnd.Next(65,91)))
        missList <- [| for i in 0 .. len -> false |]
        miss <- 0
        pos <- len
        sw.Reset()
        mesStr <- "Spaceキーで開始"
        state <- Title
    
    //スタート前状態
    |Title ->
        if key.kPush(Keys.Space) then
            pos <- 0
            sw.Restart()
            mesStr <- "Escキーで中断可"
            state <- Main

    //ゲーム中状態
    |Main ->
        //キーチェック
        if key.getKey(0) <> Keys.None then
            if char(key.getKey(0)) = text.[pos] then
                pos <- pos + 1
                if len <= pos then
                    state <- Score
            else
                missList.[pos] <- true
                miss <- miss + 1
    
    //スコア設定処理
    |Score ->
        sw.Stop()
        let time = int(sw.ElapsedMilliseconds)
        savedata <-
            ( DateTime.Now , time , miss ) :: savedata |> 
            List.sortBy (fun (_,t,_) -> t)

        runk <- List.findIndex (fun (_,t,_) -> t = time)savedata
        playCnt <- playCnt + 1
        mesStr <- "終了！"  + (runk+1).ToString() + "位"
        saveValue "save.dat" savedata
        state <- Fin

    //終了時のスペースキー待ち状態
    |Fin ->
        if key.kPush(Keys.Space) then
            state <- Init

    //描画
    g.clear(Color.Black)

    g.setColor(Color.White)
    g.dStr 0 0 "<100文字タイピング>"
    g.dStr 180 0 mesStr

    //タイプ文字列描画
    List.iteri(
        fun i t ->
            g.setColor( if missList.[i] = true then Color.Red elif pos <= i then Color.White else Color.Gray )
            let x = (16*(i%20))
            let y = (i/20*16+20)
            g.dStr x y (t.ToString())
            if i = pos then g.dStr x y "_"
    )text

    //情報描画
    g.setColor(Color.White)
    g.dStr 2  102 ( "プレイ回数：" + playCnt.ToString())
    g.dStr 140 102 ( "TIME：" + timeFormat(sw.ElapsedMilliseconds))
    g.dStr 250 102 ( "MISS：" + miss.ToString() )


    //スコア描画
    g.setColor(Color.White)
    for i in 0 .. 19 do
        if i < savedata.Length then
            let day, time, miss = savedata.[i]
            g.setColor(if i = runk then Color.Red else Color.White)
            g.dStrS (i/10*150) (i%10*12+120) ( (i+1).ToString() + " : " + day.ToShortDateString() + " " + timeFormat(int64(time)) + " ×" + miss.ToString())
    