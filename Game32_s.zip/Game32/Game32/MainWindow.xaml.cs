﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Game32
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        // 描画属性用変数
        private DrawingAttributes inkDA = new DrawingAttributes();
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // 初期化
            inkDA.Width = 1;    // ペンの幅
            inkDA.Height = 1;   // ペンの高さ
            inkCanvas.DefaultDrawingAttributes = inkDA;
        }

        //ストローク削除
        private void button_Clear_Click(object sender, RoutedEventArgs e)
        {
            inkCanvas.Strokes.Clear();
            inkCanvas.Children.Clear();
        }

        //編集モード選択
        private void comboBox_EditingMode_DropDownClosed(object sender, EventArgs e)
        {
            // 選択されている項目を取得
            string selectedItem = ((ComboBoxItem)comboBox_EditingMode.SelectedItem).Content.ToString();
            switch (selectedItem)
            {
                case ("None"): inkCanvas.EditingMode = InkCanvasEditingMode.None; break;
                case ("Ink"): inkCanvas.EditingMode = InkCanvasEditingMode.Ink; break;
                case ("GestureOnly"): inkCanvas.EditingMode = InkCanvasEditingMode.GestureOnly; break;
                case ("InkAndGesture"): inkCanvas.EditingMode = InkCanvasEditingMode.InkAndGesture; break;
                case ("Select"): inkCanvas.EditingMode = InkCanvasEditingMode.Select; break;
                case ("EraseByPoint"): inkCanvas.EditingMode = InkCanvasEditingMode.EraseByPoint; break;
                case ("EraseByStroke"): inkCanvas.EditingMode = InkCanvasEditingMode.EraseByStroke; break;
            }          
        }

        private void comboBox_StylusTip_DropDownClosed(object sender, EventArgs e)
        {
             // 選択されている項目を取得
            string selectedItem = ((ComboBoxItem)comboBox_StylusTip.SelectedItem).Content.ToString();
            switch (selectedItem)
            {
                case ("Ellipse"):inkDA.StylusTip = StylusTip.Ellipse; break;
                case ("Rectangle"): inkDA.StylusTip = StylusTip.Rectangle; break;
            }
            inkCanvas.DefaultDrawingAttributes = inkDA;
        }

        private void sliderDAWidth_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (inkCanvas == null) return;
            inkDA.Width = sliderDAWidth.Value;    // ペンの幅
            lavelDAWidth.Content = "W:" + sliderDAWidth.Value;
            inkCanvas.DefaultDrawingAttributes = inkDA;
        }

        private void sliderDAHeight_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (inkCanvas == null) return;
            inkDA.Height = sliderDAHeight.Value;    // ペンの幅
            lavelDAHeight.Content = "H:" + sliderDAHeight.Value;
            inkCanvas.DefaultDrawingAttributes = inkDA;
        }

        private void sliderColorValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (inkCanvas == null) return;
            inkDA.Color = Color.FromArgb((byte)sliderA.Value, (byte)sliderR.Value, (byte)sliderG.Value, (byte)sliderB.Value);
            inkCanvas.DefaultDrawingAttributes = inkDA;
            lavelA.Content = "A:" + (byte)sliderA.Value;
            lavelR.Content = "R:" + (byte)sliderR.Value;
            lavelG.Content = "G:" + (byte)sliderG.Value;
            lavelB.Content = "B:" + (byte)sliderB.Value;
        }

        private void checkBoxHighlight_Checked(object sender, RoutedEventArgs e)
        {
            if (inkCanvas == null) return;
            inkDA.IsHighlighter = checkBoxHighlight.IsChecked.Value;
            inkCanvas.DefaultDrawingAttributes = inkDA;
        }

        private void checkBoxFitToCurve_Click(object sender, RoutedEventArgs e)
        {
            if (inkCanvas == null) return;
            inkDA.FitToCurve = checkBoxFitToCurve.IsChecked.Value;
            inkCanvas.DefaultDrawingAttributes = inkDA;
        }

        //ジェスチャを認識した時
        private void inkCanvas_Gesture(object sender, InkCanvasGestureEventArgs e)
        {
            ReadOnlyCollection<GestureRecognitionResult> gestureResults;
            // ジェスチャの認識結果を取得
            gestureResults = e.GetGestureRecognitionResults();
            // 認識結果の信頼性が高い順にメッセージを表示する
            if ( gestureResults[0].RecognitionConfidence == RecognitionConfidence.Strong )
            {
                // 認識時の領域（外枠）サイズを取得
                Rect strokeRect = e.Strokes.GetBounds();
                switch (gestureResults[0].ApplicationGesture)
                {
                    case ApplicationGesture.Circle: // 楕円（円）認識時
                        // 認識した外枠サイズに合わせて円を作成する
                        Ellipse ellipse = new Ellipse();
                        ellipse.Width = strokeRect.Width;
                        ellipse.Height = strokeRect.Height;
                        ellipse.SetValue(System.Windows.Controls.InkCanvas.LeftProperty, strokeRect.X);
                        ellipse.SetValue(System.Windows.Controls.InkCanvas.TopProperty, strokeRect.Y);
                        ellipse.Stroke = Brushes.Black;
                        // 作成した円をキャンバスに追加
                        inkCanvas.Children.Add(ellipse);
                        break;
                    case ApplicationGesture.Square:
                        // 四角形認識時
                        // 認識した外枠サイズに合わせて四角形を作成する
                        Rectangle rectangle = new Rectangle();
                        rectangle.Width = strokeRect.Width;
                        rectangle.Height = strokeRect.Height;
                        rectangle.SetValue(System.Windows.Controls.InkCanvas.LeftProperty, strokeRect.X);
                        rectangle.SetValue(System.Windows.Controls.InkCanvas.TopProperty, strokeRect.Y);
                        rectangle.Stroke = Brushes.Black;
                        // 作成した四角形をキャンバスに追加
                        inkCanvas.Children.Add(rectangle);
                        break;
                }
                labelGesuture.Content = (gestureResults[0].ApplicationGesture.ToString());
            }
                
        }

        // ［保存］ボタンクリック時の処理
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlgSave = new Microsoft.Win32.SaveFileDialog();

            dlgSave.Filter = "ビットマップファイル(*.bmp)|*.bmp|" +
            "JPEGファイル(*.jpg)|*,jpg|" +
            "PNGファイル(*.png)|*.png";
            dlgSave.AddExtension = true;

            if (inkCanvas.Strokes.Count == 0) { MessageBox.Show("何も書かれていない"); return; }

            if ((bool)dlgSave.ShowDialog())
            {
                // 拡張子を取得する
                string extension = System.IO.Path.GetExtension(dlgSave.FileName).ToUpper();

                // ストロークが描画されている境界を取得
                Rect rectBounds = inkCanvas.Strokes.GetBounds();

                // 描画先を作成
                DrawingVisual dv = new DrawingVisual();
                DrawingContext dc = dv.RenderOpen();
                // 描画エリアの位置補正（補正しないと黒い部分ができてしまう）
                dc.PushTransform(new TranslateTransform(-rectBounds.X, -rectBounds.Y));

                // 描画エリア(dc)に四角形を作成
                // 四角形の大きさはストロークが描画されている枠サイズとし、
                // 背景色はInkCanvasコントロールと同じにする
                dc.DrawRectangle(inkCanvas.Background, null, rectBounds);

                // 上記で作成した描画エリア(dc)にInkCanvasのストロークを描画
                inkCanvas.Strokes.Draw(dc);
                dc.Close();

                // ビジュアルオブジェクトをビットマップに変換する
                RenderTargetBitmap rtb = new RenderTargetBitmap(
                    (int)rectBounds.Width, (int)rectBounds.Height,
                    96, 96,
                    PixelFormats.Default);
                rtb.Render(dv);

                // ビットマップエンコーダー変数の宣言
                BitmapEncoder enc = null;

                switch (extension)
                {
                    case ".BMP":
                        enc = new BmpBitmapEncoder();
                        break;
                    case ".JPG":
                        enc = new JpegBitmapEncoder();
                        break;
                    case ".PNG":
                        enc = new PngBitmapEncoder();
                        break;
                }

                if (enc != null)
                {
                    // ビットマップフレームを作成してエンコーダーにフレームを追加する
                    enc.Frames.Add(BitmapFrame.Create(rtb));
                    // ファイルに書き込む
                    System.IO.Stream stream = System.IO.File.Create(dlgSave.FileName);
                    enc.Save(stream);
                    stream.Close();
                }
            }
        }

        // ［ISF形式で保存する］ボタンクリック時の処理
        private void btnSaveAsISF_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlgSave = new Microsoft.Win32.SaveFileDialog();

            dlgSave.Filter = "ISFファイル(*.isf)|*.isf";

            if ((bool)dlgSave.ShowDialog())
            {
                using ( System.IO.FileStream fs = 
                    new System.IO.FileStream(dlgSave.FileName, System.IO.FileMode.Create))
                {
                    inkCanvas.Strokes.Save(fs);
                }

                MessageBox.Show("保存しました");
            }
        }

        // ［ISF形式ファイルを開く］ボタンクリック時の処理
        private void btnOpenISF_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlgOpen = new Microsoft.Win32.OpenFileDialog();

            dlgOpen.Filter = "ISFファイル(*.isf)|*.isf";

            if ((bool)dlgOpen.ShowDialog())
            {
                // 現在のストロークをクリア
                inkCanvas.Strokes.Clear();

                using (System.IO.FileStream fs =
                    new System.IO.FileStream(dlgOpen.FileName, System.IO.FileMode.Open))
                {
                    inkCanvas.Strokes = new System.Windows.Ink.StrokeCollection(fs);
                }
            }
        }
    }
}
