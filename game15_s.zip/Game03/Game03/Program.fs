﻿open Microsoft.Xna.Framework;
open Microsoft.Xna.Framework.Audio;
open Microsoft.Xna.Framework.Content;
open Microsoft.Xna.Framework.Graphics;
open Microsoft.Xna.Framework.Input;
open System.IO;

//ゲームクラス
type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定

    //メンバ変数的なもの
    let g = new Graphics.Graphics(this,320,240)

    //盤面
    let mutable buffer = Array2D.zeroCreate 3 3

    let mutable kind = 1
    let mutable flg = 0
    let mutable texture:Texture2D[] = null;  

    //コンテンツ登録
    override this.LoadContent() =
        use stream1 = new FileStream("maru.png",FileMode.Open)
        use stream2 = new FileStream("batu.png",FileMode.Open)
        texture <- [|null;Texture2D.FromStream(this.GraphicsDevice,stream1) ; Texture2D.FromStream(this.GraphicsDevice,stream2)|]
        g.LoadContent()

    //ゲームロジック
    override this.Update gametime =
        km.setKey()//キー取得

        //クリックされたとき
        if km.mIsPush(0) then
            if flg <> 0 then
                flg <- 0
                buffer <- Array2D.zeroCreate 3 3
                kind <- 1
            else          
                let x = km.ms.X/32
                let y = km.ms.Y/32
                if x >= 0 && x < 3 && y >= 0 && y < 3 then
                    if buffer.[ x , y ] = 0 then
                        //○×設定
                        buffer.[ x , y ] <- kind

                        //引き分けの判定
                        let mutable sum = 0
                        for i in 0..2 do
                            for j in 0..2 do
                                if buffer.[i,j] <> 0 then
                                    sum <- sum + 1
                        if sum = 9 then flg <- 3

                        //勝ち判定
                        //横
                        for i in 0..2 do
                            sum <- 0
                            for j in 0..2 do
                                if buffer.[i,j] = kind then
                                    sum <- sum + 1
                            if sum = 3 then flg <- kind

                        //縦
                        for i in 0..2 do
                            sum <- 0
                            for j in 0..2 do
                                if buffer.[j,i] = kind then
                                    sum <- sum + 1 
                            if sum = 3 then flg <- kind

                        //斜め(左上から右下)
                        sum <- 0
                        for i in 0..2 do
                            if buffer.[i,i] = kind then
                                sum <- sum + 1 
                        if sum = 3 then flg <- kind

                        //斜め(左下から右上)
                        sum <- 0
                        let mutable j = 2
                        for i in 0..2 do                  
                            if buffer.[j,i] = kind then
                                sum <- sum + 1
                                j <- j-1
                        if sum = 3 then flg <- kind

                        //プレイヤー入れ替え
                        kind <- if kind = 1 then 2 else 1    
        
        base.Update gametime
        
    //描画処理
    override this.Draw gametime =
        g.Clear(Color.Black)//画面のクリア

        //盤面の描画
        Array2D.iteri ( fun x y a -> g.FillRect(x*32,y*32,31,31, Color.White); g.DrawImage(texture.[a],x*32,y*32) ) buffer
        
        //マルとバツのどっちのターンか表示
        if kind = 1 then
            g.DrawTextM("マルのターン", 0, 8, Color.White)
        else
            g.DrawTextM("バツのターン", 0, 8, Color.White)

        //勝敗の表示
        let result =
            function
            |0 -> "しあいちゅう"
            |1 -> "マルのかち"
            |2 -> "バツのかち"
            |3 -> "ひきわけ"
            |_ -> "Error"

        g.DrawTextM(result(flg), 0, 10, Color.White)

        base.Draw gametime

[<EntryPoint>]//プログラム開始位置
let main(args : string[]) =
    let game = new MyGame()
    game.Run()
    game.Dispose()
    0