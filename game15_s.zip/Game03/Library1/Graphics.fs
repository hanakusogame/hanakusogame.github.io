﻿//描画関連の機能をまとめたモジュール
//方向性が定まっていないため非常にごちゃごちゃ
module Graphics

open Microsoft.Xna.Framework;
open Microsoft.Xna.Framework.Graphics;

//描画関連クラス
type Graphics(gam, w, h) =
    let game = gam
    let gdm = new GraphicsDeviceManager(game)
    let spBatch = lazy new SpriteBatch(game.GraphicsDevice)
    let mutable color = Color.Black
    let effect = lazy new BasicEffect(game.GraphicsDevice)
    let sFont = lazy game.Content.Load<SpriteFont>("small")
    let mFont = lazy game.Content.Load<SpriteFont>("default")
    

    //コンストラクタ？
    do
        gdm.PreferredBackBufferWidth <- w
        gdm.PreferredBackBufferHeight <- h

    //線を描く
    let drawline colors = 
        for pass in effect.Value.CurrentTechnique.Passes do
            pass.Apply()
            gdm.GraphicsDevice.DrawUserPrimitives(PrimitiveType.LineStrip, colors, 0, colors.Length-1)
    
    //コンテンツロード？ぜんぜん関係なし？
    member this.LoadContent() =
        effect.Value.VertexColorEnabled <- true 
    
    //画面クリア
    member this.Clear (c) = gdm.GraphicsDevice.Clear(c)

    //色設定
    member this.SetColor (c) = color <- c

    //連続線描画
    member this.DrawPolyline (vlist:float32[][],c) =
        if vlist.Length > 1 then
            let cw = float32 gdm.PreferredBackBufferWidth / 2.0f
            let ch = float32 gdm.PreferredBackBufferHeight / 2.0f
            let colors =
                [|
                    for v in vlist ->
                        new VertexPositionColor(new Vector3( -1.0f + v.[0] / cw, 1.0f - v.[1] / ch , 0.0f),c)
                |]
            drawline colors
        
    //線分描画
    member this.DrawLine(x0, y0, x1, y1 , c ) =
        this.DrawPolyline([|[| (float32)x0 ; (float32)y0 |];[| (float32)x1 ; (float32)y1 |]|] , c )

    member this.DrawLine(x0, y0, x1, y1) = this.DrawLine(x0, y0, x1, y1, color)

    //矩形描画
    member this.DrawRect(x, y, w, h, c) =
        let cw = float32 gdm.PreferredBackBufferWidth / 2.0f
        let ch = float32 gdm.PreferredBackBufferHeight / 2.0f
        let xx = float32 x
        let yy = float32 y
        let ww = float32 w
        let hh = float32 h
        let colors =
            [|
                new VertexPositionColor(new Vector3( -1.0f + xx / cw, 1.0f - yy / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + (xx+ww) / cw, 1.0f - yy / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + (xx+ww) / cw, 1.0f - (yy+hh) / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + xx / cw, 1.0f - (yy+hh) / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + xx / cw, 1.0f - yy / ch , 0.0f),c)
            |]
        drawline colors

    member this.DrawRect(x, y, w, h) = this.DrawRect( x, y, w, h, color)

    //塗りつぶし矩形描画
    member this.FillRect(x, y, w, h, c) =
        let cw = float32 gdm.PreferredBackBufferWidth / 2.0f
        let ch = float32 gdm.PreferredBackBufferHeight / 2.0f
        let xx = float32 x
        let yy = float32 y
        let ww = float32 w
        let hh = float32 h
        let colors =
            [|
                new VertexPositionColor(new Vector3( -1.0f + xx / cw, 1.0f - yy / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + (xx+ww) / cw, 1.0f - yy / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + (xx+ww) / cw, 1.0f - (yy+hh) / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + xx / cw, 1.0f - yy / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + (xx+ww) / cw, 1.0f - (yy+hh) / ch , 0.0f),c)
                new VertexPositionColor(new Vector3( -1.0f + xx / cw, 1.0f - (yy+hh) / ch , 0.0f),c)
            |]
        for pass in effect.Value.CurrentTechnique.Passes do
            pass.Apply()
            gdm.GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleList, colors, 0, 2)

    member this.FillRect(x, y, w, h) = this.FillRect( x, y, w, h, color)

    //テキスト描画(中くらいのサイズ) ※x,yには行と桁を入れるの注意
    member this.DrawTextM(s:string, x, y, c) =
        let xx = float32 x * 16.0f
        let yy = (float32 y * 16.0f)-1.0f

        spBatch.Value.Begin()
        spBatch.Value.DrawString(mFont.Value, s ,new Vector2(xx, yy), c)
        spBatch.Value.End()

    member this.DrawTextM(s:string, x, y) = this.DrawTextM(s, x, y, color)

    //テキストの描画(小さいサイズ)
    member this.DrawTextS(s:string, x, y, c) =
        
        let xx = float32 x * 8.0f
        let yy = float32 y * 8.0f

        spBatch.Value.Begin()
        spBatch.Value.DrawString(sFont.Value, s ,new Vector2(xx, yy), c)
        spBatch.Value.End()

    member this.DrawTextS(s:string, x, y) = this.DrawTextS(s, x, y, color)

    //画像の部分描画
    member this.DrawImage(tex:Texture2D, dRect, sRect) =
        let rotation = 0.0f
        let origin = new Vector2()
        let flip = new SpriteEffects()
        let src = new System.Nullable<Rectangle>(sRect)
        spBatch.Value.Begin()
        spBatch.Value.Draw(tex, dRect, src, Color.White, rotation, origin, flip, 0.0f)
        spBatch.Value.End()

    //画像の部分描画2
    member this.DrawImage(tex:Texture2D, dx1, dy1, dx2, dy2, sx1, sy1) =
        if tex <> null then
            let dRect = new Rectangle(dx1, dy1, dx2, dy2)
            let sRect = new Rectangle(sx1, sy1, dx2, dy2)
            this.DrawImage(tex, dRect, sRect)

    //画像そのまま描画
    member this.DrawImage(tex:Texture2D , x, y) =
        if tex <> null then
            let dRect = new Rectangle(x, y, tex.Width, tex.Height)
            let sRect = new Rectangle(0, 0, tex.Width, tex.Height)
            this.DrawImage(tex, dRect, sRect)
