﻿//その他いろいろ置いておく（メモ的に使う）
module etc

open System.IO;
open System.Runtime.Serialization.Formatters.Binary;

//ファイル入出力処理(クラス等のシリアライズ)
//引用元→http://fsharpandenglishword.blog83.fc2.com/blog-entry-131.html
let saveValue filename x = 
    use stream = new FileStream(filename,FileMode.Create) 
    (new BinaryFormatter()).Serialize(stream,box x)
    
let loadValue filename =
    use stream = new FileStream(filename,FileMode.Open)
    (new BinaryFormatter()).Deserialize(stream) |> unbox

//-------------ここから完全にメモ---------------
(*

//ランダムな値
let rnd = new System.Random ()


//今回ちょっといらなそうなので退避
    //初期化
    //override  this.Initialize() =
        //base.Initialize()

    //コンテンツ登録
    //override this.LoadContent() =

    //コンテンツ破棄
    //override this.UnloadContent() =

*)