﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Windows.Ink;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Game33
{
    public partial class MainWindow : Window
    {
        private Stopwatch sw = new Stopwatch();
        private Random rnd = new Random();
        private ApplicationGesture[] gestureArray =
            (ApplicationGesture[])Enum.GetValues(typeof(ApplicationGesture));
        private int test = 3;
        private int cnt = 0;
        private List<TimeSpan> runkList = new List<TimeSpan>(); 

        public MainWindow()
        {
            InitializeComponent();
            CompositionTarget.Rendering += Update;
            inkCanvas.EditingMode = InkCanvasEditingMode.GestureOnly;
            inkCanvas.DefaultDrawingAttributes.Width = 5;
            inkCanvas.DefaultDrawingAttributes.Height = 5;
            labelGesuture2.Content = "";
            myStopwatchLabel.Content = sw.Elapsed.ToString("G").Substring(2, 13);
            
            if (File.Exists("save.dat"))
            {
                runkList = (List < TimeSpan >)LoadFromBinaryFile("save.dat");
                string s = "";
                for (int i = 0; i < 15; i++)
                {
                    if (i >= runkList.Count) break;
                    s = s + (i + 1).ToString().PadLeft(2) +
                        "|" + runkList[i].ToString("G").Substring(2, 13) + "\n";
                }
                labelRunking.Content = s;
            }
        }

        //ボタンクリック
        private void button_Click(object sender, RoutedEventArgs e)
        {
            button.Visibility = Visibility.Hidden;
            labelCnt.Content = "" + cnt;
            test = rnd.Next(3, 41);
            labelGesuture2.Content = (gestureArray[test].ToString());
            labelCnt.Content = "" + (cnt + 1);
            sw.Restart();
        }

        //ジェスチャー確定時
        private void inkCanvas_Gesture(object sender, InkCanvasGestureEventArgs e)
        {
            ReadOnlyCollection<GestureRecognitionResult> gestureResults;
            gestureResults = e.GetGestureRecognitionResults();
            ApplicationGesture g1 = gestureResults[0].ApplicationGesture;
            ApplicationGesture g2 = gestureArray[test];
            labelGesuture.Content = (g1.ToString());
            if (g1 == g2)
            {
                if (cnt == 9)
                {
                    sw.Stop();
                    myStopwatchLabel.Content = sw.Elapsed.ToString("G").Substring(2, 13);
                    int runk = runkList.FindIndex( t => sw.Elapsed < t);
                    if (runk != -1)
                    {
                        runkList.Insert(runk, sw.Elapsed);
                        labelCnt.Content = "終了！ " + (runk+1) + "位です。";
                    }
                    else
                    {
                        runkList.Add(sw.Elapsed);
                        labelCnt.Content = "終了！ 最下位です。";
                    }
                    SaveToBinaryFile(runkList, "save.dat");
                    string s = "";
                    for (int i = 0; i < 15; i++)
                    {
                        if (i >= runkList.Count) break;
                        s = s + (i+1).ToString().PadLeft(2) +
                            "|" + runkList[i].ToString("G").Substring(2, 13) + "\n";
                    }
                    labelRunking.Content = s;
                    cnt = 0;
                    labelGesuture.Content = "";
                    labelGesuture2.Content = "";
                    button.Visibility = Visibility.Visible;
                }
                else
                {
                    cnt++;
                    test = rnd.Next(3, 41);
                    labelCnt.Content = "" + (cnt+1);
                    labelGesuture.Content = "";
                    labelGesuture2.Content = (gestureArray[test].ToString());
                }
            }
        }

        //ストップウォッチ更新
        protected void Update(object sender, EventArgs e)
        {
            myStopwatchLabel.Content = sw.Elapsed.ToString("G").Substring(2, 13);
        }

        /// <summary>
        /// オブジェクトの内容をファイルから読み込み復元する
        /// </summary>
        /// <param name="path">読み込むファイル名</param>
        /// <returns>復元されたオブジェクト</returns>
        public static object LoadFromBinaryFile(string path)
        {
            FileStream fs = new FileStream(path,
                FileMode.Open,
                FileAccess.Read);
            BinaryFormatter f = new BinaryFormatter();
            //読み込んで逆シリアル化する
            object obj = f.Deserialize(fs);
            fs.Close();

            return obj;
        }

        /// <summary>
        /// オブジェクトの内容をファイルに保存する
        /// </summary>
        /// <param name="obj">保存するオブジェクト</param>
        /// <param name="path">保存先のファイル名</param>
        public static void SaveToBinaryFile(object obj, string path)
        {
            FileStream fs = new FileStream(path,
                FileMode.Create,
                FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            //シリアル化して書き込む
            bf.Serialize(fs, obj);
            fs.Close();
        }

    }
}
