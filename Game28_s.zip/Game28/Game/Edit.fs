﻿module Edit

open System.Windows.Forms
open System.Drawing
open System.Collections.Generic
open System.Text.RegularExpressions

open MyGraphics
open MyLoop
open MyInput
open MyForm
open KeyToStr

type Edit() =
    let mutable inputMode = 0
    let mutable cx,cy = 0,0
    let mutable bk_s = "" //変換前文字列
    let mutable sList = new List<string>()
    let mutable rList = []
    let kc = new KeysConverter()

    do
        sList.Add("")

    //更新処理
    member u.update(g:MyGraphics,keyy:MyInput) =
        let mutable s = sList.[cy]
        for key in keyy.KeyList do
            match key with
            | Keys.None -> ()

            | Keys.Tab ->
                if inputMode = 0 then inputMode <- 1
                else inputMode <- 0 
        
            //カーソル移動
            | Keys.Up ->
                if cy > 0 then
                    cy <- cy - 1
                    if cx > ( sList.[cy].Length ) then cx <- sList.[cy].Length

            | Keys.Down ->
                if cy < ( sList.Count - 1 ) then
                    cy <- cy + 1
                    if cx > ( sList.[cy].Length ) then cx <- sList.[cy].Length

            | Keys.Left ->
                if cx > 0 then cx <- cx - 1

            | Keys.Right ->
                if cx < ( sList.[cy].Length ) then cx <- cx + 1

            //改行
            | Keys.Enter ->
                if cx <> sList.[cy].Length then
                    sList.Insert( cy + 1 , sList.[cy].Remove(0,cx) )
                    sList.[cy] <- sList.[cy].Remove(cx)
                    cy <- cy + 1
                    cx <- 0
                //最後の文字の時
                else
                    sList.Insert( cy+1 , "" )
                    cy <- cy + 1
                    cx <- 0
        
            //前方削除
            | Keys.Delete ->
                if cx <> sList.[cy].Length then
                    s <- s.Remove(cx,1)
                    sList.[cy] <- s

            //後方削除
            | Keys.Back ->
                //変換候補削除
                if inputMode = 0 && bk_s.Length <> 0 then
                    bk_s <- ""
                else
                    if cx <> 0 then
                        s <- s.Remove( cx - 1 , 1 )
                        sList.[cy] <- s
                        cx <- cx - 1
                    else
                        //改行削除
                        if cy <> 0 then
                            cx <- sList.[ cy - 1 ].Length
                            sList.[ cy - 1 ] <- sList.[ cy - 1 ] + sList.[cy]
                            sList.RemoveAt(cy)
                            cy <- cy - 1
        
            //文字入力
            | k ->
                match inputMode with
                //ローマ字入力
                | 0 ->
                    //まず、英数字で取得
                    match List.tryFind( fun (a:Alphabet) -> a.key = k && a.shift = keyy.kShift() )al with
                    |None -> ()
                    |Some(a) ->
                        //アルファベットもしくはスペース
                        if List.exists(fun b -> b = a.str.[0])['a' .. 'z'] || a.str = " " || a.str = "-" then
                            bk_s <- bk_s + ( a.str )
            
                    //変換候補のリスト取得
                    let ss = bk_s
                    if ss <> "" then
                        rList <-
                            List.filter(fun (a:Japanese) ->
                                ( List.exists (fun b -> Regex.IsMatch(b,("^"+ss)) ) (a.rStr) ) )jp
                    else rList <- []
                
                    match rList.Length with
                    | 1 ->
                        //一致するとき確定
                        if List.exists (fun s -> bk_s = s)rList.Head.rStr then
                            let setS = rList.Head.jpStr
                            s <- s.Insert(cx, setS)
                            sList.[cy] <- s
                            cx <- cx + setS.Length
                            bk_s <- ""

                    | 0 ->
                        //候補がない場合は消す
                        bk_s <- ""

                    | _ -> ()
                 
                //半角英数字入力
                | 1 ->
                    match List.tryFind( fun (a:Alphabet) -> a.key = k && a.shift = keyy.kShift() )al with
                    |None -> ()
                    |Some(a) ->
                        s <- s.Insert(cx, a.str)
                        sList.[cy] <- s
                        cx <- cx + 1

                | _ -> ()

        g.setColor(Color.White)

        //文字の表示
        for i = 0 to ( sList.Count - 1 ) do
            for j = 0 to ( sList.[i].Length - 1 ) do
                g.dStr (j*20) (i*20) sList.[i].[j]

        //変換前文字の表示
        g.dStr (cx*20) (cy*20) bk_s
        
        //カーソル表示
        g.fRect (cx*20) (cy*20) 2 16

        //変換候補の表示
        List.iteri(fun i a -> g.dStrS (25*i) 210 a.jpStr)rList

        //その他情報
        let modeStr =
            match inputMode with
            |0 -> "ローマ字"
            |1 -> "半角英数"
            |_ -> "エラー"

        g.dStrS 0 220 ("入力:" + modeStr + "(tabで変更) X:" + cx.ToString() + " Y:" + cy.ToString())
        g.dStrS 0 230 ("F1:画面サイズ変更 F2:タイピング ESC:終了")
