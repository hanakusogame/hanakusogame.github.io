﻿open System
open System.Windows.Forms
open System.Drawing
open System.Collections.Generic
open System.Text.RegularExpressions
open System.Diagnostics

open MyGraphics
open MyLoop
open MyInput
open MyForm
open KeyToStr
open MyIO

open Edit

type Mode = |Edit |Typing

type State = |Start |Main |Kekka |Ranking

type RankData = { date:DateTime ; time:int64 ; miss:int }

type Typing() =
    let rnd = new Random()
    let mutable pos = 0
    let mutable baseList = []//半角英数字のリスト
    let mutable romaList = []//ローマ字のリスト
    let mutable missList = Array.create 100 false
    let mutable missCnt = 0
    let mutable rank = 0
    let mutable rankList =
        if not (fileChk("save.dat")) then
            [ for i in 0 .. 5 -> new List<RankData>() ]
        else
            loadValue "save.dat"
    let mutable bk_s = ""
    let mutable initFlg = false
    let mutable state = Start
    let mutable mode = 0
    let sw = new Stopwatch()

    //時間のフォーマット関数
    let timeFormat t =
        ( int(t) / 1000 ).ToString() + "." + String.Format( "{0:D2}" , int(t) % 1000 / 10 ).ToString()

    //描画処理
    let draw( g:MyGraphics ) =
        //文字の色を決める
        let cSet i =
            g.setColor(
                if missList.[i] then
                    Color.Red
                elif pos > i then
                    Color.Gray
                else
                    Color.White
            )

        //文字列の表示
        match mode with
        | 0 | 1 | 2 | 3 ->
            //英数字
            baseList |>
            List.iteri (
                fun i a ->
                    cSet i
                    g.dStr ( (i%10) * 32 ) ((i/10) * 20) a.str  
            )
        | 4 | 5 ->
            //ローマ字
            romaList |>
            List.iteri (
                fun i a ->
                    cSet i
                    let x = if a.jpStr.Length = 1 then ( (i%10) * 32 ) + 5 else ( (i%10) * 32 )
                    g.dStr x ((i/10) * 20) a.jpStr
            )
        | _ -> ()

        g.setColor(Color.White)

        //現在地の表示
        g.dStr ( (pos%10) * 32) ((pos/10) * 20) "_" 

        if state = Start then
            //モード
            let strMode =
                match mode with
                | 0 -> "アルファベット(小文字のみ)"
                | 1 -> "アルファベット(大小混在)"
                | 2 -> "数字"
                | 3 -> "半角英数字全て"
                | 4 -> "ローマ字１文字パターンのみ"
                | 5 -> "ローマ字全パターン"
                | a -> "エラー:" + a.ToString()

            g.dStr 0 200 ("モード:" + strMode)
            g.dStrS 0 220 "Space:開始 tab:中断 左右:モード変更 R:ランキング"
            g.dStrS 0 230 "F1:画面サイズ変更 F2:メモ帳 ESC:終了"

        if state = Main then

            //時間の表示
            g.dStr 220 200 ( "time:" + (timeFormat(sw.ElapsedMilliseconds)))

            //ミス回数の表示
            g.dStr 220 220 ( "miss:" + missCnt.ToString())

            //ローマ字入力用表示
            if mode >= 4 then

                let x = if pos > 96 then 99 - pos else 3
                for i = 0 to x do
                    //背景
                    g.setColor(if i = 0 then Color.White else Color.Gray)
                    g.fRect ( i * 55 + 1) 200 54 39
                
                    //文字(カタカナ)
                    g.setColor(Color.Black)
                    let p = pos + i
                    g.dStr ( i * 55 ) 200 ( romaList.[p].jpStr.ToString() )
                
                    //文字(ローマ字)
                    let len = romaList.[p].jpStr.Length

                    let matchList =
                        if i = 0 then
                            romaList.[p].rStr |>
                            List.filter ( fun b -> Regex.IsMatch( b , ("^" + bk_s) ) )
                        else
                            romaList.[p].rStr

                    matchList |>
                    List.iteri(
                        fun ri r ->
                            g.dStrS ( i * 55 + ( 16 * len ) + 3 ) (ri * 10 + 200) ( r )
                    )

                    //入力中文字
                    g.dStr 0 220 bk_s

    //問題リスト作成
    let createList () =
        match mode with
        | 0 -> baseList <- [ for i in 1 .. 100 -> al.[ rnd.Next( 0 , 25 ) ] ] //小文字のみ
        | 1 -> baseList <- [ for i in 1 .. 100 -> al.[ rnd.Next( 0 , 51 ) ] ] //大文字小文字混合
        | 2 -> baseList <- [ for i in 1 .. 100 -> al.[ rnd.Next( 52 , 62 ) ] ] //数字
        | 3 -> baseList <- [ for i in 1 .. 100 -> al.[ rnd.Next( 0 , al.Length ) ] ] //全部
        | 4 -> romaList <- [ for i in 1 .. 100 -> jp.[ rnd.Next( 0 , 84 ) ] ] //ローマ字１文字パターンのみ
        | 5 -> romaList <- [ for i in 1 .. 100 -> jp.[ rnd.Next( 0 , ( jp.Length - 3 ) ) ] ] //ローマ字全部(3文字の3パターンは除く)
        | _ -> ()

    //初期処理
    let init() =
        createList()
        missCnt <- 0
        missList <- Array.create 100 false
        pos <- 0

    //開始前処理
    let start ( g:MyGraphics, key:MyInput ) =
        if not initFlg then init() ; initFlg <- true

        if key.kPush( Keys.Left ) then
            if mode = 0 then mode <- 5
            else mode <- mode - 1
            createList()
        elif key.kPush( Keys.Right ) then
            if mode = 5 then mode <- 0
            else mode <- mode + 1
            createList()

        if key.kPush( Keys.Space ) then
            sw.Restart()
            initFlg <-false
            Main
        elif key.kPush( Keys.R ) then
            Ranking
        else
            draw(g)
            Start

    //メイン処理
    let main ( g:MyGraphics, keyy:MyInput ) =
        //更新処理
        let mutable returnVal = Main

        let finish(k,a) =
            sw.Stop()
            let t = sw.ElapsedMilliseconds
            let r = rankList.[mode]

            if r.Count = 0 then rank <- 0
            elif t > r.[r.Count - 1].time  then rank <- r.Count
            else rank <- r.FindIndex(fun x -> t < x.time)

            rankList.[mode].Insert( rank, { date = DateTime.Now ; time = t ; miss = missCnt } )
                                
            saveValue "save.dat" rankList

        //中断
        if keyy.kPush(Keys.Tab) then
            returnVal <- Start
            
        for key in keyy.KeyList do
            match mode with
            //英数字系
            | 0 | 1 | 2 | 3 ->
                match key , baseList.[pos] with
                | Keys.None , _ -> ()
                | k , a ->
                    if k = a.key && keyy.kShift() = a.shift then
                        if pos = 99 then
                            finish(k,a)
                            returnVal <- Kekka
                        else
                            pos <- pos + 1
                    else
                        if k <> Keys.ShiftKey then
                            missCnt <- missCnt + 1
                            missList.[pos] <- true

            //ローマ字系
            | 4 | 5 ->
                match key , romaList.[pos] with
                | Keys.None , _ -> ()
                | k , a ->
                    //まず、英数字で取得
                    match List.tryFind( fun (a:Alphabet) -> a.key = k && a.shift = keyy.kShift() )al with
                    |None -> ()
                    |Some(a) ->
                        //「アルファベット」と「スペース」と「ー」のみ
                        if List.exists(fun b -> b = a.str.[0])['a' .. 'z'] || a.str = " " || a.str = "-" then
                            bk_s <- bk_s + ( a.str )

                    //一致するパターンがあるか？
                    if List.exists ( fun b -> Regex.IsMatch( b , ( "^" + bk_s ) ) ) a.rStr then
                        //完全一致の場合
                        if List.exists ( fun b -> bk_s = b ) a.rStr then
                            bk_s <- ""
                            if pos = 99 then
                                finish(k,a)
                                returnVal <- Kekka
                            else
                                pos <- pos + 1
                    else
                        missCnt <- missCnt + 1
                        missList.[pos] <- true
                        bk_s <- ""

            | _ -> ()

        keyy.KeyList <- []

        draw(g)
        returnVal

    //結果表示
    let mutable kekkaStart = 0
    let kekka( g:MyGraphics, key:MyInput ) =
        let mutable returnVal = Kekka
        if key.kPush(Keys.Space) then
            kekkaStart <- 0
            returnVal <- Start
        
        for k in key.KeyList do
            match k with
            | Keys.Down ->
                if kekkaStart > 0 then
                    kekkaStart <- kekkaStart - 1

            | Keys.Up ->
                if (kekkaStart + 10) < rankList.[mode].Count then
                    kekkaStart <- kekkaStart + 1
            |_ -> ()   
        
        //文字の色を決める
        let cSet i =
            g.setColor(
                if missList.[i] then
                    Color.Red
                else
                    Color.White
            )

        //文字列の表示
        match mode with
        | 0 | 1 | 2 | 3 ->
            //英数字
            baseList |>
            List.iteri (
                fun i a ->
                    cSet i
                    g.dStrS ( (i%10) * 16 ) ((i/10) * 10) a.str  
            )
        | 4 | 5 ->
            //ローマ字
            romaList |>
            List.iteri (
                fun i a ->
                    cSet i
                    let x = if a.jpStr.Length = 1 then ( (i%10) * 16 ) + 5 else ( (i%10) * 16 )
                    g.dStrS x ((i/10) * 10) a.jpStr
            )
        | _ -> ()

        //結果
        g.setColor(Color.White)
        g.dStr  0 120 "[結果]"
        g.dStr 10 160 ("タイム:" + timeFormat(sw.ElapsedMilliseconds) )
        g.dStr 10 180 ("ミス　:" + missCnt.ToString())
        g.dStr 10 200 ("ランク:" + (rank+1).ToString() + "位")

        //ランキング
        g.dStr 160 0 "ランキング"
        let r = rankList.[mode]
        for i = 0 to 9 do
            let j = kekkaStart + i
            if j < r.Count then
                g.setColor(
                    if rank = j then Color.Red else Color.White
                )
                let si = (j+1).ToString()
                let sd = r.[j].date.ToString("[MM/dd]")
                let ti = timeFormat(r.[j].time)
                let mi = r.[j].miss.ToString()
                g.dStr 160 ( i * 20 + 20) ( si + ": " + ti + "(" + mi + ")" )
                g.dStrS 280 ( i * 20 + 26) sd

        g.setColor(Color.White)
        g.dStr 160 220 ("プレイ回数:" + (r.Count.ToString()))

        g.dStrS 0 230 ("Space:戻る 上下:スクロール")

        returnVal

    //ランキング表示
    let mutable rankingPos = 0
    let ranking( g:MyGraphics, key:MyInput ) =
        let mutable returnVal = Ranking

        if key.kPush( Keys.Up ) then
            if mode = 0 then mode <- 5
            else mode <- mode - 1
            rankingPos <- 0
            createList()
        elif key.kPush( Keys.Down ) then
            if mode = 5 then mode <- 0
            else mode <- mode + 1
            rankingPos <- 0
            createList()

        let r = rankList.[mode]
        for k in key.KeyList do
            match k with
            | Keys.Space ->
                rankingPos <- 0
                returnVal <- Start
            | Keys.Left ->
                if 0 <= (rankingPos - 20) then
                    rankingPos <- rankingPos - 20
            | Keys.Right ->
                if r.Count > (rankingPos + 20) then
                    rankingPos <- rankingPos + 20
            |_ -> ()
        
        g.setColor(Color.White)
        
        g.dStr 0 0 ( "[ランキング]" )
        g.dStrS 120 0 ( "プレイ回数" + r.Count.ToString() )
        for i = 0 to 9 do
            for j = 0 to 1 do
                let y = i * 20 + 20
                let x = j * 160
                let p = (j*10) + i + rankingPos
                if p < r.Count then
                    let si = (p+1).ToString()
                    let sd = r.[p].date.ToString("[MM/dd]")
                    let ti = timeFormat(r.[p].time)
                    let mi = r.[p].miss.ToString()
                    g.dStr x y ( si + ": " + ti + "(" + mi + ")" )
                    g.dStrS (x+110) (y+6) sd
        
        //モード
        let strMode =
            match mode with
            | 0 -> "アルファベット(小文字のみ)"
            | 1 -> "アルファベット(大小混在)"
            | 2 -> "数字"
            | 3 -> "半角英数字全て"
            | 4 -> "ローマ字１文字パターンのみ"
            | 5 -> "ローマ字全パターン"
            | a -> "エラー:" + a.ToString()

        g.dStrS 120 10 ("モード:" + strMode)

        g.dStrS 0 230 ("Space:戻る 上下:モード変更 左右:スクロール")

        returnVal

    //更新処理
    member u.update(g:MyGraphics , key:MyInput ) =
        state <-
        match state with
        | Start -> start(g,key)
        | Main -> main(g,key)
        | Kekka -> kekka(g,key)
        | Ranking -> ranking(g,key)

type Game() =
    inherit MyForm()

    let mutable mode = Mode.Typing
    let edit = new Edit()
    let typing  = new Typing()
    //更新処理
    override u.update(g,key) =
        if key.kPush(Keys.F2) then
            match mode with
            | Edit -> mode <- Mode.Typing
            | Typing -> mode <- Mode.Edit

        match mode with
        | Edit -> edit.update(g,key)
        | Typing -> typing.update( g , key )
        key.KeyList <- []

let game = new Game()
game.run()
