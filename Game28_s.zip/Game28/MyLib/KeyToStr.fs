﻿module KeyToStr

open System
open System.Drawing
open System.Windows.Forms
open MyInput
open MyGraphics

//日本語ローマ字入力用
type Japanese =
    {
        jpStr:string
        rStr:string list
    }

//半角英数字
type Alphabet =
    {
        key : Keys
        shift : bool
        str : string
    }

let al =
    [
        { key = Keys.A ; shift = false ; str = "a" }
        { key = Keys.B ; shift = false ; str = "b" }
        { key = Keys.C ; shift = false ; str = "c" }
        { key = Keys.D ; shift = false ; str = "d" }
        { key = Keys.E ; shift = false ; str = "e" }
        { key = Keys.F ; shift = false ; str = "f" }
        { key = Keys.G ; shift = false ; str = "g" }
        { key = Keys.H ; shift = false ; str = "h" }
        { key = Keys.I ; shift = false ; str = "i" }
        { key = Keys.J ; shift = false ; str = "j" }
        { key = Keys.K ; shift = false ; str = "k" }
        { key = Keys.L ; shift = false ; str = "l" }
        { key = Keys.M ; shift = false ; str = "m" }
        { key = Keys.N ; shift = false ; str = "n" }
        { key = Keys.O ; shift = false ; str = "o" }
        { key = Keys.P ; shift = false ; str = "p" }
        { key = Keys.Q ; shift = false ; str = "q" }
        { key = Keys.R ; shift = false ; str = "r" }
        { key = Keys.S ; shift = false ; str = "s" }
        { key = Keys.T ; shift = false ; str = "t" }
        { key = Keys.U ; shift = false ; str = "u" }
        { key = Keys.V ; shift = false ; str = "v" }
        { key = Keys.W ; shift = false ; str = "w" }
        { key = Keys.X ; shift = false ; str = "x" }
        { key = Keys.Y ; shift = false ; str = "y" }
        { key = Keys.Z ; shift = false ; str = "z" }

        { key = Keys.A ; shift = true ; str = "A" }
        { key = Keys.B ; shift = true ; str = "B" }
        { key = Keys.C ; shift = true ; str = "C" }
        { key = Keys.D ; shift = true ; str = "D" }
        { key = Keys.E ; shift = true ; str = "E" }
        { key = Keys.F ; shift = true ; str = "F" }
        { key = Keys.G ; shift = true ; str = "G" }
        { key = Keys.H ; shift = true ; str = "H" }
        { key = Keys.I ; shift = true ; str = "I" }
        { key = Keys.J ; shift = true ; str = "J" }
        { key = Keys.K ; shift = true ; str = "K" }
        { key = Keys.L ; shift = true ; str = "L" }
        { key = Keys.M ; shift = true ; str = "M" }
        { key = Keys.N ; shift = true ; str = "N" }
        { key = Keys.O ; shift = true ; str = "O" }
        { key = Keys.P ; shift = true ; str = "P" }
        { key = Keys.Q ; shift = true ; str = "Q" }
        { key = Keys.R ; shift = true ; str = "R" }
        { key = Keys.S ; shift = true ; str = "S" }
        { key = Keys.T ; shift = true ; str = "T" }
        { key = Keys.U ; shift = true ; str = "U" }
        { key = Keys.V ; shift = true ; str = "V" }
        { key = Keys.W ; shift = true ; str = "W" }
        { key = Keys.X ; shift = true ; str = "X" }
        { key = Keys.Y ; shift = true ; str = "Y" }
        { key = Keys.Z ; shift = true ; str = "Z" }

        { key = Keys.D0 ; shift = false ; str = "0" }
        { key = Keys.D1 ; shift = false ; str = "1" }
        { key = Keys.D2 ; shift = false ; str = "2" }
        { key = Keys.D3 ; shift = false ; str = "3" }
        { key = Keys.D4 ; shift = false ; str = "4" }
        { key = Keys.D5 ; shift = false ; str = "5" }
        { key = Keys.D6 ; shift = false ; str = "6" }
        { key = Keys.D7 ; shift = false ; str = "7" }
        { key = Keys.D8 ; shift = false ; str = "8" }
        { key = Keys.D9 ; shift = false ; str = "9" }

        //{ key = Keys.NumPad0 ; shift = false ; str = "0" }
        //{ key = Keys.NumPad1 ; shift = false ; str = "1" }
        //{ key = Keys.NumPad2 ; shift = false ; str = "2" }
        //{ key = Keys.NumPad3 ; shift = false ; str = "3" }
        //{ key = Keys.NumPad4 ; shift = false ; str = "4" }
        //{ key = Keys.NumPad5 ; shift = false ; str = "5" }
        //{ key = Keys.NumPad6 ; shift = false ; str = "6" }
        //{ key = Keys.NumPad7 ; shift = false ; str = "7" }
        //{ key = Keys.NumPad8 ; shift = false ; str = "8" }
        //{ key = Keys.NumPad9 ; shift = false ; str = "9" }

        { key = Keys.D1 ; shift = true ; str = "!" }
        { key = Keys.D2 ; shift = true ; str = "\""}
        { key = Keys.D3 ; shift = true ; str = "#" }
        { key = Keys.D4 ; shift = true ; str = "$" }
        { key = Keys.D5 ; shift = true ; str = "%" }
        { key = Keys.D6 ; shift = true ; str = "&" }
        { key = Keys.D7 ; shift = true ; str = "'" }
        { key = Keys.D8 ; shift = true ; str = "(" }
        { key = Keys.D9 ; shift = true ; str = ")" }

        { key = Keys.Space           ; shift = false ; str = " "}
        { key = Keys.OemMinus        ; shift = false ; str = "-"}
        { key = Keys.Oem5            ; shift = false ; str = "\\" }
        { key = Keys.Oem7            ; shift = false ; str = "^"}
        { key = Keys.Oemtilde        ; shift = false ; str = "@"}
        { key = Keys.OemOpenBrackets ; shift = false ; str = "["}
        { key = Keys.Oemplus         ; shift = false ; str = ";"}
        { key = Keys.Oem1            ; shift = false ; str = ":"}
        { key = Keys.Oem6            ; shift = false ; str = "]"}
        { key = Keys.Oemcomma        ; shift = false ; str = ","}
        { key = Keys.OemPeriod       ; shift = false ; str = "."}
        { key = Keys.OemQuestion     ; shift = false ; str = "/"}
        //{ key = Keys.OemBackslash    ; shift = false ; str = "\\"}

        { key = Keys.OemMinus        ; shift = true ; str = "="}
        { key = Keys.Oem5            ; shift = true ; str = "|"}
        { key = Keys.Oem7            ; shift = true ; str = "~"}
        { key = Keys.Oemtilde        ; shift = true ; str = "`"}
        { key = Keys.OemOpenBrackets ; shift = true ; str = "{"}
        { key = Keys.Oemplus         ; shift = true ; str = "+"}
        { key = Keys.Oem1            ; shift = true ; str = "*"}
        { key = Keys.Oem6            ; shift = true ; str = "}"}
        { key = Keys.Oemcomma        ; shift = true ; str = "<"}
        { key = Keys.OemPeriod       ; shift = true ; str = ">"}
        { key = Keys.OemQuestion     ; shift = true ; str = "?"}
        { key = Keys.OemBackslash    ; shift = true ; str = "_"}
    ]

let jp =
    [
        { jpStr = "　" ; rStr = [" "] };
        { jpStr = "ア" ; rStr = ["a"] };{ jpStr = "イ" ; rStr = ["i";"yi"] };{ jpStr = "ウ" ; rStr = ["u";"wu";"wyu"] };{ jpStr = "エ" ; rStr = ["e"] };{ jpStr = "オ" ; rStr = ["o"] };
        { jpStr = "カ" ; rStr = ["ka";"ca"] };{ jpStr = "キ" ; rStr = ["ki"] };{ jpStr = "ク" ; rStr = ["ku";"cu"] };{ jpStr = "ケ" ; rStr = ["ke"] };{ jpStr = "コ" ; rStr = ["ko";"co"] };
        { jpStr = "サ" ; rStr = ["sa"] };{ jpStr = "シ" ; rStr = ["si";"shi"] };{ jpStr = "ス" ; rStr = ["su"] };{ jpStr = "セ" ; rStr = ["se"] };{ jpStr = "ソ" ; rStr = ["so"] };
        { jpStr = "タ" ; rStr = ["ta"] };{ jpStr = "チ" ; rStr = ["ti";"chi"] };{ jpStr = "ツ" ; rStr = ["tu";"tsu"] };{ jpStr = "テ" ; rStr = ["te"] };{ jpStr = "ト" ; rStr = ["to"] };
        { jpStr = "ナ" ; rStr = ["na"] };{ jpStr = "ニ" ; rStr = ["ni"] };{ jpStr = "ヌ" ; rStr = ["nu"] };{ jpStr = "ネ" ; rStr = ["ne"] };{ jpStr = "ノ" ; rStr = ["no"] };
        { jpStr = "ハ" ; rStr = ["ha"] };{ jpStr = "ヒ" ; rStr = ["hi"] };{ jpStr = "フ" ; rStr = ["hu";"fu"] };{ jpStr = "ヘ" ; rStr = ["he"] };{ jpStr = "ホ" ; rStr = ["ho"] };
        { jpStr = "マ" ; rStr = ["ma"] };{ jpStr = "ミ" ; rStr = ["mi"] };{ jpStr = "ム" ; rStr = ["mu"] };{ jpStr = "メ" ; rStr = ["me"] };{ jpStr = "モ" ; rStr = ["mo"] };
        { jpStr = "ヤ" ; rStr = ["ya"] };{ jpStr = "ユ" ; rStr = ["yu"] };{ jpStr = "ヨ" ; rStr = ["yo"] };{ jpStr = "ー" ; rStr = ["-"] };
        { jpStr = "ラ" ; rStr = ["ra"] };{ jpStr = "リ" ; rStr = ["ri"] };{ jpStr = "ル" ; rStr = ["ru"] };{ jpStr = "レ" ; rStr = ["re"] };{ jpStr = "ロ" ; rStr = ["ro"] };
        { jpStr = "ワ" ; rStr = ["wa"] };{ jpStr = "ヲ" ; rStr = ["wo"] };{ jpStr = "ン" ; rStr = ["nn";"xn"] };{ jpStr = "ヴ" ; rStr = ["vu"] };
        { jpStr = "ガ" ; rStr = ["ga"] };{ jpStr = "ギ" ; rStr = ["gi"] };{ jpStr = "グ" ; rStr = ["gu"] };{ jpStr = "ゲ" ; rStr = ["ge"] };{ jpStr = "ゴ" ; rStr = ["go"] };
        { jpStr = "ザ" ; rStr = ["za"] };{ jpStr = "ジ" ; rStr = ["zi";"ji"] };{ jpStr = "ズ" ; rStr = ["zu"] };{ jpStr = "ゼ" ; rStr = ["ze"] };{ jpStr = "ゾ" ; rStr = ["zo"] };
        { jpStr = "ダ" ; rStr = ["da"] };{ jpStr = "ヂ" ; rStr = ["di"] };{ jpStr = "ヅ" ; rStr = ["du"] };{ jpStr = "デ" ; rStr = ["de"] };{ jpStr = "ド" ; rStr = ["do"] };
        { jpStr = "バ" ; rStr = ["ba"] };{ jpStr = "ビ" ; rStr = ["bi"] };{ jpStr = "ブ" ; rStr = ["bu"] };{ jpStr = "ベ" ; rStr = ["be"] };{ jpStr = "ボ" ; rStr = ["bo"] };
        { jpStr = "パ" ; rStr = ["pa"] };{ jpStr = "ピ" ; rStr = ["pi"] };{ jpStr = "プ" ; rStr = ["pu"] };{ jpStr = "ペ" ; rStr = ["pe"] };{ jpStr = "ポ" ; rStr = ["po"] };
        { jpStr = "ァ" ; rStr = ["xa";"la"] };{ jpStr = "ィ" ; rStr = ["xi";"li"] };{ jpStr = "ゥ" ; rStr = ["xu";"lu"] };{ jpStr = "ェ" ; rStr = ["xe";"le";"xye";"lye"] };{ jpStr = "ォ" ; rStr = ["xo";"lo"] };
        { jpStr = "ッ" ; rStr = ["xtu";"ltu"] };{ jpStr = "ャ" ; rStr = ["lya";"lya"] };{ jpStr = "ュ" ; rStr = ["xyu";"lyu"] };{ jpStr = "ョ" ; rStr = ["xyo";"lyo"] };{ jpStr = "ヮ" ; rStr = ["xwa";"lwa"] };
        { jpStr = "キャ" ; rStr = ["kya"] };{ jpStr = "キィ" ; rStr = ["kyi"] };{ jpStr = "キュ" ; rStr = ["kyu"] };{ jpStr = "キェ" ; rStr = ["kye"] };{ jpStr = "キョ" ; rStr = ["kyo"] };
        { jpStr = "ウァ" ; rStr = ["wya"] };{ jpStr = "ウィ" ; rStr = ["whi";"wi"] };{ jpStr = "ウェ" ; rStr = ["whe";"we"] };{ jpStr = "ウォ" ; rStr = ["wyo"] };
        { jpStr = "クャ" ; rStr = ["qya"] };{ jpStr = "クィ" ; rStr = ["qyi";"qwi"] };{ jpStr = "クュ" ; rStr = ["qyu"] };{ jpStr = "クェ" ; rStr = ["qye";"qwe"] };{ jpStr = "クョ" ; rStr = ["qyo"] };
        { jpStr = "クァ" ; rStr = ["kwa";"qwa"] };{ jpStr = "クゥ" ; rStr = ["qwu"] };{ jpStr = "クォ" ; rStr = ["qwo"] };
        { jpStr = "シャ" ; rStr = ["sya";"sha"] };{ jpStr = "シィ" ; rStr = ["syi"] };{ jpStr = "シュ" ; rStr = ["syu";"shu"] };{ jpStr = "シェ" ; rStr = ["sye";"she"] };{ jpStr = "ショ" ; rStr = ["syo";"sho"] };
        { jpStr = "スァ" ; rStr = ["swa"] };{ jpStr = "スィ" ; rStr = ["swi"] };{ jpStr = "スゥ" ; rStr = ["swu"] };{ jpStr = "スェ" ; rStr = ["swe"] };{ jpStr = "スォ" ; rStr = ["swo"] };
        { jpStr = "テャ" ; rStr = ["tha"] };{ jpStr = "ティ" ; rStr = ["thi"] };{ jpStr = "テュ" ; rStr = ["thu"] };{ jpStr = "テェ" ; rStr = ["the"] };{ jpStr = "テョ" ; rStr = ["tho"] };
        { jpStr = "トァ" ; rStr = ["twa"] };{ jpStr = "トィ" ; rStr = ["twi"] };{ jpStr = "トゥ" ; rStr = ["twu"] };{ jpStr = "トェ" ; rStr = ["twe"] };{ jpStr = "トォ" ; rStr = ["two"] };
        { jpStr = "チャ" ; rStr = ["tya";"cha";"cya"] };{ jpStr = "チィ" ; rStr = ["tyi";"cyi"] };{ jpStr = "チュ" ; rStr = ["tyu";"chu";"cyu"] };{ jpStr = "チェ" ; rStr = ["tye";"che";"cye"] };{ jpStr = "チョ" ; rStr = ["tyo";"cho";"cyo"] };
        { jpStr = "ファ" ; rStr = ["fa";"fwa"] };{ jpStr = "フィ" ; rStr = ["fi";"fwi";"fyi"] };{ jpStr = "フゥ" ; rStr = ["fwu"] };{ jpStr = "フェ" ; rStr = ["fe";"fwi";"fye"] };{ jpStr = "フォ" ; rStr = ["fo";"fwo"] };
        { jpStr = "グァ" ; rStr = ["gwa"] };{ jpStr = "グィ" ; rStr = ["gwi"] };{ jpStr = "グゥ" ; rStr = ["gwu"] };{ jpStr = "グェ" ; rStr = ["gwe"] };{ jpStr = "グォ" ; rStr = ["gwo"] };
        { jpStr = "ニャ" ; rStr = ["nya"] };{ jpStr = "ニィ" ; rStr = ["nyi"] };{ jpStr = "ニュ" ; rStr = ["nyu"] };{ jpStr = "ニェ" ; rStr = ["nye"] };{ jpStr = "ニョ" ; rStr = ["nyo"] };
        { jpStr = "ドァ" ; rStr = ["dwa"] };{ jpStr = "ドィ" ; rStr = ["dwi"] };{ jpStr = "ドゥ" ; rStr = ["dwu"] };{ jpStr = "ドェ" ; rStr = ["dwe"] };{ jpStr = "ドォ" ; rStr = ["dwo"] };
        { jpStr = "ヒャ" ; rStr = ["hya"] };{ jpStr = "ヒィ" ; rStr = ["hyi"] };{ jpStr = "ヒュ" ; rStr = ["hyu"] };{ jpStr = "ヒェ" ; rStr = ["hye"] };{ jpStr = "ヒョ" ; rStr = ["hyo"] };
        { jpStr = "フャ" ; rStr = ["fya"] };{ jpStr = "フュ" ; rStr = ["fyu"] };{ jpStr = "フョ" ; rStr = ["fyo"] };
        { jpStr = "ミャ" ; rStr = ["mya"] };{ jpStr = "ミィ" ; rStr = ["myi"] };{ jpStr = "ミュ" ; rStr = ["myu"] };{ jpStr = "ミェ" ; rStr = ["mye"] };{ jpStr = "ミョ" ; rStr = ["myo"] };
        { jpStr = "ツァ" ; rStr = ["tsa"] };{ jpStr = "ツィ" ; rStr = ["tsi"] };{ jpStr = "ツェ" ; rStr = ["tse"] };{ jpStr = "ツォ" ; rStr = ["tso"] };
        { jpStr = "リャ" ; rStr = ["rya"] };{ jpStr = "リィ" ; rStr = ["ryi"] };{ jpStr = "リュ" ; rStr = ["ryu"] };{ jpStr = "リェ" ; rStr = ["rye"] };{ jpStr = "リョ" ; rStr = ["ryo"] };
        { jpStr = "ギャ" ; rStr = ["gya"] };{ jpStr = "ギィ" ; rStr = ["gyi"] };{ jpStr = "ギュ" ; rStr = ["gyu"] };{ jpStr = "ギェ" ; rStr = ["gye"] };{ jpStr = "ギョ" ; rStr = ["gyo"] };
        { jpStr = "ヴァ" ; rStr = ["va"] };{ jpStr = "ヴィ" ; rStr = ["vi";"vyi"] };{ jpStr = "ヴェ" ; rStr = ["ve";"vye"] };{ jpStr = "ヴォ" ; rStr = ["vo"] };
        { jpStr = "ヴャ" ; rStr = ["vya"] };{ jpStr = "ヴュ" ; rStr = ["vyu"] };{ jpStr = "ヴョ" ; rStr = ["vyo"] };
        { jpStr = "ジャ" ; rStr = ["ja";"jya";"zya"] };{ jpStr = "ジィ" ; rStr = ["jyi";"zyi"] };{ jpStr = "ジュ" ; rStr = ["ju";"jyu";"zyu"] };{ jpStr = "ジェ" ; rStr = ["je";"jye";"zye"] };{ jpStr = "ジョ" ; rStr = ["jo";"jyo";"zyo"] };
        { jpStr = "ヂャ" ; rStr = ["dya"] };{ jpStr = "ヂィ" ; rStr = ["dyi"] };{ jpStr = "ヂュ" ; rStr = ["dyu"] };{ jpStr = "ヂェ" ; rStr = ["dye"] };{ jpStr = "ヂョ" ; rStr = ["dyo"] };
        { jpStr = "デャ" ; rStr = ["dha"] };{ jpStr = "ディ" ; rStr = ["dhi"] };{ jpStr = "デュ" ; rStr = ["dhu"] };{ jpStr = "デェ" ; rStr = ["dhe"] };{ jpStr = "デョ" ; rStr = ["dho"] };
        { jpStr = "ビャ" ; rStr = ["bya"] };{ jpStr = "ビィ" ; rStr = ["byi"] };{ jpStr = "ビュ" ; rStr = ["byu"] };{ jpStr = "ビェ" ; rStr = ["bye"] };{ jpStr = "ビョ" ; rStr = ["byo"] };
        { jpStr = "ピャ" ; rStr = ["pya"] };{ jpStr = "ピィ" ; rStr = ["pyi"] };{ jpStr = "ピュ" ; rStr = ["pyu"] };{ jpStr = "ピェ" ; rStr = ["pye"] };{ jpStr = "ピョ" ; rStr = ["pyo"] };
        { jpStr = "ッカ" ; rStr = ["kka"] };{ jpStr = "ッキ" ; rStr = ["kki"] };{ jpStr = "ック" ; rStr = ["kku"] };{ jpStr = "ッケ" ; rStr = ["kke"] };{ jpStr = "ッコ" ; rStr = ["kko"] };
        { jpStr = "ッガ" ; rStr = ["gga"] };{ jpStr = "ッギ" ; rStr = ["ggi"] };{ jpStr = "ッグ" ; rStr = ["ggu"] };{ jpStr = "ッゲ" ; rStr = ["gge"] };{ jpStr = "ッゴ" ; rStr = ["ggo"] };
        { jpStr = "ッサ" ; rStr = ["ssa"] };{ jpStr = "ッシ" ; rStr = ["ssi"] };{ jpStr = "ッス" ; rStr = ["ssu"] };{ jpStr = "ッセ" ; rStr = ["sse"] };{ jpStr = "ッソ" ; rStr = ["sso"] };
        { jpStr = "ッザ" ; rStr = ["zza"] };{ jpStr = "ッジ" ; rStr = ["zzi"] };{ jpStr = "ッズ" ; rStr = ["zzu"] };{ jpStr = "ッゼ" ; rStr = ["zze"] };{ jpStr = "ッゾ" ; rStr = ["zzo"] };
        { jpStr = "ッタ" ; rStr = ["tta"] };{ jpStr = "ッチ" ; rStr = ["tti"] };{ jpStr = "ッツ" ; rStr = ["ttu"] };{ jpStr = "ッテ" ; rStr = ["tte"] };{ jpStr = "ット" ; rStr = ["tto"] };
        { jpStr = "ッダ" ; rStr = ["dda"] };{ jpStr = "ッヂ" ; rStr = ["ddi"] };{ jpStr = "ッヅ" ; rStr = ["ddu"] };{ jpStr = "ッデ" ; rStr = ["dde"] };{ jpStr = "ッド" ; rStr = ["ddo"] };
        { jpStr = "ッハ" ; rStr = ["hha"] };{ jpStr = "ッヒ" ; rStr = ["hhi"] };{ jpStr = "ッフ" ; rStr = ["hhu";"ffu"] };{ jpStr = "ッヘ" ; rStr = ["hhe"] };{ jpStr = "ッホ" ; rStr = ["hho"] };
        { jpStr = "ッバ" ; rStr = ["bba"] };{ jpStr = "ッビ" ; rStr = ["bbi"] };{ jpStr = "ッブ" ; rStr = ["bbu"] };{ jpStr = "ッベ" ; rStr = ["bbe"] };{ jpStr = "ッボ" ; rStr = ["bbo"] };
        { jpStr = "ッマ" ; rStr = ["mma"] };{ jpStr = "ッミ" ; rStr = ["mmi"] };{ jpStr = "ッム" ; rStr = ["mmu"] };{ jpStr = "ッメ" ; rStr = ["mme"] };{ jpStr = "ッモ" ; rStr = ["mmo"] };
        { jpStr = "ッパ" ; rStr = ["ppa"] };{ jpStr = "ッピ" ; rStr = ["ppi"] };{ jpStr = "ップ" ; rStr = ["ppu"] };{ jpStr = "ッペ" ; rStr = ["ppe"] };{ jpStr = "ッポ" ; rStr = ["ppo"] };
        { jpStr = "ッヤ" ; rStr = ["yya"] };{ jpStr = "ッイ" ; rStr = ["yyi"] };{ jpStr = "ッユ" ; rStr = ["yyu"] };{ jpStr = "ッヨ" ; rStr = ["yyo"] };
        { jpStr = "ッラ" ; rStr = ["rra"] };{ jpStr = "ッリ" ; rStr = ["rri"] };{ jpStr = "ッル" ; rStr = ["rru"] };{ jpStr = "ッレ" ; rStr = ["rre"] };{ jpStr = "ッロ" ; rStr = ["rro"] };
        { jpStr = "ッワ" ; rStr = ["wwa"] };{ jpStr = "ッウ" ; rStr = ["wwu"] };{ jpStr = "ッヲ" ; rStr = ["wwo"] };
        { jpStr = "イェ" ; rStr = ["ye"] };
        { jpStr = "ッァ" ; rStr = ["xxa";"lxa"] };{ jpStr = "ッィ" ; rStr = ["xxi";"lxi";"xxyi";"llyi"] };{ jpStr = "ッゥ" ; rStr = ["xxu";"lxu"] };{ jpStr = "ッェ" ; rStr = ["xxe";"lxe";"xxye";"llye"] };{ jpStr = "ッォ" ; rStr = ["xxo";"lxo"] };
        { jpStr = "ッャ" ; rStr = ["xxya";"llya"] };{ jpStr = "ッュ" ; rStr = ["xxyu";"llyu"] };{ jpStr = "ッョ" ; rStr = ["xxyo";"llyo"] };
        { jpStr = "ッウィ" ; rStr = ["wwi"] };{ jpStr = "ッイェ" ; rStr = ["yye"] };{ jpStr = "ッウェ" ; rStr = ["wwe"] };
    ]