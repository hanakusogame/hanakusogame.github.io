﻿//グラフィックス関連モジュール
module MyGraphics
open System.Windows.Forms
open System.Drawing
open System.Drawing.Drawing2D


type MyGraphics(form:Form) =
    
    let currentContext = BufferedGraphicsManager.Current 
    //let myBuffer = currentContext.Allocate(form.CreateGraphics(),form.DisplayRectangle)
    let mutable myBuffer = currentContext.Allocate(form.CreateGraphics(),form.DisplayRectangle)

    let img = new Bitmap(form.ClientSize.Width , form.ClientSize.Height);
    let g = Graphics.FromImage(img);
    let mutable color = Color.White
    let mutable fontSize = 12
    let brush = new SolidBrush(color)
    let pen = new Pen(color)
    
    //フォントの有無をチェックする関数(フォント名が引数)
    let fontchk fontname =
        let texCol = new Text.InstalledFontCollection()
        texCol.Families |>
        Array.exists(fun a -> fontname = a.Name)

    //let fontM = new Font("ＭＳ ゴシック", float32(12), FontStyle.Bold)
    let fontM = new Font( "ＭＳ ゴシック", float32(12) )

    let fontS = new Font("ＭＳ ゴシック", float32(8))

    do
        myBuffer.Graphics.InterpolationMode <- InterpolationMode.NearestNeighbor
        g.InterpolationMode <- InterpolationMode.NearestNeighbor

    member u.render() =
        let sx,sy = form.ClientSize.Width,form.ClientSize.Height
        myBuffer.Graphics.DrawImage( img , 0 , 0 , sx , sy )
        myBuffer.Render()

    member u.reSize(w,h) =
        form.ClientSize <- new Size( w , h )
        myBuffer.Dispose()//いるのか要らないのかわからん
        myBuffer <- currentContext.Allocate(form.CreateGraphics(),form.DisplayRectangle)
        myBuffer.Graphics.InterpolationMode <- InterpolationMode.NearestNeighbor


    member u.clear(c) = g.Clear(c)

    member u.setColor c = color <- c
    member u.setRgb r g b = color <- Color.FromArgb(r,g,b)

    //文字列表示
    member u.dStr x y str =
        brush.Color <- color
        g.DrawString(str.ToString(), fontM , brush, float32(x), float32(y))

    //小さめ文字test
    member u.dStrS x y str =
        brush.Color <- color
        g.DrawString(str.ToString(), fontS, brush, float32(x), float32(y))
    
    //円の描画
    member u.dCircle((x:int),y,w,h) =
        pen.Color <- color
        g.DrawEllipse(pen, x, y, w, h)

    member u.dCircle(x, y, r) =
        u.dCircle( (x-r), (y-r), ((r-1)*2), ((r-1)*2) )

    //円の描画(塗りつぶし)
    member u.fCircle( (x:int), y, w, h ) =
        brush.Color <- color
        g.FillEllipse( brush, x, y, w, h )

    member u.fCircle(x, y, r) =
        u.fCircle( (x-r), (y-r), ((r-1)*2), ((r-1)*2) )

    //矩形表示
    member u.dRect x y w h =
        pen.Color <- color
        g.DrawRectangle(pen , x, y, w-1, h-1)

    //矩形表示(塗りつぶし)
    member u.fRect (x:int) y w h =
        brush.Color <- color
        g.FillRectangle(brush, x, y, w, h)

    //正方形表示
    member u.dBox x y size = u.dRect x y size size

    //正方形表示(塗りつぶし)
    member u.fBox x y size = u.fRect x y size size

    //直線描画
    member u.dLine (x1:int) y1 x2 y2 =
        pen.Color <- color
        g.DrawLine( pen, x1, y1, x2, y2 )

    //連続直線描画
    member u.dLines (p:Point[]) =
        pen.Color <- color
        if p.Length > 1 then
            g.DrawLines(pen,p)

    //多角形描画
    member u.dPoly (a:(int*int)List) =
        pen.Color <- color
        let p = Array.init a.Length ( fun i ->
            let (x,y) = a.[i]
            new Point( x,y ) )
        g.DrawPolygon(pen,p)

    //多角形描画(塗りつぶし)
    member u.fPoly (a:(int*int)List) =
        brush.Color <- color
        let p = Array.init a.Length ( fun i ->
            let (x,y) = a.[i]
            new Point( x,y ) )
        g.FillPolygon(brush,p)