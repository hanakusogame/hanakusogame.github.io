﻿module MyIO
open System.IO
open System.Runtime.Serialization.Formatters.Binary


let fileChk filename = File.Exists(filename)
//ファイル入出力処理(クラス等のシリアライズ)
//引用元→http://fsharpandenglishword.blog83.fc2.com/blog-entry-131.html
let saveValue filename x = 
    use stream = new FileStream(filename,FileMode.Create) 
    (new BinaryFormatter()).Serialize(stream,box x)
    
let loadValue filename =
    use stream = new FileStream(filename,FileMode.Open)
    (new BinaryFormatter()).Deserialize(stream) |> unbox

