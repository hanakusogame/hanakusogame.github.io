﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace WindowsGame1 {
    class KeyManager {
        public KeyboardState keyState;     // 現在の状態
        private KeyboardState prevKeyState; // 前のフレームの状態
        public MouseState ms;//マウスの状態
        private MouseState bk_ms; // 前のフレームの状態

        //キー情報セット(マウスも)(毎フレームごとに呼べ)
        public void setKey(Game game) {
            prevKeyState = keyState;
            keyState = Keyboard.GetState();
            bk_ms = ms;
            ms = Mouse.GetState();
        }

        //押されているときTrueを返す
        //キーボード
        public bool IsDown(Keys key) {
            return keyState.IsKeyDown(key);
        }
        //マウス
        public bool IsDown(int i) {
            if (i == 0) return (ms.LeftButton == ButtonState.Pressed);
            if (i == 1) return (ms.RightButton == ButtonState.Pressed);
            if (i == 2) return (ms.MiddleButton == ButtonState.Pressed);
            return false;
        }

        //押された瞬間のときTrueを返す
        //キーボード
        public bool IsPressed(Keys key) {
            return (keyState.IsKeyDown(key) && prevKeyState.IsKeyUp(key));
        }
        //マウス
        public bool IsPressed(int i) {
            if (i == 0) return (ms.LeftButton == ButtonState.Pressed && bk_ms.LeftButton == ButtonState.Released);
            if (i == 1) return (ms.RightButton == ButtonState.Pressed && bk_ms.RightButton == ButtonState.Released);
            if (i == 2) return (ms.MiddleButton == ButtonState.Pressed && bk_ms.MiddleButton == ButtonState.Released);
            return false;
        }

        //離された瞬間のときTrueを返す
        public bool IsRelease(Keys key) {
            return (keyState.IsKeyUp(key) && prevKeyState.IsKeyDown(key));
        }
        //マウス
        public bool IsRelease(int i) {
            if (i == 0) return (ms.LeftButton == ButtonState.Released && bk_ms.LeftButton == ButtonState.Pressed);
            if (i == 1) return (ms.RightButton == ButtonState.Released && bk_ms.RightButton == ButtonState.Pressed);
            if (i == 2) return (ms.MiddleButton == ButtonState.Released && bk_ms.MiddleButton == ButtonState.Pressed);
            return false;
        }

    }
}
