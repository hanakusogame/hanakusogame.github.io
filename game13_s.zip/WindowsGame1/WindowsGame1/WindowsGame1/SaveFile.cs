﻿using System;
using System.Xml.Serialization;
using System.IO;

namespace WindowsGame1 {
    //ファイルをセーブするクラスかと見せかけて共通して使う情報をまとめているようなクラス
    class SaveFile {
        //保存するクラス(SampleClass)インスタンスを作成
        public Block[] data;

        //初期化(とりあえず)
        public void init() {
            data = new Block[10];
            for (int i = 0; i < data.Length; i++) {
                data[i] = new Block( i * 25, 100+(i*1), 20, 30);
            }
        }

        //セーブ処理
        public void save() {
            //保存先のファイル名
            string fileName = @"test.xml";

            //XmlSerializerオブジェクトを作成
            //オブジェクトの型を指定する
            XmlSerializer serializer = new XmlSerializer(typeof(Block[]));
            //書き込むファイルを開く
            FileStream fs = new FileStream(fileName, FileMode.Create);
            //シリアル化し、XMLファイルに保存する
            serializer.Serialize(fs, data);
            //ファイルを閉じる
            fs.Close();
        }

        //ロード処理
        public void loadBase(String fileName) {
            //XmlSerializerオブジェクトを作成
            XmlSerializer serializer = new XmlSerializer(typeof(Block[]));
            //読み込むファイルを開く
            FileStream fs = new System.IO.FileStream(fileName, FileMode.Open);
            //XMLファイルから読み込み、逆シリアル化する
            data = (Block[])serializer.Deserialize(fs);
            //ファイルを閉じる
            fs.Close();
        }

        public void load() {
            loadBase("test.xml");
        }

        public void dLoad() {
            loadBase("d_test.xml");
        }
    }
}
