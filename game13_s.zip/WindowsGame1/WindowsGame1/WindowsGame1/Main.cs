using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace WindowsGame1 {
    //基底 Game クラスから派生した、ゲームのメイン クラスです。
    public class Main : Game {

        int dispX = 320, dispY = 240;
        StageManager sm = new StageManager();//ステージ管理クラス
        KeyManager km = new KeyManager();//キー管理クラス
        SaveFile sf = new SaveFile();//セーブファイル
        Graphics g;//グラフィックスクラス

        //コンストラクタ
        public Main() {
            Content.RootDirectory = "Content";

            // Windows Phone のフレーム レートは既定で 30 fps です。
            TargetElapsedTime = TimeSpan.FromTicks(333333);

            // ロック中のバッテリ寿命を延長する。
            InactiveSleepTime = TimeSpan.FromSeconds(1);

            // ウインドウ上でマウスのポインタを表示するようにする
            this.IsMouseVisible = true;

            // ユーザーにウインドウサイズの変更を許可する
            //this.Window.AllowUserResizing = true;

            //ウィンドウタイトル変更
            // this.Window.Title = "ゲーム";

            //グラフィックスの生成
            g = new Graphics(this, dispX, dispY);
        }

        //初期化
        protected override void Initialize() {
            base.Initialize();
        }

        //コンテンツ読み込み
        protected override void LoadContent() {
            g.LoadContent();
        }

        //コンテンツ破棄
        protected override void UnloadContent() { }

        //更新処理(ゲームロジック)
        protected override void Update(GameTime gameTime) {
            // ゲームの終了条件をチェックします。
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // キーボードの状態を設定
            km.setKey(this);

            //画面を更新
            sm.update(km, sf);

            base.Update(gameTime);
        }

        //描画処理
        protected override void Draw(GameTime gameTime) {
            //画面を描画
            sm.draw(g);
            base.Draw(gameTime);
        }
    }
}
