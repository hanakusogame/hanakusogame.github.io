﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;

namespace WindowsGame1 {
    //ステージ作成画面クラス
    class Edit : Stage {
        int mx, my;
        int x, y, w, h;
        bool helpFlg;//操作方法表示フラグ
        List<Block> bList;

        //初期化
        public override void init(SaveFile sf) {
            id = 3;
            //sf.init();
            //sf.save();
            sf.load();
            helpFlg = true;
            //ブロック作成
            bList = new List<Block>(sf.data);

        }

        //更新
        public override void update(StageManager sm, KeyManager km, SaveFile sf) {
            mx = km.ms.X;
            my = km.ms.Y;

            //ブロック作成処理
            if (km.IsDown(0)) {
                if (km.IsPressed(0)) {
                    x = mx;
                    y = my;
                    if(helpFlg == true) helpFlg = false;
                }
                w = mx;
                h = my;
            }
            else {
                if (km.IsRelease(0)) {
                    //左右反転
                    if (x > w) {
                        int tmp = x;
                        x = w;
                        w = tmp;
                    }

                    //上下反転
                    if (y > h) {
                        int tmp = y;
                        y = h;
                        h = tmp;
                    }

                    //小さすぎる場合作らない
                    if (w - x > 12 && h - y > 12) {
                        bList.Add(new Block(x, y, w - x, h - y));
                    }
                }
            }

            //ブロック削除処理
            if (km.IsPressed(1)) {
                bList.RemoveAll(b => (mx < b.x + b.w && b.x < mx && my < b.y + b.h && b.y < my));
            }

            //プレイする
            if (km.IsPressed(Keys.Space)) {
                sf.data = bList.ToArray();
                sf.save();
                sm.setPrevStage();
            }

            //ヘルプを表示
            if (km.IsPressed(Keys.H)) helpFlg = true;

            //デフォルトに戻す
            if (km.IsPressed(Keys.D)) {
                sf.dLoad();
                bList = new List<Block>(sf.data);
            }
        }

        //描画
        public override void draw(Graphics g) {
            //画面クリア
            g.SetColor(0, 0, 0);
            g.Clear();

            g.SetColor(255, 0, 0);
            g.DrawText("エディットモード" , 0, 0);
            g.DrawText("x=" + mx + " Y=" + my, 200, 0);


            //ブロック描画
            bList.ForEach(b => b.draw(g));

            //作成中ブロックの描画
            g.SetColor(255, 0, 0);
            g.DrawRect(x, y, w - x, h - y);
            if (helpFlg) {
                g.DrawText("Space:プレイする D:デフォルトにもどす", 0, 160);
                g.DrawText("H:ヘルプ", 0, 180);
                g.DrawText("ひだりドラッグ:ブロックをつくる", 0, 200);
                g.DrawText("みぎクリック:ブロックをけす", 0, 220);
            }
        }
    }
}
