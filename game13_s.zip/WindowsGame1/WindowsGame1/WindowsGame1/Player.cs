﻿using System.Collections.Generic;
using Microsoft.Xna.Framework.Input;

namespace WindowsGame1 {
    //プレイヤークラス
    //と、見せかけてブロックと敵キャラ以外ほとんど全部制御
    class Player {
        //メンバ変数
        public int x, y, w, h;
        private int dx, dy;//移動量
        private float jumpPower = 3;//ジャンプ力？
        private int sp = 3;//速度
        private bool dieFlg;//死亡フラグ
        private bool startflg;

        //なぜここにあるのかわからないスコアとハイスコア
        private int score,hiScore;

        //初期処理
        public void init() {
            //全部決め打ちだぜ
            x = 120;
            y = 220;
            w = 16;
            h = 16;
            dieFlg =false;
            score = 0;
        }

        //更新(リトライしたいときtrueを返す)
        public bool update(KeyManager km, List<Block> bList, List<Enemy> eList) {
            //生きているとき
            if (!dieFlg && startflg) {
                //移動処理
                dx = 0; dy = sp;
                //if (km.IsDown(Keys.Up)) dy = -sp;
                //if (km.IsDown(Keys.Down)) dy = sp;
                if (km.IsDown(Keys.Left)) dx = -sp;
                if (km.IsDown(Keys.Right)) dx = sp;
            
                if (km.IsPressed(Keys.Z)) {
                    //接地判定
                    if (y + h >= 240 || bList.Exists(b => (x < b.x + b.w && b.x < x + w && y < b.y + b.h && b.y < y + h + 1))) {
                        jumpPower = -6.0f;
                    }
                }

                //ジャンプ力を衰えさせる
                if (jumpPower < 5.0f) {
                    jumpPower += 0.25f;
                    dy = (int)jumpPower;
                }

                //上昇中
                if (jumpPower < 0) {
                    //頭ぶつけた判定
                    if (y <= 0 || bList.Exists(b => (x < b.x + b.w && b.x < x + w && y - 1 < b.y + b.h && b.y < y + h))) {
                        jumpPower = 0.0f;
                        dy = (int)jumpPower;
                    }
                }

                x += dx;
                y += dy;

                //当たり判定
                bList.ForEach(b => collision(b));

                //画面からはみ出さないようにする
                if (x < 0) x = 0;
                else if (x + w > 320) x = 320 - w;
                if (y < 0) y = 0;
                else if (y + w > 240) y = 240 - h;

                //黄色い敵にあたったとき
                List<Enemy> dieEList = eList.FindAll(e => (e.type == 1 && x < e.x + e.w && e.x < x + w && y < e.y + e.h && e.y < y + h));
                if (dieEList.Count > 0) {
                    score += dieEList.Count;//スコアを増やす
                    dieEList.ForEach(e => eList.Remove(e));//まさかここで消すとは思うまい…
                }

                //死亡判定（緑の敵にあたったとき）
                dieFlg = eList.Exists(e => (e.type == 0 && x < e.x + e.w && e.x < x + w && y < e.y + e.h && e.y < y + h));

                //死んだら
                if (dieFlg && score > hiScore) hiScore = score;//ハイスコア判定・設定（ここでやるべきでない気がする
            }
            else {
                //死んでるときＺキーでリトライ
                if (km.IsPressed(Keys.Z)) {             
                    startflg = true;
                    return true;
                }
            }

            return false;
        }

        //当たり判定
        public void collision(Block b) {
            if (x < b.x + b.w && b.x < x + w && y < b.y + b.h && b.y < y + h) {
                //移動処理
                if (dy > 0) {
                    // ブロックの上端
                    if ((y + h) - b.y < b.dMax) {
                        y = b.y - h;
                        return;
                    }
                }

                if (dy < 0) {
                    // ブロックの下端
                    if ((b.y + b.h) - y < b.dMax) {
                        y = b.y + b.h;
                        return;
                    }
                }

                if (dx > 0) {
                    // ブロックの左端
                    if ((x + w) - b.x < b.dMax) {
                        x = b.x - w;
                        return;
                    }
                }

                if (dx < 0) {
                    // ブロックの右端
                    if ((b.x + b.w) - x < b.dMax) {
                        x = b.x + b.w;
                        return;
                    }
                }
            }
        }

        //描画
        public void draw(Graphics g) {
            //スコアとハイスコアの描画
            g.SetColor(0, 255, 0);
            g.DrawText("スコア:" + score, 100, 0);
            g.DrawText("ハイスコア:" + hiScore, 200, 0);
            if (!startflg) {
                g.SetColor(0,0,0,200);
                g.FillRect(60, 60, 200, 120);
                g.SetColor(0, 255, 0);
                g.DrawText("みどりよけきいろとり", 80, 80);
                g.DrawText("ゲーム", 120, 100);
                g.DrawText("Zキーでスタート", 100, 140);
                g.DrawText("Spaceキーでエディット", 80, 160);
            }
            else {
                //プレイヤー自身の描画
                if (dieFlg) g.SetColor(255, 0, 0);
                else g.SetColor(255, 255, 255);
                g.FillRect(x, y, w, h);

                //死んでいるとき
                if (dieFlg) {
                    //ゲームオーバーの表示
                    g.SetColor(0, 0, 0, 200);
                    g.FillRect(60, 60, 200, 120);
                    g.SetColor(0, 255, 0);

                    g.DrawText("ゲームオーバー", 90, 80);
                    if (hiScore == score) {
                        g.DrawText("ハイスコアです", 90, 100);
                    }
                    g.DrawText("Zキーでリトライ", 90, 140);
                }
            }
        }
    }
}
