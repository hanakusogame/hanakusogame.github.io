﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;
using System.IO;
using Microsoft.Xna.Framework;
using System.Xml.Serialization;

namespace WindowsGame1 {
    //ゲーム実行画面
    class Play : Stage {
        //メンバ変数
        Player p = new Player();
        List<Block> bList;
        List<Enemy> eList;
        Random rnd = new Random();
        int frame;
        int level;

        //初期化
        public override void init(SaveFile sf) {
            id = 2;//未使用？
            frame = 0;

            //プレイヤーの初期化
            p.init();

            //ブロック読み込み
            sf.load();
            bList = new List<Block>(sf.data);

            //敵作成・発生
            eList = new List<Enemy>();
            for (int i = 0; i < 3; i++) {
                eList.Add(new Enemy(rnd.Next(300), 10));
            }

            //ｙ座標が低い順にソート
            bList.Sort((b1, b2) => b2.y - b1.y);
        }

        //更新処理
        public override void update(StageManager sm, KeyManager km, SaveFile sf) {
            //エディットモードに戻る
            if (km.IsPressed(Keys.Space)) {
                sm.setNextStage();
            }

            //プレイヤー移動
            if (p.update(km, bList, eList)) {
                sm.setThisStage();//再スタート
            }

            //壁更新処理（現状何もしてない
            bList.ForEach(b => b.update());

            //敵発生処理
            if (frame / 500 < 10) {
                level = (frame / 500) + 1;
            }
            if (frame%(110-(level*10)) == 0) eList.Add(new Enemy(rnd.Next(300), 10));

            //敵更新処理
            eList.ForEach(e => e.update(bList));

            //敵削除処理
            eList.RemoveAll(e => e.dieFlg);

            frame++;//フレームカウンタ更新
        }

        //描画処理
        public override void draw(Graphics g) {
            //画面クリア
            g.SetColor(0, 0, 0);
            g.Clear();
            g.SetColor(0, 255, 0);
            g.DrawText("レベル:" + level, 0, 0);

            //敵
            eList.ForEach(e => e.draw(g));

            //ブロック
            bList.ForEach(b => b.draw(g));

            //プレイヤー
            p.draw(g);


        }
    }
}

