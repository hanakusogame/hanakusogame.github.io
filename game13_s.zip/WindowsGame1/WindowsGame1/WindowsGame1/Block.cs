﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsGame1 {
    //ブロッククラス
    public class Block {
        //メンバ変数；
        public int x, y, w, h;
        public int dMax = 6;//衝突判定幅

        //コンストラクタ
        public Block() {
        }
        public Block(int x, int y, int w, int h) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }

        //更新処理
        public void update() { }

        //描画処理
        public void draw(Graphics g) {
            //塗り潰し矩形の描画
            g.SetColor(150, 150, 150);
            g.FillRect(x, y, w, h);
        }
    }
}
