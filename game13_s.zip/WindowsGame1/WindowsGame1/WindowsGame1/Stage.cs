﻿
namespace WindowsGame1 {
    //ステージ（画面）インターフェース
    abstract class Stage {
        public int id;

        //抽象メソッド
        public abstract void init(SaveFile sf);
        public abstract void update(StageManager sm, KeyManager km, SaveFile sf);
        public abstract void draw(Graphics g);
    }
}
