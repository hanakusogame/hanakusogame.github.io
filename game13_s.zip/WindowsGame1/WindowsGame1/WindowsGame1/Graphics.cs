using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

//�O���t�B�b�N�X
//������̃T�C�g�̃T���v�����قڂ��̂܂ܗ��p��http://www.saturn.dti.ne.jp/npaka/windowsphone/
//�Ȃ̂ňӖ����������Ă��Ȃ�
    public class Graphics {
        private Game game;//�Q�[���{��
        private GraphicsDeviceManager gdm;    //GDM
        private SpriteBatch spBatch;//�X�v���C�g�o�b�`
        private Color color;  //�F
        private BasicEffect effect; //�G�t�F�N�g
        private SpriteFont font; //�X�v���C�g�t�H���g

        //�`��ݒ�
        private float rotation { get; set; }//��]
        private Vector2 origin { get; set; } //���_
        private SpriteEffects flip { get; set; } //���]

        //�R���X�g���N�^
        public Graphics(Game game, int w, int h) {
            this.game = game;
            gdm = new GraphicsDeviceManager(game);

            // ��ʂ̉𑜓x��ύX����
            gdm.PreferredBackBufferWidth = w;
            gdm.PreferredBackBufferHeight = h;
        }

        //�O���t�B�N�X�R���e���g�̓ǂݍ���
        public void LoadContent() {
            spBatch = new SpriteBatch(gdm.GraphicsDevice);
            color = Color.White;
            effect = new BasicEffect(gdm.GraphicsDevice);
            effect.VertexColorEnabled = true;
            font = game.Content.Load<SpriteFont>("font");
        }

        //�O���t�B�b�N�X�f�o�C�X�}�l�[�W���̎擾
        public GraphicsDeviceManager GetGraphicsDeviceManager() {
            return gdm;
        }

        //�F�̎w��
        public void SetColor(int red, int green, int blue) {
            this.color = new Color((byte)red, (byte)green, (byte)blue);
        }

        //�F�̎w��
        public void SetColor(int red, int green, int blue, int alpha) {
            this.color = new Color((byte)red, (byte)green, (byte)blue, (byte)alpha);
        }

        //��ʂ̃N���A
        public void Clear() {
            gdm.GraphicsDevice.Clear(color);
        }

        //���C���̕`��
        public void DrawLine(float x0, float y0, float x1, float y1) {
            float cw = gdm.PreferredBackBufferWidth / 2;
            float ch = gdm.PreferredBackBufferHeight / 2;
            VertexPositionColor[] colors = new VertexPositionColor[] {
�@�@        new VertexPositionColor(new Vector3(-1f+x0/cw,1f-y0/ch,0),color),
�@�@        new VertexPositionColor(new Vector3(-1f+x1/cw,1f-y1/ch,0),color)
        };
            foreach (EffectPass pass in this.effect.CurrentTechnique.Passes) {
                pass.Apply();
                gdm.GraphicsDevice.DrawUserPrimitives(PrimitiveType.LineList, colors, 0, 1);
            }
        }

        //�|�����C���̕`��
        public void DrawPolyline(float[] x, float[] y) {
            float cw = gdm.PreferredBackBufferWidth / 2;
            float ch = gdm.PreferredBackBufferHeight / 2;
            VertexPositionColor[] colors = new VertexPositionColor[x.Length];
            for (int i = 0; i < x.Length; i++) {
                colors[i] = new VertexPositionColor(new Vector3(-1f + x[i] / cw, 1f - y[i] / ch, 0), color);
            }
            foreach (EffectPass pass in this.effect.CurrentTechnique.Passes) {
                pass.Apply();
                gdm.GraphicsDevice.DrawUserPrimitives(PrimitiveType.LineStrip, colors, 0, x.Length - 1);
            }
        }

        //��`�̕`��
        public void DrawRect(float x, float y, float w, float h) {
            float cw = gdm.PreferredBackBufferWidth / 2;
            float ch = gdm.PreferredBackBufferHeight / 2;
            VertexPositionColor[] colors = new VertexPositionColor[] {
            new VertexPositionColor(new Vector3(-1f+(x  )/cw,1f-(y  )/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x+w)/cw,1f-(y  )/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x+w)/cw,1f-(y+h)/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x  )/cw,1f-(y+h)/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x  )/cw,1f-(y  )/ch,0),color)
        };
            foreach (EffectPass pass in effect.CurrentTechnique.Passes) {
                pass.Apply();
                gdm.GraphicsDevice.DrawUserPrimitives(
                    PrimitiveType.LineStrip, colors, 0, 4);
            }
        }

        //�h��ׂ���`�̕`��
        public void FillRect(float x, float y, float w, float h) {
            float cw = gdm.PreferredBackBufferWidth / 2;
            float ch = gdm.PreferredBackBufferHeight / 2;
            VertexPositionColor[] colors = new VertexPositionColor[] {
            new VertexPositionColor(new Vector3(-1f+(x  )/cw,1f-(y  )/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x+w)/cw,1f-(y  )/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x+w)/cw,1f-(y+h)/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x  )/cw,1f-(y  )/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x+w)/cw,1f-(y+h)/ch,0),color),
            new VertexPositionColor(new Vector3(-1f+(x  )/cw,1f-(y+h)/ch,0),color)
        };
            foreach (EffectPass pass in effect.CurrentTechnique.Passes) {
                pass.Apply();
                gdm.GraphicsDevice.DrawUserPrimitives(
                    PrimitiveType.TriangleList, colors, 0, 2);
            }
        }

        //�e�L�X�g�̕`��
        public void DrawText(String text, float x, float y) {
            if (font == null) return;
            spBatch.Begin();
            spBatch.DrawString(font, text, new Vector2(x, y), color);
            spBatch.End();
        }

        //�C���[�W�̕`��
        public void DrawImage(Texture2D image, float x, float y) {
            if (image == null) return;
            Rectangle dst = new Rectangle((int)x, (int)y, image.Width, image.Height);
            Rectangle src = new Rectangle(0, 0, image.Width, image.Height);
            spBatch.Begin();
            spBatch.Draw(image, dst, src, Color.White, rotation, origin, flip, 0);
            spBatch.End();
        }

        //�C���[�W�̊g�k�`��
        public void DrawImage(Texture2D image, float x, float y, float w, float h) {
            if (image == null) return;
            Rectangle dst = new Rectangle((int)x, (int)y, (int)w, (int)h);
            Rectangle src = new Rectangle(0, 0, image.Width, image.Height);
            spBatch.Begin();
            spBatch.Draw(image, dst, src, Color.White, rotation, origin, flip, 0); ;
            spBatch.End();
        }

        //�C���[�W�̕����`��
        public void DrawImage(Texture2D image, float x, float y, float w, float h,
            float sx, float sy, float sw, float sh) {
            if (image == null) return;
            Rectangle dst = new Rectangle((int)x, (int)y, (int)w, (int)h);
            Rectangle src = new Rectangle((int)sx, (int)sy, (int)sw, (int)sh);
            spBatch.Begin();
            spBatch.Draw(image, dst, src, Color.White, rotation, origin, flip, 0);
            spBatch.End();
        }

    }
