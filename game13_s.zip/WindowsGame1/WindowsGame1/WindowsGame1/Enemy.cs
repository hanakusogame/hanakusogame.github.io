﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsGame1 {
    //敵クラス
    public class Enemy {
        //メンバ変数
        public int x, y, w, h;
        private bool muki;
        private int dx = 0;
        private int dy = 3;
        private int frame;
        public int type; //種類
        public bool dieFlg; //死亡フラグ
        private Random rnd;

        //コンストラクタ
        public Enemy(int x, int y) {
            rnd = new Random(x);
            type = rnd.Next(2);
            this.x = x;
            this.y = y;
            this.w = 16;
            this.h = 16;
        }

        //更新処理
        public void update(List<Block> bList) {
            frame++;

            //死亡判定
            if (frame == 1000) {
                dieFlg =true;
            }

            //移動処理
            int sp = 1;

            if (!muki) {
                dx = -sp;
            }
            if (muki) {
                dx = sp;
            }

            //ジャンプ中以外の処理
            //ジャンプ開始
            bool jmpFlg = bList.Exists(b => (x < b.x + b.w && b.x < x + w && y < b.y + b.h && b.y < y + h + 1));
            if (rnd.Next(60) == 0 && (jmpFlg || y >= (240-h))) {
                dy = -3;
            }

            x += dx;
            y += dy;

            //当たり判定
            bList.ForEach(b => collision(b));

            //画面からはみ出さないようにする
            if (x < 0) {
                x = 0;
                muki = !muki;
            }
            if (x + w > 320) {
                x = 320 - w;
                muki = !muki;
            }
            if (y < 0) {
                y = 0;
                dy = 3;
            }
            if (y + w > 240) y = 240 - h;
        }

        //当たり判定
        public void collision(Block b) {
            if (x < b.x + b.w && b.x < x + w && y < b.y + b.h && b.y < y + h) {

                //移動処理
                if (dy > 0) {
                    // ブロックの上端
                    if ((y + h) - b.y < b.dMax) {
                        y = b.y - h;

                        return;
                    }
                }

                if (dy < 0) {
                    // ブロックの下端
                    if ((b.y + b.h) - y < b.dMax) {
                        y = b.y + b.h;
                        dy = 3;
                        return;
                    }
                }

               if (dx > 0) {
                    // ブロックの左端
                    if ((x + w) - b.x < b.dMax) {
                        x = b.x - w;
                        muki = !muki;
                        return;
                    }
               }

               if (dx < 0) {
                    // ブロックの右端
                    if ((b.x + b.w) - x < b.dMax) {
                        x = b.x + b.w;
                        muki = !muki;
                        return;
                    }
                }
            }
        }

        //描画処理
        public void draw(Graphics g) {
            //塗り潰し矩形の描画
            if(type == 0) g.SetColor(0, 255, 0);
            else g.SetColor(255, 255, 0);
            g.FillRect(x, y, w, h);
        }
    }
}
