using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// アセンブリに関する全般的な情報は、以下の一連の属性によって管理されます。 
// アセンブリに関連付けられている情報を変更するには、これらの属性値を変更します。
// 
[assembly: AssemblyTitle("WindowsGame1")]
[assembly: AssemblyProduct("WindowsGame1")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright ©  2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// ComVisible 属性を false に設定すると、その型はこのアセンブリ内でCOM コンポーネントから 
// 参照不可能になります。COM からこのアセンブリ内の型にアクセスする場合は、 
// その型のComVisible 属性を true に設定してください。
// 
[assembly: ComVisible(false)]

// Windows 上では、このプロジェクトが COM に公開されている場合、
// 次の GUID が typelib の ID として設定されます。Windows 以外のプラットフォームでは、
// このアセンブリをデバイスに展開するときにタイトル ストレージ コンテナーを一意に識別するために使用します。
[assembly: Guid("13edcdf9-fdbe-4a08-be8c-57ed6d98f615")]

// アセンブリのバージョン情報は、次の 4 つの値で構成されています。
//
//      メジャー バージョン
//      マイナー バージョン 
//      ビルド番号
//      リビジョン
//
[assembly: AssemblyVersion("1.0.0.0")]
