﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsGame1 {
    //ステージ管理クラス
    class StageManager {
        private int bk_id;//????
        private int id;//現在のステージを示すid;
        private bool initFlg = false;//初期処理フラグ
        private List<Stage> sList = new List<Stage>();//ステージのリスト

        public StageManager() {
            //ステージ登録
            sList.Add(new Play());
            sList.Add(new Edit());
            setStage(0);
        }

        //現在のステージで最初から
        public void setThisStage() {
            initFlg = false;
        }

        //次のステージへ
        public void setNextStage() {
            if (id < (sList.Count - 1)) {
                bk_id++;
            }
            initFlg = false;
        }

        //前のステージへ
        public void setPrevStage() {
            if (id > 0) {
                bk_id--;
            }
            initFlg = false;
        }

        //指定されたステージへ
        public void setStage(int id) {
            if (this.id != id && id < sList.Count) {
                bk_id = id;
                initFlg = false;
            }
        }

        //更新処理
        public void update(KeyManager km,SaveFile sf) {
            if (!initFlg) {
                id = bk_id;
                sList[id].init(sf);//初期処理
                initFlg = true;
            }
            sList[id].update(this,km,sf);
        }

        //描画処理
        public void draw(Graphics g) {
             sList[id].draw(g);
        }
    }
}
