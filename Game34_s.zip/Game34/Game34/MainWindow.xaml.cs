﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Reflection;
using System.IO.MemoryMappedFiles;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace Game34 {
    public partial class MainWindow : Window {
        Polyline polylineLeft;
        Polyline polylineRight;

        MediaPlayer player = new MediaPlayer();

        Stopwatch sw = new Stopwatch();

        int pos = 0;

        private WaveManager wm = new WaveManager();

        string fileName;

        Line myLine;
        double spS, spE;

        public MainWindow() {
            InitializeComponent();

            polylineLeft = new Polyline();
            polylineLeft.Stroke = Brushes.Red;
            polylineLeft.StrokeThickness = 2;

            polylineRight = new Polyline();
            polylineRight.Stroke = Brushes.Cyan;
            polylineRight.StrokeThickness = 2;

            canvasWave.Children.Add(polylineLeft);
            canvasWave.Children.Add(polylineRight);

            player.MediaEnded += player_MediaEnded;
            CompositionTarget.Rendering += CompositionTarget_Rendering;

            myLine = new Line();
            myLine.Stroke = Brushes.White;
            myLine.StrokeThickness = 2;
            myLine.X1 = 10; myLine.Y1 = 165; myLine.X2 = 210; myLine.Y2 = 165;
            canvas.Children.Add(myLine);

        }

        void CompositionTarget_Rendering(object sender, EventArgs e) {
            if (sw.IsRunning) {
                labelRecord.Content = sw.Elapsed.ToString("G").Substring(5, 8);
            }

            if (buttonPlay.Content.ToString() == "Pause") {
                sliderTime.Value = player.Position.TotalSeconds;
            }
        }

        void player_MediaEnded(object sender, EventArgs e) {
            player.Close();
            sliderTime.Value = 0;
            buttonPlay.Content = "Play";
        }

        //wavファイルを開くダイアログボックス
        public string FileOpen() {
            Assembly myAssembly = Assembly.GetEntryAssembly();
            string path = myAssembly.Location;
            int i = path.LastIndexOf('\\');
            path = path.Remove(i);

            // Configure open file dialog box
            OpenFileDialog dlg = new OpenFileDialog();
            //dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".wav"; // Default file extension
            dlg.Filter = "WaveFile|*.wav"; // Filter files by extension
            dlg.InitialDirectory = path;

            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true) {
                // Open document
                return dlg.FileName;
            }
            else {
                return null;
            }
        }

        //波形表示
        private void drawWave(int index) {
            WaveInfo wave = wm.waveList[listBox.SelectedIndex];
            int span = (wave.bitSample / 8 * wave.Cannel);
            BinaryReader r = new BinaryReader(wave.ms);
            wave.ms.Position = index * span;
            polylineLeft.Points.Clear();
            polylineRight.Points.Clear();
            for (int x = 0; x < 200; x++) {
                if (wave.ms.Position >= wave.byteSize - span) { break; }
                if (wave.bitSample == 16) {
                    double y1 = r.ReadInt16() / 512 + 64;
                    polylineRight.Points.Add(new Point(x, y1));
                    //ステレオ
                    if (wave.Cannel == 2) {
                        double y2 = r.ReadInt16() / 512 + 64;
                        polylineLeft.Points.Add(new Point(x, y2));
                    }
                }
                else {
                    double y1 = r.ReadByte() / 2;
                    polylineRight.Points.Add(new Point(x, y1));
                    //ステレオ
                    if (wave.Cannel == 2) {
                        double y2 = r.ReadByte() / 2;
                        polylineLeft.Points.Add(new Point(x, y2));
                    }
                }
            }
        }

        //リストボックス更新
        private void updateListBox(int i) {
            listBox.Items.Clear();
            wm.waveList.ForEach(w => listBox.Items.Add(w.fileName));
            listBox.SelectedIndex = i;
        }

        //ファイルから開く
        private void Button_Click_1(object sender, RoutedEventArgs e) {
            fileName = FileOpen();
            if (fileName != null) {
                if (wm.create(fileName)) {
                    updateListBox(wm.waveList.Count - 1);
                }
            }
        }

        //キーボードイベント
        private void Window_KeyDown_1(object sender, KeyEventArgs e) {
            if (e.Key == Key.I) {
                if (label.Visibility == Visibility.Visible) {
                    label.Visibility = Visibility.Hidden;
                }else
                {
                    label.Visibility = Visibility.Visible;
                }
            }

            if (e.Key == Key.Z) {
                WaveInfo wi = wm.waveList[listBox.SelectedIndex];
                if (wm.waveList.Count != 0) {
                    if (pos < wi.byteSize - 1) {
                        pos++;
                        drawWave(pos);
                    }
                }
            }

            if (e.Key == Key.X) {
                if (wm.waveList.Count != 0) {
                    if (pos > 0) {
                        pos--;
                        drawWave(pos);
                    }
                }
            }

        }


        //再生
        private void buttonPlay_Click(object sender, RoutedEventArgs e) {
            if (buttonPlay.Content.ToString() == "Play") {
                int i = listBox.SelectedIndex;
                if (i != -1) {
                    if (wm.waveList[i].save("tmp.wav")) {
                        player.Open(new Uri(@"tmp.wav", UriKind.Relative));
                        player.Position = new TimeSpan((long)(sliderTime.Value * 10000000));
                    }
                    player.Position = new TimeSpan((long)(sliderTime.Value * 10000000));
                    player.Play();
                    buttonPlay.Content = "Pause";
                }
            }
            else if (buttonPlay.Content.ToString() == "Pause") {
                player.Pause();
                buttonPlay.Content = "Play";
            }
        }

        //停止
        private void buttonStop_Click(object sender, RoutedEventArgs e) {
            player.Stop();
            player.Close();
            sliderTime.Value = 0;
            buttonPlay.Content = "Play";
        }

        private void drawSelectArea() {
            myLine.X1 = spS / sliderTime.Maximum * 200 + 10;
            myLine.X2 = spE / sliderTime.Maximum * 200 + 10;
        }

        private void buttonPosStart_Click(object sender, RoutedEventArgs e) {
            spS = sliderTime.Value;
            drawSelectArea();
        }

        private void ButtonPosEnd_Click(object sender, RoutedEventArgs e) {
            spE = sliderTime.Value;
            drawSelectArea();
        }

        //作成
        private void buttonCreate_Click(object sender, RoutedEventArgs e) {
            if (wm.newCreate(2)) {
                updateListBox(wm.waveList.Count - 1);
            }
        }

        //保存
        private void buttonSave_Click(object sender, RoutedEventArgs e) {
            wm.waveList[0].save(@"testWave.wav");
        }

        //削除
        private void buttonDel_Click(object sender, RoutedEventArgs e) {
            if (listBox.SelectedIndex != -1) {
                wm.derete(listBox.SelectedIndex);
                updateListBox(-1);
            }
        }

        //録音開始
        private void buttonRecord_Click(object sender, RoutedEventArgs e) {
            if (!sw.IsRunning) {
                buttonRecord.Content = "Stop";
                wm.recordStart();
                sw.Restart();
            }
            else {
                sw.Stop();
                if (wm.recordEnd()) {
                    updateListBox(wm.waveList.Count - 1);
                }
                buttonRecord.Content = "Start";
            }
        }

        //選択変更
        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (listBox.SelectedIndex != -1) {
                WaveInfo wi = wm.waveList[listBox.SelectedIndex];
                label.Content = wi.getStrInfo();
                double time = (double)wi.byteSize / wi.byteSec;
                sliderTime.Maximum = time;
                sliderTime.Value = 0;
                drawWave(0);
                label.Content = wm.waveList[listBox.SelectedIndex].getStrInfo();
                spS = 0; spE = sliderTime.Maximum; drawSelectArea();
                player.Close();
            }
        }

        //スライダー位置変更時
        private void Slider_ValueChanged_1(object sender, RoutedPropertyChangedEventArgs<double> e) {
            int i = listBox.SelectedIndex;
            if (i != -1) {
                TimeSpan ts = new TimeSpan((long)(sliderTime.Value * 10000000));
                labelTime.Content = ts.ToString("G").Substring(5, 8);
                drawWave((int)(sliderTime.Value * wm.waveList[i].rate));
            }
        }

        private void buttonMute_Click(object sender, RoutedEventArgs e) {
            int i = listBox.SelectedIndex;
            if (i != -1) {
                wm.waveList[i].mute(spS, spE);
            }
        }
    }
}
