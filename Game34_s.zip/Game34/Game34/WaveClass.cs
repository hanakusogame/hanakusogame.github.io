﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;

namespace Game34 {
    class WaveInfo {
        //ファイル名
        public string fileName = "NoName.wav";

        //ヘッダー
        public string riffHead = "RIFF";
        public uint riffSize = 38;
        public string waveHead = "WAVE";
        public string fmtCank = "fmt ";
        public uint fmtCankSize = 16;
        public ushort formatId = 1;
        public ushort Cannel = 2;
        public uint rate = 44100;
        public uint byteSec = 176400;
        public ushort blockSize = 2;
        public ushort bitSample = 16;
        public string dataCank = "data";
        public uint byteSize = 0;

        //メモリ情報
        public MemoryStream ms = new MemoryStream();

        //情報取得
        public string getStrInfo() {
            return
            (
               "fileName   :" + fileName + "\n" +
               "riffHead   :" + riffHead + "\n" +
               "riffSize   :" + riffSize + "\n" +
               "waveHead   :" + waveHead + "\n" +
               "fmtCank    :" + fmtCank + "\n" +
               "fmtCankSize:" + fmtCankSize + "\n" +
               "formatId   :" + formatId + "\n" +
               "Cannel     :" + Cannel + "\n" +
               "rate       :" + rate + "\n" +
               "byteSec    :" + byteSec + "\n" +
               "blockSize  :" + blockSize + "\n" +
               "bitSample  :" + bitSample + "\n" +
               "dataCank   :" + dataCank + "\n" +
               "byteSize   :" + byteSize + "\n"
            );
        }

        //ファイルに保存
        public bool save(string fileName) {
            try {
                using (BinaryWriter w = new BinaryWriter(File.OpenWrite(fileName), Encoding.ASCII)) {
                    w.Write(Encoding.ASCII.GetBytes(riffHead));
                    w.Write(riffSize);
                    w.Write(Encoding.ASCII.GetBytes(waveHead));
                    w.Write(Encoding.ASCII.GetBytes(fmtCank));
                    w.Write(fmtCankSize);
                    w.Write(formatId);
                    w.Write(Cannel);
                    w.Write(rate);
                    w.Write(byteSec);
                    w.Write(blockSize);
                    w.Write(bitSample);
                    w.Write(Encoding.ASCII.GetBytes(dataCank));
                    w.Write(byteSize);
                    ms.Position = 0;
                    while (ms.Length > ms.Position) {
                        w.Write((byte)ms.ReadByte());
                    }
                }
            }
            catch {
                return false;
            }
            return true;
        }

        //消音
        public void mute(double s, double e) {
            BinaryWriter r = new BinaryWriter(ms);
            ms.Position = ((int)(s * byteSec) / blockSize * blockSize);
            int ep = ((int)(e * byteSec) / blockSize) - ((int)(s * byteSec) / blockSize);
            for (int i = 0; i < ep; i++) {
                r.Write((short)0);
                r.Write((short)0);
            }
        }
    }

    class WaveManager {
        public List<WaveInfo> waveList = new List<WaveInfo>();

        private BinaryReader r;

        [DllImport("winmm.dll")]
        private static extern int mciSendString(string command, StringBuilder buf, int bufsize, IntPtr hwndCallback);

        private string getStr(int size) {
            string s = "";
            for (int i = 0; i < size; i++) { s = s + (char)r.ReadByte(); }
            return s;
        }

        //新規作成
        public bool newCreate(int sec) {
            WaveInfo wave = new WaveInfo();
            wave.riffSize += (uint)(wave.byteSec * sec);
            wave.byteSize = (uint)(wave.byteSec * sec);
            //wave.ms.Capacity = (int)();
            BinaryWriter w = new BinaryWriter(wave.ms);
            while (wave.ms.Position < wave.byteSec * sec) {
                if (wave.ms.Position / 200 % 2 == 1) {
                    w.Write((short)1000);
                }
                else {
                    w.Write((short)-1000);
                }
            }
            Console.WriteLine("" + wave.ms.Length);
            waveList.Add(wave);
            return true;
        }

        //ファイルから開く
        public bool create(string filePath) {
            WaveInfo wave = new WaveInfo();
            using (FileStream fs = new FileStream(filePath, FileMode.Open)) {
                if (fs.Length < 44) return false;
                wave.fileName = filePath.Substring(filePath.LastIndexOf('\\') + 1);
                BinaryWriter w = new BinaryWriter(wave.ms);
                r = new BinaryReader(fs);
                wave.riffHead = getStr(4);
                wave.riffSize = r.ReadUInt32();
                wave.waveHead = getStr(4);
                wave.fmtCank = getStr(4);
                wave.fmtCankSize = r.ReadUInt32();
                wave.formatId = r.ReadUInt16();
                wave.Cannel = r.ReadUInt16();
                wave.rate = r.ReadUInt32();
                wave.byteSec = r.ReadUInt32();
                wave.blockSize = r.ReadUInt16();
                wave.bitSample = r.ReadUInt16();
                string s;
                while (true) {
                    s = getStr(4);
                    if (s == "data") {
                        wave.dataCank = s;
                        wave.byteSize = r.ReadUInt32();
                        break;
                    }
                    else if (s == "LIST" || s == "fact") {
                        uint i = r.ReadUInt32();
                        fs.Position += i;//いらないので飛ばす。
                    }
                    else { break; }
                }
                if (wave.byteSize == 0) return false;
                int amari = 0;
                int rate = 8000;
                if (wave.rate == rate && wave.Cannel == 2 && wave.bitSample == 16) {
                    fs.CopyTo(wave.ms);
                }
                else{
                    while (true) {
                        short sh1,sh2;
                        if (wave.bitSample == 16) { sh1 = r.ReadInt16();}
                        else{ sh1 = (short)(((int)r.ReadByte() - 128) * 256);}

                        if (wave.Cannel == 2) {
                            if (wave.bitSample == 16) { sh2 = r.ReadInt16();}
                            else { sh2 = (short)(((int)r.ReadByte() - 128) * 256); }
                        }
                        else { sh2 = sh1;}

                        for (int i = 0; i < ((rate + amari) / wave.rate); i++) {
                            w.Write(sh1); w.Write(sh2);
                        }

                        amari = (rate + amari) % (int)wave.rate;
                        if (fs.Position == fs.Length) { break; }
                    }
                }
                wave.rate = (uint)rate;
                wave.Cannel = 2;
                wave.byteSec = wave.rate * 4;
                wave.blockSize = 4;
                wave.bitSample = 16;
                wave.byteSize = (uint)wave.ms.Length;
                wave.riffSize = (uint)wave.ms.Length + 36;

                waveList.Add(wave);//追加
            }
            return true;
        }

        //削除
        public bool derete(int i) {
            waveList.RemoveAt(i);
            return true;
        }

        //録音
        public bool recordStart() {
            string set = "channels 2 samplespersec 8000 alignment 2 bitspersample 16";
            int i = 0;
            i = mciSendString("open new type waveaudio alias Rec", null, 0, IntPtr.Zero);
            Console.WriteLine("" + i);
            i = mciSendString("set Rec " + set, null, 0, IntPtr.Zero);
            Console.WriteLine("" + i);
            i = mciSendString("record Rec", null, 0, IntPtr.Zero);
            Console.WriteLine("" + i);

            return true;
        }

        //録音停止
        public bool recordEnd() {
            string fileName = @"Rec.wav";
            mciSendString("stop Rec", null, 0, IntPtr.Zero);
            mciSendString("save Rec " + fileName, null, 0, IntPtr.Zero);
            mciSendString("close Rec", null, 0, IntPtr.Zero);
            create(@"Rec.wav");

            return true;
        }
        
    }
}
