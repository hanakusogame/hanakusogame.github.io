﻿open Microsoft.Xna.Framework;
open Microsoft.Xna.Framework.Input;

//2Dポイント構造体
type p2d =
    struct
        val mutable X: int
        val mutable Y: int
        new(x: int, y: int) = { X = x; Y = y }
    end

//ゲームクラス
type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定

    //メンバ変数的なもの
    let g = new G.MyGraphics(this,320,240)
    let mutable array = Array2D.zeroCreate 13 13
    let mutable pos = [ p2d(6,6) ] //位置
    let mutable move = 4 //移動向き
    let mutable cnt = 0 //フレームカウンタ
    let mutable score = 0 //スコア
    let mutable hiscore = 0
    let mutable dieFlg = false //死亡フラグ
    let rnd = new System.Random () //ランダムな値
    let mutable speed = 0;

    //色テーブル
    let c = [| Color.Black ; Color.Lime ; Color.Magenta ; Color.Yellow ; Color.Blue ; Color.Red |]
    //キーテーブル
    let key = [| Keys.Up ; Keys.Left ; Keys.Right ; Keys.Down ; Keys.Space |]
    //向き(移動量)テーブル
    let muki = [| p2d(0,-1) ; p2d(-1,0) ; p2d(1,0) ; p2d(0,1) ; p2d(0,0)|]

    //初期化
    let init () =
        array <- Array2D.zeroCreate 13 13
        array.[6,6] <- 1
        move <- 4
        cnt <- 0
        score <- 0
        pos <- [ p2d(6,6) ]
        speed <- 0
        dieFlg <- false

    //コンテンツ登録
    override this.LoadContent() =
        init ()
        g.LoadContent()

    //ゲームロジック
    override this.Update gametime =
        km.setKey()//キー取得
        //終了処理
        if km.kIsPush(Keys.Escape) then base.Exit()
        
        //死亡時以外
        if dieFlg = false then
            //方向キーが押されたら向き変更
            for i = 0 to 3 do
                if km.kIsPush(key.[i]) then
                    move <- i
        
            //移動処理
            if cnt % (30-(speed*3)) = 0 && move <> 4 then
                //移動先の位置取得
                let newX = pos.Item(pos.Length-1).X + muki.[move].X
                let newY = pos.Item(pos.Length-1).Y + muki.[move].Y

                //移動範囲内かつ自分の体にぶつかっていない
                if newX >= 0 && newX < 13 && newY >= 0 && newY < 13 && array.[newX,newY] <> 1 then
                    
                    //スピードアップアイテムを取ったとき
                    if array.[newX,newY] = 3 then
                        score <- score + 1
                        speed <- speed + 1

                    //えさを取ったとき
                    if array.[newX,newY] = 2 then score <- score + 1


                    //えさを取ったとき以外
                    if array.[newX,newY] <> 2 then
                        //表示用配列から削除（しっぽ）
                        array.[ pos.Head.X, pos.Head.Y ] <- 0

                        //尻尾を消す
                        pos <- pos.Tail
            
                    //頭を足す
                    pos <- pos @ [p2d(newX, newY)]

                    //表示用配列に追加（頭の部分）
                    array.[ newX, newY ] <- 1

                //死亡の瞬間
                else
                    for i in pos do
                        array.[i.X, i.Y] <- 5
                    if score > hiscore then hiscore <- score
                    dieFlg <- true
            
            //壁発生
            if cnt % 500 = 0 && move <> 4 then
                let x = rnd.Next(13)
                let y = rnd.Next(13)
                if array.[ x, y ] <> 1 then
                    array.[ x, y ] <- 1

            //アイテム発生
            if cnt % 200 = 0 && move <> 4 then
                let x = rnd.Next(13)
                let y = rnd.Next(13)
                if array.[ x, y ] <> 1 then
                    array.[ x, y ] <- rnd.Next(2,4)

        //死亡時
        else
            for i = 0 to 4 do
                if km.kIsPush(key.[i]) then
                    init()
            
        cnt <- cnt+1 //フレームカウント
        base.Update gametime
        
    //描画処理
    override this.Draw gametime =
        g.Clear(Color.White)//画面のクリア

        //ゲーム画面の描画
        Array2D.iteri (fun x y a -> g.FillRect( x*16, y*16, 15, 15, c.[a] )) array

        //情報描画
        g.SetColor(Color.Black)
        g.DrawTextM("<へびゲーム>",208,0)
        g.DrawTextM("スピード:" + (string)speed,208,20)
        g.DrawTextM("スコア:" + (string)score,208,40)
        g.SetColor(Color.Red)
        if dieFlg then g.DrawTextM("ゲームオーバー",208,60)
        g.SetColor(Color.Black)
        g.DrawTextS("<そうさほうほう>",208,100)
        g.DrawTextS(" やじるしキー:いどう",208,110)
        g.DrawTextS(" ESCキー:おわる",208,120)
        g.DrawTextS("<アイテム>",208,140)
        g.DrawTextS(" みどり:あたるとしぬ",208,150)
        g.DrawTextS(" きいろ:スピードアップ",208,160)
        g.DrawTextS(" ピンク:ながくなる",208,170)
        g.DrawTextM("ハイスコア:" + (string)hiscore,180,220)
        
        base.Draw gametime

[<EntryPoint>]//プログラム開始位置
let main(args : string[]) =
    let game = new MyGame()
    game.Run()
    game.Dispose()
    0
