﻿//その他いろいろ置いておく（メモ的に使う）
module etc

open System.IO;
open System.Runtime.Serialization.Formatters.Binary;

//ファイル入出力処理(クラス等のシリアライズ)
//引用元→http://fsharpandenglishword.blog83.fc2.com/blog-entry-131.html
let saveValue filename x = 
    use stream = new FileStream(filename,FileMode.Create) 
    (new BinaryFormatter()).Serialize(stream,box x)
    
let loadValue filename =
    use stream = new FileStream(filename,FileMode.Open)
    (new BinaryFormatter()).Deserialize(stream) |> unbox

//-------------ここから完全にメモ---------------
(*

//ランダムな値
let rnd = new System.Random ()

//ファイルからテクスチャ作成
use stream2 = new FileStream("xxx.png",FileMode.Open)
texture = Texture2D.FromStream(this.GraphicsDevice,stream1)


//今回ちょっといらなそうなので退避
    //初期化
    //override  this.Initialize() =
        //base.Initialize()

    //コンテンツ破棄
    //override this.UnloadContent() =

//-----------ゲームクラス基本-------------------
open Microsoft.Xna.Framework;
open Microsoft.Xna.Framework.Graphics;

type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定

    //メンバ変数的なもの
    let g = new G.MyGraphics(this,320,240)

    //コンテンツ登録
    override this.LoadContent() =
        g.LoadContent()

    //ゲームロジック
    override this.Update gametime =
        km.setKey()//キー取得
        base.Update gametime
        
    //描画処理
    override this.Draw gametime =
        g.Clear(Color.Black)//画面のクリア

        base.Draw gametime

[<EntryPoint>]//プログラム開始位置
let main(args : string[]) =
    let game = new MyGame()
    game.Run()
    game.Dispose()
    0
//-------------ここまで-----------------------------------

////////////////////Ａ＊アルゴリズム使用例///////////////////
open Astar
open System

//A*関数を使用する例

//コストや障害物を加味しない最短距離を返す
//Point -> Point -> int
let inline heuristic (x, y) (u, v) = max (abs (x - u))  (abs (y - v))

//探索する位置のシークエンスを作成する関数(通行不可な場所はこれで除外)
// Map -> Point -> Set<Point> 
let inline successor m (x,y) = 
    set[for u in  [x + 1; x; x - 1] do
        for v in  [y + 1; y; y - 1] do
            if (0 <= u && u < List.length m 
                && 0 <= v && v < List.length (List.head m)) 
                && (u <> x || y <> v) 
                && (List.nth (List.nth m u) v <> '~') then
                    yield set [u, v]
        ]
    |> Set.unionMany

//渡された文字のある場所の座標を返す
//char -> Map -> Point
let inline find c =
      let rec inner x m = 
          match m with
          | [] ->  failwith "Can't find tile."
          | h :: t -> 
              match List.tryFindIndex (fun item -> item = c) h with
              | Some y -> x, y
              | otherwise -> inner (x+1) t
      inner 0

//文字列リストの最短距離に'#'を付けて返す
// char list list -> Point list -> char list list
let inline path m l = 
       List.mapi (fun idx ht ->
           List.mapi (fun idy c->
               if List.exists (fun (n', m') -> (n', m') = (idx, idy)) l then '#' else c) ht) m

//ソースから最短経路を取得して経路を描画したリストを返す
let inline run s =
      //ソースをリストに変換
      let m = List.map (fun (str : string) ->List.ofSeq str) s
      let start = find 'S' m //スタート位置
      let finish = find 'F' m //ゴール位置
      let succ = successor m //探索する位置を指定する関数(除外する文字の場所はこれで除外)
      let h     = heuristic finish //ゴールまでのコスト無視の最短距離を求める関数
      //指定位置のコストを返す関数
      let cost (x, y) = 
          let costs = Map.ofList [('S',1);('F',1);('.',1);('*',2);('^',7)]
          List.nth m x 
          |> AstarTypes.flip List.nth y
          |> AstarTypes.flip Map.find costs
      printfn "%d" (h(0,5))
 
      path m (AstarImpl.astar start succ ((=) finish) cost h)

//ソースとなるリスト
let input =
    [ "..*...";
     "*^*^~.";
     "*~*^.~";
     "^^^^~^";
     "^~^~.~";
     "~~^~~.";
     "F*~*~S";]
printfn "Input Map :"
List.iter (fun x -> printfn "%A" (List.ofSeq x))  input

let res = run input

printfn " Path "
List.iter (fun x -> printfn "%A" x)  res

////////////////////////ここまで//////////////////////////////////////////////

*)