﻿//Game20
open System
open Microsoft.Xna.Framework
open Microsoft.Xna.Framework.Graphics
open Microsoft.Xna.Framework.Input
open System.Collections.Generic
open Astar

//範囲内にあるか関数
let limitVal i min max = i >= min && i < max
let limitPos x y minx miny maxx maxy = limitVal x minx maxx && limitVal y miny maxy

//Point -> Point -> int　コストや障害物を加味しない最短距離を返す
let inline heuristic (x, y) (u, v) = max (abs (x - u))  (abs (y - v))

//探索する位置のシークエンスを作成する関数(通行不可な場所はこれで除外)
let inline successor (arr : int[,]) (x,y)  =
    let chkList =  [(x,y-1);(x+1,y);(x,y+1);(x-1,y)]
    //斜めも必要なとき足す;(x-1,y-1);(x+1,y-1);(x-1,y+1);(x+1,y+1)
    set[for u,v in chkList do
        if limitPos u v 0 0 (arr.GetLength(0)) (arr.GetLength(1)) then
            if arr.[u,v] <> 0 then//0は通行不可能とする
                yield set [u, v]
       ]
    |> Set.unionMany


//ソースから最短経路を取得して経路を描画したリストを返す
let inline run (arr:int[,]) (x,y)=
      let start = (17,12) //スタート位置
      let finish = (x,y) //ゴール位置
      let succ = successor arr//探索する位置を指定する関数(除外する文字の場所はこれで除外)
      let h     = heuristic finish //ゴールまでのコスト無視の最短距離を求める関数    
      let cost (x, y) = arr.[x,y]//指定位置のコストを返す関数
 
      AstarImpl.astar start succ ((=) finish) cost h

//敵レコード
type Enemy =
    {
        mutable pos:(int*int)list ;
        t:int ;
        mutable cnt:int
    }

//ゲームクラス
type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定

    //メンバ変数的なもの
    let g = new G.MyGraphics(this,320,240)
    let mutable px,py = 0,0 //マウス位置
    let mutable mx,my = 18,13 //マップサイズ
    let pSize = 16          //マップチップサイズ
    let mutable id = 0
    let array = Array2D.create mx my 1
    let mutable tes = []
    let enemy = new List<Enemy>()//敵リスト(可変リスト)
    let rnd = new System.Random ()//ランダム
    let mutable cnt = 0 //フレームカウンタ
    let mutable initFlg = false
    let mutable score = 0
    let mutable hiscore = 0
    let limitScr() = limitPos px py 0 0 320 240

    //初期化
    let init () =
        if score > hiscore then hiscore <- score
        score <- 0
        Array2D.iteri (fun x y _ -> array.[x,y] <- 1) array
        enemy.Clear()
        initFlg <- true

    //コンテンツ登録
    override this.LoadContent() =
        g.LoadContent()

    //ゲームロジック
    override this.Update gametime =
        km.setKey()//キー取得
        px <- km.ms.X; py <- km.ms.Y //マウス位置取得

        if km.kIsPush(Keys.Escape) then this.Exit()//終了処理
        
        if not initFlg then
            //初期化
            if km.mIsPush(0) && limitScr() then init()

        else

            //敵発生
            if cnt%130 = 0 then
                let pList = run array (0,0)
                if pList <> [] then
                    enemy.Add({pos = pList; t=rnd.Next(2); cnt = 0})
                else
                    initFlg <- false
            
            //削除処理の中で更新処理をするという荒業
            enemy.RemoveAll(fun e ->
                e.cnt <- e.cnt+1//フレームカウンタ

                //移動処理
                if e.cnt%20 = 0 then
                    let x,y = e.pos.Head
                    let mutable pos = e.pos
                    if array.[x,y] <> 0 then //直接クリック消し攻撃に対応
                        pos <- run array (x,y)
                        
                    if pos <> [] && pos.Tail <> [] then
                        e.pos <- pos.Tail
                        let x,y = e.pos.Head
                        //ゴール地点到達
                        if x = 17 && y = 12 then
                            if e.t = 0 then initFlg <- false    //ピンクだったら死亡
                            else score <- score + 1 //黄色だったらスコアを増やす
                        false
                    else
                        true
                else false
            )|> ignore


            //壁設置
            if km.mIsDown(0) then
                if limitPos (px/pSize) (py/pSize) 0 0 mx my then
                    array.[px/pSize,py/pSize] <- 0

            //壁削除
            if km.mIsDown(1) then
                if limitPos (px/pSize) (py/pSize) 0 0 mx my then
                    array.[px/pSize,py/pSize] <- 1

        cnt <- cnt + 1
        base.Update gametime
        
    //描画処理
    override this.Draw gametime =
        g.Clear(Color.Black)//画面のクリア

        //この辺はぐちゃぐちゃすぎてわからなくなった。
        let c = [|Color.Black; Color.Green; Color.Yellow|]
        Array2D.iteri (fun x y i -> g.FillRect(pSize*x, pSize*y, pSize-1, pSize-1, c.[i]) ) array
        g.DrawRect(px/pSize*pSize, py/pSize*pSize, pSize-1, pSize-1, Color.White)

        let c = [|Color.Magenta; Color.Yellow|]
        g.SetColor(Color.Yellow)
        enemy.ForEach(fun e -> g.FillRect((fst e.pos.Head)*16,(snd e.pos.Head)*16,pSize-1, pSize-1, c.[e.t]))
        g.DrawTextS("スタート",0,0,Color.White)
        g.DrawTextS("ゴール" ,270,190,Color.White)

        g.DrawTextS("ハイスコア:" + hiscore.ToString(),220,210,Color.Cyan)
        g.DrawTextM("スコア:" + score.ToString(),220,220,Color.Lime)
        if not initFlg then
            g.DrawTextM("ゲームオーバー",0,220,Color.Magenta)
        else g.DrawTextM("かこいゲーム",0,220,Color.White)

        base.Draw gametime

[<EntryPoint>]//プログラム開始位置
let main(args : string[]) =
    let game = new MyGame()
    game.Run()
    game.Dispose()
    0

