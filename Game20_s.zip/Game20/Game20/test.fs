﻿open Astar
open System

//A*関数を使用する例

//コストや障害物を加味しない最短距離を返す
//Point -> Point -> int
let inline heuristic (x, y) (u, v) = max (abs (x - u))  (abs (y - v))

//探索する位置のシークエンスを作成する関数(通行不可な場所はこれで除外)
// Map -> Point -> Set<Point> 
let inline successor m (x,y) = 
    set[for u in  [x + 1; x; x - 1] do
        for v in  [y + 1; y; y - 1] do
            if (0 <= u && u < List.length m 
                && 0 <= v && v < List.length (List.head m)) 
                && (u <> x || y <> v) 
                && (List.nth (List.nth m u) v <> '~') then
                    yield set [u, v]
        ]
    |> Set.unionMany

//渡された文字のある場所の座標を返す
//char -> Map -> Point
let inline find c =
      let rec inner x m = 
          match m with
          | [] ->  failwith "Can't find tile."
          | h :: t -> 
              match List.tryFindIndex (fun item -> item = c) h with
              | Some y -> x, y
              | otherwise -> inner (x+1) t
      inner 0

//文字列リストの最短距離に'#'を付けて返す
// char list list -> Point list -> char list list
let inline path m l = 
       List.mapi (fun idx ht ->
           List.mapi (fun idy c->
               if List.exists (fun (n', m') -> (n', m') = (idx, idy)) l then '#' else c) ht) m

//ソースから最短経路を取得して経路を描画したリストを返す
let inline run s =
      //ソースをリストに変換
      let m = List.map (fun (str : string) ->List.ofSeq str) s
      let start = find 'S' m //スタート位置
      let finish = find 'F' m //ゴール位置
      let succ = successor m //探索する位置を指定する関数(除外する文字の場所はこれで除外)
      let h     = heuristic finish //ゴールまでのコスト無視の最短距離を求める関数
      //指定位置のコストを返す関数
      let cost (x, y) = 
          let costs = Map.ofList [('S',1);('F',1);('.',1);('*',2);('^',7)]
          List.nth m x 
          |> AstarTypes.flip List.nth y
          |> AstarTypes.flip Map.find costs
      printfn "%d" (h(0,5))
 
      path m (AstarImpl.astar start succ ((=) finish) cost h)

//ソースとなるリスト
let input =
    [ "..*...";
     "*^*^~.";
     "*~*^.~";
     "^^^^~^";
     "^~^~.~";
     "~~^~~.";
     "F*~*~S";]
printfn "Input Map :"
List.iter (fun x -> printfn "%A" (List.ofSeq x))  input

let res = run input

printfn " Path "
List.iter (fun x -> printfn "%A" x)  res

