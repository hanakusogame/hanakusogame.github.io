﻿module Edit

open System.Windows.Forms
open System.Drawing
open System.Collections.Generic
open System.Text.RegularExpressions

open MyGraphics
open MyLoop
open MyInput
open MyForm
open KeyToStr
open MyIME
open MyIO

type Edit() =
    let mutable dx,dy = 0,0 //表示位置
    let mutable cx,cy = 0,0 //カーソル位置
    let mutable bkx,bky = 0,0 //カーソル位置バックアップ用
    let mutable baseStr = ""
    let mutable sList = new List<string>()//表示文字列
    let mutable cStr = "" //コピー中文字列
    let mutable fileName = ""
    let mutable searchList = [] //検索で見つかった位置リスト
    let mutable searchStr = ""
    let mutable replaceS = ""
    let mutable replaceD = ""
    let kc = new KeysConverter()
    let mutable maxX,maxY = 38,12
    let mutable mode = 0
    let ime = new MyIME()

    //マウス位置からカーソル位置設定
    let setMouseCur(mx,my) =
        let y =
            if my / 16 + dy < sList.Count then
                my / 16 + dy
            else
                sList.Count - 1

        let x =
            if mx / 8  + dx < sList.[y].Length then
                mx / 8  + dx
            else
                sList.[y].Length
        x,y

    //選択範囲逆転
    let revSPos(sx,sy,dx,dy) =
        if sy > dy || ( sy = dy && sx > dx )then
            dx,dy,sx,sy
        else
            sx,sy,dx,dy

    //カーソル位置から文字位置取得
    let getMPos(cx,cy) =
        let mutable p = 0
        for i = 0 to cy - 1 do
            p <- p + sList.[i].Length + 1
        p + cx

    //カーソル位置のはみ出し補正
    let revisionCor() =
        if cy > maxY + dy then dy <- cy - maxY
        elif cy < dy      then dy <- cy
        if cx > maxX + dx then dx <- cx - maxX
        elif cx < dx      then dx <- cx

    //カーソル位置変更
    let setCor(x,y) =
        cx <- x ; bkx <- x
        cy <- y ; bky <- y

    let setSCor(x,y) =
        cx <- x ; cy <- y

    let setBCor(x,y) =
        bkx <- x ; bky <- y

    //文字位置からカーソル位置設定
    let getCPos(i) =
        let s = baseStr.Substring(0,i)
        let a = s.Split('\n')
        a.[a.Length-1].Length , a.Length - 1 

    //カーソル上移動
    let moveUp() =
        if cy > 0 then
            let y = cy - 1
            if cx > ( sList.[y].Length ) then
                setCor(sList.[y].Length , y)
            else
                setCor(cx , y)
            revisionCor()

    //カーソル下移動
    let moveDown() =
        if cy < ( sList.Count - 1 ) then
            let y = cy + 1 
            if cx > ( sList.[y].Length ) then
                setCor( sList.[y].Length , y )
            else
                setCor(cx , y)
            revisionCor()

    //カーソル左移動
    let moveLeft(i) =
        for ii = 1 to i do
            if cx > 0 then
                setCor(cx - 1 , cy)
            elif cy > 0 then
                setCor( sList.[ cy - 1 ].Length , cy - 1)
        revisionCor()

    //カーソル右移動
    let moveRight(i) =
        for ii = 1 to i do
            if cx < ( sList.[cy].Length ) then
                setCor(cx + 1 , cy)
            elif cy < sList.Count - 1 then
                setCor( 0, cy + 1)
        revisionCor()

    //文字列をリストに変換
    let StrToList() =
        sList.Clear()
        Array.iter(fun a -> sList.Add(a))(baseStr.Split('\n'))

    //選択範囲をカーソル位置から文字位置に変換し取得
    let getSPos() =
        let a = getMPos( cx , cy  )
        let b = getMPos( bkx, bky )
        if a < b then a,b else b,a

    //選択範囲削除
    let delSStr(a,b) =
        baseStr <- baseStr.Remove( a, b - a )
        StrToList()
        setCor(getCPos(a))

    //文字列挿入
    let insStr(s) =
        if cx <> bkx || cy <> bky then
            delSStr(getSPos())
            
        baseStr <- baseStr.Insert(getMPos(cx,cy), s)
        StrToList()
        moveRight(s.Length)
        searchList <- []

    //文字列削除(前方)
    let delStr() =
        //変換候補削除
        if ime.TmpStr.Length <> 0 then
            ime.TmpStr <- ""
        else
            let a,b = getSPos()
            if a = b then
                if getMPos(cx,cy) < baseStr.Length then
                    baseStr <- baseStr.Remove( getMPos(cx,cy) , 1 )
                    StrToList()
            else
                delSStr(a,b)
            searchList <- []

    //文字列削除(後方)
    let backStr() =
        //変換候補削除
        if ime.TmpStr.Length <> 0 then
            ime.TmpStr <- ""
        else
            let a,b = getSPos()
            if a = b then
                let p = getMPos(cx,cy)
                if p > 0 then
                    baseStr <- baseStr.Remove( p - 1 , 1 )
                    StrToList()
                    moveLeft(1)
            else
                delSStr(a,b)
            searchList <- []

    //コピー
    let copyStr() =
        let a,b = getSPos()
        cStr <- baseStr.Substring( a, b - a )

    //カット
    let cutStr() =
        let a,b = getSPos()
        cStr <- baseStr.Substring( a, b - a )
        StrToList()
        delSStr(a,b)
        searchList <- []

    //ペースト
    let pasteStr(cx,cy) =
        if cStr <> "" then
            let a,b = getSPos()
            if a <> b then
                delSStr(a,b)

            baseStr <- baseStr.Insert( a, cStr )
            StrToList()
            setCor( getCPos( a + cStr.Length ) )
            revisionCor()
            searchList <- []

    //全選択
    let selectAll() =
        let y = sList.Count - 1
        setSCor( sList.[y].Length , y )
        setBCor(0,0)

    //新規作成(未作成)
    let newFile() = ()
    //保存
    let saveFile() =
        if fileName = "" then false
        else
            WiteFile(fileName,baseStr)
            true
        
    //開く
    let openFile() =
        if fileName = "" then false
        else
            match ReadFile(fileName) with
            |None -> false
            |Some(s) ->
                baseStr <- s
                StrToList()
                cx <- 0
                cy <- 0
                true
        
    //検索
    let search() =
        if searchStr = "" then
            false
        else
            let mutable i = 0
            searchList <- []
            while i <> -1 do
                i <- baseStr.IndexOf( searchStr, i )
                if i <> -1 then
                    searchList <- ( getCPos(i) , searchStr.Length ) :: searchList
                    i <- i + searchStr.Length
            printfn "%A" searchList
            true
    
    //置換(未作成)
    let replace() = true

    //更新処理
    member u.update(form:MyForm,g:MyGraphics,key:MyInput) =
        match mode with
        | 0 ->
            //マウス系
            if key.mPush(0) then
                let mx,my = key.mPos(form.Scale)
                if mx > 0 && mx < 320 && my > 0 && my < 220 then
                    let bk_x,bk_y = setMouseCur(mx,my)

                    if key.kShift then
                        setSCor(bk_x, bk_y)
                    else
                        setCor(bk_x, bk_y)
                
            if key.mDown(0) then
                let mx,my = key.mPos(form.Scale)
                if mx > 0 && mx < 320 && my > 0 && my < 220 then
                    let bk_x,bk_y = setMouseCur(mx,my)
                    setSCor(bk_x, bk_y)

            if key.Delta <> 0 then
                dy <- dy - (key.Delta/120)
                if dy < 0 then dy <- 0
                if dy > sList.Count then dy <- sList.Count
        
            //キーボード系
            for k in key.KeyList do
                if not key.kCtrl then
                    match k with
                    | Keys.Tab ->
                        if ime.Mode = 0 then ime.Mode <- 1
                        else ime.Mode <- 0 
        
                    //カーソル移動
                    | Keys.Up -> moveUp()
                    | Keys.Down -> moveDown()
                    | Keys.Left -> moveLeft(1)
                    | Keys.Right -> moveRight(1)
                    | Keys.Delete -> delStr()//前方削除
                    | Keys.Back -> backStr()//後方削除
                    //文字入力
                    | k ->
                        match ime.getStr(k , key.kShift) with
                        |None -> ()
                        |Some(s) -> insStr(s)
                else
                    match k with
                    | Keys.Up ->   if dy < sList.Count then dy <- dy + 1//表示位置移動
                    | Keys.Down -> if dy > 0           then dy <- dy - 1
                    | Keys.A -> selectAll()//全選択
                    | Keys.C -> copyStr()//コピー処理
                    | Keys.X -> cutStr()//カット処理
                    | Keys.V -> pasteStr(cx,cy)//ペースト処理
                    | Keys.N -> newFile()//未作成
                    | Keys.S -> mode <- 1 ; ime.Mode <- 1
                    | Keys.O ->
                        mode <- 2 ; ime.Mode <- 1
                    | Keys.F ->
                        mode <- 3 ; ime.Mode <- 1
                    | Keys.H ->
                        ()//未作成(置換)
                    | _ -> ()
        
        //ファイル保存
        | 1 ->
            //ファイル名入力中
            for k in key.KeyList do
                match k with
                | Keys.Tab ->
                    if ime.Mode = 0 then ime.Mode <- 1
                    else ime.Mode <- 0 
                | Keys.Enter ->
                    if saveFile() then
                        mode <- 0
                | Keys.Space ->
                    mode <- 0
                | Keys.Back -> if fileName <> "" then fileName <- fileName.Remove( fileName.Length - 1)
                | k ->
                    match ime.getStr(k , key.kShift) with
                    |None -> ()
                    |Some(s) -> fileName <- fileName + s

        //ファイル読み込み
        | 2 ->
            //ファイル名入力中
            for k in key.KeyList do
                match k with
                | Keys.Tab ->
                    if ime.Mode = 0 then ime.Mode <- 1
                    else ime.Mode <- 0 
                | Keys.Enter ->
                    if openFile() then
                        mode <- 0
                | Keys.Space ->
                    mode <- 0
                | Keys.Back -> if fileName <> "" then fileName <- fileName.Remove( fileName.Length - 1)
                | k ->
                    match ime.getStr( k , key.kShift ) with
                    |None -> ()
                    |Some(s) -> fileName <- fileName + s

        //検索
        | 3 ->
            for k in key.KeyList do
                match k with
                | Keys.Tab ->
                    if ime.Mode = 0 then ime.Mode <- 1
                    else ime.Mode <- 0 
                | Keys.Enter ->
                    if search() then
                        mode <- 0
                | Keys.Space ->
                    mode <- 0
                | Keys.Back -> if searchStr <> "" then searchStr <- searchStr.Remove( searchStr.Length - 1)
                | k ->
                    match ime.getStr(k , key.kShift) with
                    |None -> ()
                    |Some(s) -> searchStr <- searchStr + s

        //置換
        | 4 -> ()

        | _ -> ()
            

        
        //描画処理
        g.setColor(Color.White)

        //検索結果表示
        g.setColor(Color.Gray)
        List.iter(
            fun ((x,y),len) ->
                let xx,yy = x-dx , y-dy
                if xx >= 0 && xx < maxX && yy >= 0 && yy < maxY+2 then
                    g.fRect (xx*8) (yy*16) (len*8) 16 
        )searchList

        //選択範囲の逆転
        let psx,psy,pdx,pdy = revSPos(cx,cy,bkx,bky)

        //文字の表示
        for y = 0 to maxY+1 do
            for x = 0 to maxX do
                let xx = x + dx
                let yy = y + dy
                if yy <= ( sList.Count - 1 ) then
                    if xx <= ( sList.[yy].Length - 1 ) then
                        if (yy > psy || (yy = psy && xx >= psx)) &&
                           (yy < pdy || (yy = pdy && xx < pdx)) then
                            g.setColor(Color.Lime)
                        else
                            g.setColor(Color.White)
                        g.dStr ( x * 8 ) ( y * 16 ) sList.[yy].[xx]

        //変換前文字の表示
        g.dStr ((cx-dx)*8) ((cy-dy)*16) ime.TmpStr
        
        //カーソル表示
        g.setColor(Color.Yellow)
        g.fRect ( (cx-dx) * 8 + 2 ) ((cy-dy)*16) 2 16

        //カーソル表示
        g.setColor(Color.DarkBlue)
        g.dLine 0 ((cy-dy+1)*16-1) 315 ((cy-dy+1)*16-1)

        //変換候補の表示
        g.setColor(Color.Yellow)
        List.iteri(fun i a -> g.dStrS (25*i) 210 a.jpStr)ime.RomaList

        //スクロールバーの表示
        g.setColor(Color.White) ; g.dRect 315 0 5 240
        let lenY = maxY * 240 / ( sList.Count + maxY - 1 )
        let posY = dy * 240 / ( sList.Count + maxY - 1 )
        g.setColor(Color.Red) ; g.fRect 315 posY 5 lenY

        g.setColor(Color.White) ; g.fRect 0 220 320 20
        //その他情報
        g.setColor(Color.Black)
        let modeStr =
            match ime.Mode with
            |0 -> "半角カナ"
            |1 -> "半角英数"
            |_ -> "エラー"

        match mode with
        | 0 ->
            g.dStrS 0 220 ("X: " + cx.ToString() + " Y:" + cy.ToString())
            g.dStrS 200 220 ( "[" + modeStr + "(tabで変更)]" )
            g.dStrS 250 230 ("メモ帳以下")
        | 1 ->
            g.dStr 20 222 fileName
            g.dStrS 0 220 ("保存")
            g.dStrS 180 230 ("Enter:決定 Space:戻る")
        | 2 ->
            g.dStr 20 222 fileName
            g.dStrS 0 220 ("開く")
            g.dStrS 180 230 ("Enter:決定 Space:戻る")
        | 3 ->
            g.dStr 20 222 searchStr
            g.dStrS 0 220 ("検索")
            g.dStrS 180 230 ("Enter:決定 Space:戻る")
        | _ ->
            ()
        g.dStrS 200 220 ( "[" + modeStr + "(tabで変更)]" )