﻿open System
open System.Windows.Forms
open System.Drawing
open System.Collections.Generic
open System.Text.RegularExpressions
open System.Diagnostics

open MyGraphics
open MyLoop
open MyInput
open MyForm
open KeyToStr
open MyIO

open Edit

type Game() =
    inherit MyForm()
    let edit = new Edit()
    //更新処理
    override u.update(g,key) =
        edit.update(u,g,key)
        key.Clear()

let game = new Game()
game.run()
