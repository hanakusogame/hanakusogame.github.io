﻿//ベースとなるフォーム
module MyForm

open System
open System.Windows.Forms
open System.Drawing
open System.Collections.Generic
open MyGraphics
open MyLoop
open MyInput

type MyForm() =
    let mutable w,h = 320,240
    let mutable scale = 1
    let mutable debugFlg = false
    let fileName =
        let path = Application.ExecutablePath.Split('\\')
        path.[path.Length-1]

    let form = new Form( ClientSize = new Size(w, h) , MaximizeBox = false, FormBorderStyle = FormBorderStyle.FixedSingle)
    let g = new MyGraphics(form)
    let key = new MyInput(form)
    let loop = new MyLoop()
    let mutable frameCnt = 0

    let updateBase ( update: MyGraphics * MyInput -> unit ) () =
        key.setMouse()
        key.setKey()

        if form.Created then
            //終了
            if key.kPush(Keys.Escape) then loop.exit()

            //サイズ変更
            match key.getKey(0) with
            |Keys.F1 ->
                if scale = 2 then
                    scale <- 1
                    g.reSize(w,h)
                else
                    scale <- 2
                    g.reSize( w*scale , h*scale )

            //デバッグ情報表示可否変更
            |Keys.F12 ->
                debugFlg <- not(debugFlg)
            |_->()

            g.clear(Color.Black)

            update(g,key)

            //デバッグ情報表示
            if debugFlg then
                g.setColor(Color.Lime)
                let x,y = key.mPos(scale)
                g.dStrS 0  0 ( "FPS:" + loop.getFps().ToString() )
                g.dStrS 0 10 ( "W:" + w.ToString() + " H:" + h.ToString() + " S:" + scale.ToString())
                g.dStrS 0 20 ( "X:" + x.ToString() + " Y:" + y.ToString() )
                g.dStrS 0 30 ( "KEY:" + key.getKey(1).ToString() )

            g.render()

            //タイトルバー表示
            form.Text <- "[メモ帳以下]" + fileName
        else
            loop.exit()

        frameCnt <- frameCnt + 1

    member u.Scale with get() = scale
    member u.p_form with get() = form
    //更新処理
    abstract member update: MyGraphics * MyInput -> unit
    default u.update(g,key) = ()

    member u.run() =
        form.Show()
        loop.Update <- updateBase (u.update)
        //loop.Init <- ??
        loop.run()



