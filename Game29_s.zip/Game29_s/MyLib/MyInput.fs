﻿//入力関連モジュール(キーボード、マウス)
module MyInput

open System.Windows.Forms

type MyInput (form:Form) =
    //キーボード入力イベント取得
    let noneKeyEvent = new KeyEventArgs(Keys.None)
    let mutable keyEvent = new KeyEventArgs(Keys.None)


    let mutable bkMouse = MouseButtons.None
    let mutable nowMouse = MouseButtons.None

    let mChk =
        function
        |0 -> MouseButtons.Left
        |1 -> MouseButtons.Right
        |2 -> MouseButtons.Middle
        |_ -> MouseButtons.None

    //------キーボード情報-------
    let mutable nowKey = keyEvent
    let mutable bkKey = keyEvent

    //ちょっと実験
    let mutable keyList = []

    //マウスホイール実験
    let mutable delta = 0

    do
        form.KeyDown.Add(fun mi -> keyEvent <- mi)
        form.KeyUp.Add(fun mi -> keyEvent <- noneKeyEvent)

        //ホイールテスト
        form.MouseWheel.Add(fun a -> delta <- delta + a.Delta)

        //ちょっと実験
        form.KeyDown.Add(
            fun mi -> keyList <- keyList @ [ mi.KeyCode ]
        )
    
    //ちょっと実験
    member u.KeyList with get() = keyList and set a = keyList <- a
    member u.Delta with get() = delta and set a = delta <- a

    member u.Clear() =
        keyList <- []
        delta <- 0

    member u.setKey() =
        bkKey <- nowKey
        nowKey <- keyEvent
    
    //押されたかどうか
    member u.kPush k = bkKey.KeyCode <> k && nowKey.KeyCode = k
    member u.kDown k = nowKey.KeyCode = k
    member u.kUp k = bkKey.KeyCode = k && nowKey.KeyCode <> k

    //shiftキーが押されているかどうか
    member u.kShift with get() = nowKey.Shift
    member u.kCtrl with get() = nowKey.Control
    
    //押されたキー取得
    member u.getKey =
        function
        //押された瞬間
        |0 -> if ( nowKey.KeyCode <> Keys.None ) && ( bkKey.KeyCode <> nowKey.KeyCode ) then nowKey.KeyCode else Keys.None 
        //押されている
        |1 -> nowKey.KeyCode
        //離された(動きがややおかしい)
        |2 -> if ( bkKey.KeyCode <> Keys.None ) && (nowKey.KeyCode = Keys.None) then bkKey.KeyCode else Keys.None
        |_ -> Keys.None

    //-------マウス情報----------
    member u.setMouse() =
        bkMouse <- nowMouse
        nowMouse <- Control.MouseButtons

    member u.mPush btn =
        match mChk(btn) with
        |b -> (bkMouse &&& b) <> b && (nowMouse &&& b) = b

    member u.mDown btn =
        match mChk(btn) with
        |b -> (nowMouse &&& b) = b

    member u.mUp btn =
        match mChk(btn) with
        |b -> (bkMouse &&& b) = b && (nowMouse &&& b) <> b

    member u.mPos(s) =
        let pos = form.PointToClient(System.Windows.Forms.Cursor.Position)
        ( pos.X/s ,pos.Y/s)