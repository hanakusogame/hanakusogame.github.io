﻿//IMEもどき(とてつもなくひどい出来)
module MyIME

open System
open KeyToStr
open System.Windows.Forms
open System.Text.RegularExpressions

type MyIME() =
    let mutable mode = 0
    let mutable tmpStr = ""
    let mutable romaList = [] //変換候補

    //変換候補リスト取得
    let getRomaList(s) =
        List.filter(fun (a:Japanese) ->
            ( List.exists (fun b -> Regex.IsMatch(b,("^" + s)) ) (a.rStr) ) )jp
    
    let getChr(k,shift) = List.tryFind( fun (a:Alphabet) -> a.key = k && a.shift = shift )al

    member u.Mode with get() = mode and set a = mode <- a
    member u.TmpStr with get() = tmpStr and set a = tmpStr <- a
    member u.RomaList with get() = romaList

    member u.getStr(k:Keys,shift:bool) =
        match getChr(k,shift) with
        |None -> None
        |Some(s) ->
            match mode with
            | 1 -> Some(s.str)
            | _ ->
                match s.str with
                |"," -> Some("､")
                |"." -> Some("｡")
                |"[" -> Some("｢")
                |"]" -> Some("｣")
                |"-" -> Some("ｰ")
                | ss ->
                    if not(List.exists(fun b -> b = ss.[0] )['a' .. 'z']) then
                        Some(ss)
                    else 
                        tmpStr <- tmpStr + ss
                        romaList <- getRomaList(tmpStr)
                        match romaList.Length with
                        | 1 ->
                            //変換候補から完全に一致する文字取得
                            if List.exists (fun s -> tmpStr = s)romaList.Head.rStr then
                                tmpStr <- ""
                                Some(romaList.Head.jpStr)
                            else None
                        | 0 -> tmpStr <- "" ; None
                        | _ -> None