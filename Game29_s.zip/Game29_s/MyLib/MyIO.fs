﻿module MyIO
open System.IO
open System.Text
open System.Runtime.Serialization.Formatters.Binary


let fileChk filename = File.Exists(filename)
//ファイル入出力処理(クラス等のシリアライズ)
//引用元→http://fsharpandenglishword.blog83.fc2.com/blog-entry-131.html
let saveValue filename x = 
    use stream = new FileStream(filename,FileMode.Create) 
    (new BinaryFormatter()).Serialize(stream,box x)
    
let loadValue filename =
    use stream = new FileStream(filename,FileMode.Open)
    (new BinaryFormatter()).Deserialize(stream) |> unbox

let WiteFile(name,text:string) =
    //let sw = new StreamWriter(name, false, Encoding.GetEncoding("shift_jis"))
    let sw = new StreamWriter(name, false)
    sw.Write(text)
    sw.Close()

let ReadFile(name:string) =
    if fileChk(name) then
        let sr = new StreamReader(name)
        let text = sr.ReadToEnd()
        sr.Close()
        Some(text)
    else
        None

