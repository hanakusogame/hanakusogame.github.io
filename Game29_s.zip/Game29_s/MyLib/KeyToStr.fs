﻿module KeyToStr

open System
open System.Drawing
open System.Windows.Forms
open MyInput
open MyGraphics

//日本語ローマ字入力用
type Japanese =
    {
        jpStr:string
        rStr:string list
    }

//半角英数字
type Alphabet =
    {
        key : Keys
        shift : bool
        str : string
    }

let al =
    [
        { key = Keys.A ; shift = false ; str = "a" }
        { key = Keys.B ; shift = false ; str = "b" }
        { key = Keys.C ; shift = false ; str = "c" }
        { key = Keys.D ; shift = false ; str = "d" }
        { key = Keys.E ; shift = false ; str = "e" }
        { key = Keys.F ; shift = false ; str = "f" }
        { key = Keys.G ; shift = false ; str = "g" }
        { key = Keys.H ; shift = false ; str = "h" }
        { key = Keys.I ; shift = false ; str = "i" }
        { key = Keys.J ; shift = false ; str = "j" }
        { key = Keys.K ; shift = false ; str = "k" }
        { key = Keys.L ; shift = false ; str = "l" }
        { key = Keys.M ; shift = false ; str = "m" }
        { key = Keys.N ; shift = false ; str = "n" }
        { key = Keys.O ; shift = false ; str = "o" }
        { key = Keys.P ; shift = false ; str = "p" }
        { key = Keys.Q ; shift = false ; str = "q" }
        { key = Keys.R ; shift = false ; str = "r" }
        { key = Keys.S ; shift = false ; str = "s" }
        { key = Keys.T ; shift = false ; str = "t" }
        { key = Keys.U ; shift = false ; str = "u" }
        { key = Keys.V ; shift = false ; str = "v" }
        { key = Keys.W ; shift = false ; str = "w" }
        { key = Keys.X ; shift = false ; str = "x" }
        { key = Keys.Y ; shift = false ; str = "y" }
        { key = Keys.Z ; shift = false ; str = "z" }

        { key = Keys.A ; shift = true ; str = "A" }
        { key = Keys.B ; shift = true ; str = "B" }
        { key = Keys.C ; shift = true ; str = "C" }
        { key = Keys.D ; shift = true ; str = "D" }
        { key = Keys.E ; shift = true ; str = "E" }
        { key = Keys.F ; shift = true ; str = "F" }
        { key = Keys.G ; shift = true ; str = "G" }
        { key = Keys.H ; shift = true ; str = "H" }
        { key = Keys.I ; shift = true ; str = "I" }
        { key = Keys.J ; shift = true ; str = "J" }
        { key = Keys.K ; shift = true ; str = "K" }
        { key = Keys.L ; shift = true ; str = "L" }
        { key = Keys.M ; shift = true ; str = "M" }
        { key = Keys.N ; shift = true ; str = "N" }
        { key = Keys.O ; shift = true ; str = "O" }
        { key = Keys.P ; shift = true ; str = "P" }
        { key = Keys.Q ; shift = true ; str = "Q" }
        { key = Keys.R ; shift = true ; str = "R" }
        { key = Keys.S ; shift = true ; str = "S" }
        { key = Keys.T ; shift = true ; str = "T" }
        { key = Keys.U ; shift = true ; str = "U" }
        { key = Keys.V ; shift = true ; str = "V" }
        { key = Keys.W ; shift = true ; str = "W" }
        { key = Keys.X ; shift = true ; str = "X" }
        { key = Keys.Y ; shift = true ; str = "Y" }
        { key = Keys.Z ; shift = true ; str = "Z" }

        { key = Keys.D0 ; shift = false ; str = "0" }
        { key = Keys.D1 ; shift = false ; str = "1" }
        { key = Keys.D2 ; shift = false ; str = "2" }
        { key = Keys.D3 ; shift = false ; str = "3" }
        { key = Keys.D4 ; shift = false ; str = "4" }
        { key = Keys.D5 ; shift = false ; str = "5" }
        { key = Keys.D6 ; shift = false ; str = "6" }
        { key = Keys.D7 ; shift = false ; str = "7" }
        { key = Keys.D8 ; shift = false ; str = "8" }
        { key = Keys.D9 ; shift = false ; str = "9" }

        //{ key = Keys.NumPad0 ; shift = false ; str = "0" }
        //{ key = Keys.NumPad1 ; shift = false ; str = "1" }
        //{ key = Keys.NumPad2 ; shift = false ; str = "2" }
        //{ key = Keys.NumPad3 ; shift = false ; str = "3" }
        //{ key = Keys.NumPad4 ; shift = false ; str = "4" }
        //{ key = Keys.NumPad5 ; shift = false ; str = "5" }
        //{ key = Keys.NumPad6 ; shift = false ; str = "6" }
        //{ key = Keys.NumPad7 ; shift = false ; str = "7" }
        //{ key = Keys.NumPad8 ; shift = false ; str = "8" }
        //{ key = Keys.NumPad9 ; shift = false ; str = "9" }

        { key = Keys.D1 ; shift = true ; str = "!" }
        { key = Keys.D2 ; shift = true ; str = "\""}
        { key = Keys.D3 ; shift = true ; str = "#" }
        { key = Keys.D4 ; shift = true ; str = "$" }
        { key = Keys.D5 ; shift = true ; str = "%" }
        { key = Keys.D6 ; shift = true ; str = "&" }
        { key = Keys.D7 ; shift = true ; str = "'" }
        { key = Keys.D8 ; shift = true ; str = "(" }
        { key = Keys.D9 ; shift = true ; str = ")" }

        { key = Keys.Space           ; shift = false ; str = " "}
        { key = Keys.OemMinus        ; shift = false ; str = "-"}
        { key = Keys.Oem5            ; shift = false ; str = "\\" }
        { key = Keys.Oem7            ; shift = false ; str = "^"}
        { key = Keys.Oemtilde        ; shift = false ; str = "@"}
        { key = Keys.OemOpenBrackets ; shift = false ; str = "["}
        { key = Keys.Oemplus         ; shift = false ; str = ";"}
        { key = Keys.Oem1            ; shift = false ; str = ":"}
        { key = Keys.Oem6            ; shift = false ; str = "]"}
        { key = Keys.Oemcomma        ; shift = false ; str = ","}
        { key = Keys.OemPeriod       ; shift = false ; str = "."}
        { key = Keys.OemQuestion     ; shift = false ; str = "/"}
        //{ key = Keys.OemBackslash    ; shift = false ; str = "\\"}

        { key = Keys.OemMinus        ; shift = true ; str = "="}
        { key = Keys.Oem5            ; shift = true ; str = "|"}
        { key = Keys.Oem7            ; shift = true ; str = "~"}
        { key = Keys.Oemtilde        ; shift = true ; str = "`"}
        { key = Keys.OemOpenBrackets ; shift = true ; str = "{"}
        { key = Keys.Oemplus         ; shift = true ; str = "+"}
        { key = Keys.Oem1            ; shift = true ; str = "*"}
        { key = Keys.Oem6            ; shift = true ; str = "}"}
        { key = Keys.Oemcomma        ; shift = true ; str = "<"}
        { key = Keys.OemPeriod       ; shift = true ; str = ">"}
        { key = Keys.OemQuestion     ; shift = true ; str = "?"}
        { key = Keys.OemBackslash    ; shift = true ; str = "_"}

        { key = Keys.Enter    ; shift = false ; str = "\n"}
    ]

let jp =
    [
        { jpStr = " " ; rStr = [" "] };
        { jpStr = "ｱ" ; rStr = ["a"] };{ jpStr = "ｲ" ; rStr = ["i";"yi"] };{ jpStr = "ｳ" ; rStr = ["u";"wu";"wyu"] };{ jpStr = "ｴ" ; rStr = ["e"] };{ jpStr = "ｵ" ; rStr = ["o"] };
        { jpStr = "ｶ" ; rStr = ["ka";"ca"] };{ jpStr = "ｷ" ; rStr = ["ki"] };{ jpStr = "ｸ" ; rStr = ["ku";"cu"] };{ jpStr = "ｹ" ; rStr = ["ke"] };{ jpStr = "ｺ" ; rStr = ["ko";"co"] };
        { jpStr = "ｻ" ; rStr = ["sa"] };{ jpStr = "ｼ" ; rStr = ["si";"shi"] };{ jpStr = "ｽ" ; rStr = ["su"] };{ jpStr = "ｾ" ; rStr = ["se"] };{ jpStr = "ｿ" ; rStr = ["so"] };
        { jpStr = "ﾀ" ; rStr = ["ta"] };{ jpStr = "ﾁ" ; rStr = ["ti";"chi"] };{ jpStr = "ﾂ" ; rStr = ["tu";"tsu"] };{ jpStr = "ﾃ" ; rStr = ["te"] };{ jpStr = "ﾄ" ; rStr = ["to"] };
        { jpStr = "ﾅ" ; rStr = ["na"] };{ jpStr = "ﾆ" ; rStr = ["ni"] };{ jpStr = "ﾇ" ; rStr = ["nu"] };{ jpStr = "ﾈ" ; rStr = ["ne"] };{ jpStr = "ﾉ" ; rStr = ["no"] };
        { jpStr = "ﾊ" ; rStr = ["ha"] };{ jpStr = "ﾋ" ; rStr = ["hi"] };{ jpStr = "ﾌ" ; rStr = ["hu";"fu"] };{ jpStr = "ﾍ" ; rStr = ["he"] };{ jpStr = "ﾎ" ; rStr = ["ho"] };
        { jpStr = "ﾏ" ; rStr = ["ma"] };{ jpStr = "ﾐ" ; rStr = ["mi"] };{ jpStr = "ﾑ" ; rStr = ["mu"] };{ jpStr = "ﾒ" ; rStr = ["me"] };{ jpStr = "ﾓ" ; rStr = ["mo"] };
        { jpStr = "ﾔ" ; rStr = ["ya"] };{ jpStr = "ﾕ" ; rStr = ["yu"] };{ jpStr = "ﾖ" ; rStr = ["yo"] };{ jpStr = "ｰ" ; rStr = ["-"] };
        { jpStr = "ﾗ" ; rStr = ["ra"] };{ jpStr = "ﾘ" ; rStr = ["ri"] };{ jpStr = "ﾙ" ; rStr = ["ru"] };{ jpStr = "ﾚ" ; rStr = ["re"] };{ jpStr = "ﾛ" ; rStr = ["ro"] };
        { jpStr = "ﾜ" ; rStr = ["wa"] };{ jpStr = "ｦ" ; rStr = ["wo"] };{ jpStr = "ﾝ" ; rStr = ["nn";"xn"] };{ jpStr = "ｳﾞ" ; rStr = ["vu"] };
        { jpStr = "ｶﾞ" ; rStr = ["ga"] };{ jpStr = "ｷﾞ" ; rStr = ["gi"] };{ jpStr = "ｸﾞ" ; rStr = ["gu"] };{ jpStr = "ｹﾞ" ; rStr = ["ge"] };{ jpStr = "ｺﾞ" ; rStr = ["go"] };
        { jpStr = "ｻﾞ" ; rStr = ["za"] };{ jpStr = "ｼﾞ" ; rStr = ["zi";"ji"] };{ jpStr = "ｽﾞ" ; rStr = ["zu"] };{ jpStr = "ｾﾞ" ; rStr = ["ze"] };{ jpStr = "ｿﾞ" ; rStr = ["zo"] };
        { jpStr = "ﾀﾞ" ; rStr = ["da"] };{ jpStr = "ﾁﾞ" ; rStr = ["di"] };{ jpStr = "ﾂﾞ" ; rStr = ["du"] };{ jpStr = "ﾃﾞ" ; rStr = ["de"] };{ jpStr = "ﾄﾞ" ; rStr = ["do"] };
        { jpStr = "ﾊﾞ" ; rStr = ["ba"] };{ jpStr = "ﾋﾞ" ; rStr = ["bi"] };{ jpStr = "ﾌﾞ" ; rStr = ["bu"] };{ jpStr = "ﾍﾞ" ; rStr = ["be"] };{ jpStr = "ﾎﾞ" ; rStr = ["bo"] };
        { jpStr = "ﾊﾟ" ; rStr = ["pa"] };{ jpStr = "ﾋﾟ" ; rStr = ["pi"] };{ jpStr = "ﾌﾟ" ; rStr = ["pu"] };{ jpStr = "ﾍﾟ" ; rStr = ["pe"] };{ jpStr = "ﾎﾟ" ; rStr = ["po"] };
        { jpStr = "ｧ" ; rStr = ["xa";"la"] };{ jpStr = "ｨ" ; rStr = ["xi";"li"] };{ jpStr = "ｩ" ; rStr = ["xu";"lu"] };{ jpStr = "ｪ" ; rStr = ["xe";"le";"xye";"lye"] };{ jpStr = "ｫ" ; rStr = ["xo";"lo"] };
        { jpStr = "ｯ" ; rStr = ["xtu";"ltu"] };{ jpStr = "ｬ" ; rStr = ["lya";"lya"] };{ jpStr = "ｭ" ; rStr = ["xyu";"lyu"] };{ jpStr = "ｮ" ; rStr = ["xyo";"lyo"] };{ jpStr = "ヮ" ; rStr = ["xwa";"lwa"] };
        { jpStr = "ｷｬ" ; rStr = ["kya"] };{ jpStr = "ｷｨ" ; rStr = ["kyi"] };{ jpStr = "ｷｭ" ; rStr = ["kyu"] };{ jpStr = "ｷｪ" ; rStr = ["kye"] };{ jpStr = "ｷｮ" ; rStr = ["kyo"] };
        { jpStr = "ｳｧ" ; rStr = ["wya"] };{ jpStr = "ｳｨ" ; rStr = ["whi";"wi"] };{ jpStr = "ｳｪ" ; rStr = ["whe";"we"] };{ jpStr = "ｳｫ" ; rStr = ["wyo"] };
        { jpStr = "ｸｬ" ; rStr = ["qya"] };{ jpStr = "ｸｨ" ; rStr = ["qyi";"qwi"] };{ jpStr = "ｸｭ" ; rStr = ["qyu"] };{ jpStr = "ｸｪ" ; rStr = ["qye";"qwe"] };{ jpStr = "ｸｮ" ; rStr = ["qyo"] };
        { jpStr = "ｸｧ" ; rStr = ["kwa";"qwa"] };{ jpStr = "ｸｩ" ; rStr = ["qwu"] };{ jpStr = "ｸｫ" ; rStr = ["qwo"] };
        { jpStr = "ｼｬ" ; rStr = ["sya";"sha"] };{ jpStr = "ｼｨ" ; rStr = ["syi"] };{ jpStr = "ｼｭ" ; rStr = ["syu";"shu"] };{ jpStr = "ｼｪ" ; rStr = ["sye";"she"] };{ jpStr = "ｼｮ" ; rStr = ["syo";"sho"] };
        { jpStr = "ｽｧ" ; rStr = ["swa"] };{ jpStr = "ｽｨ" ; rStr = ["swi"] };{ jpStr = "ｽｩ" ; rStr = ["swu"] };{ jpStr = "ｽｪ" ; rStr = ["swe"] };{ jpStr = "ｽｫ" ; rStr = ["swo"] };
        { jpStr = "ﾃｬ" ; rStr = ["tha"] };{ jpStr = "ﾃｨ" ; rStr = ["thi"] };{ jpStr = "ﾃｭ" ; rStr = ["thu"] };{ jpStr = "ﾃｪ" ; rStr = ["the"] };{ jpStr = "ﾃｮ" ; rStr = ["tho"] };
        { jpStr = "ﾄｧ" ; rStr = ["twa"] };{ jpStr = "ﾄｨ" ; rStr = ["twi"] };{ jpStr = "ﾄｩ" ; rStr = ["twu"] };{ jpStr = "ﾄｪ" ; rStr = ["twe"] };{ jpStr = "ﾄｫ" ; rStr = ["two"] };
        { jpStr = "ﾁｬ" ; rStr = ["tya";"cha";"cya"] };{ jpStr = "ﾁｨ" ; rStr = ["tyi";"cyi"] };{ jpStr = "ﾁｭ" ; rStr = ["tyu";"chu";"cyu"] };{ jpStr = "ﾁｪ" ; rStr = ["tye";"che";"cye"] };{ jpStr = "ﾁｮ" ; rStr = ["tyo";"cho";"cyo"] };
        { jpStr = "ﾌｧ" ; rStr = ["fa";"fwa"] };{ jpStr = "ﾌｨ" ; rStr = ["fi";"fwi";"fyi"] };{ jpStr = "ﾌｩ" ; rStr = ["fwu"] };{ jpStr = "ﾌｪ" ; rStr = ["fe";"fwi";"fye"] };{ jpStr = "ﾌｫ" ; rStr = ["fo";"fwo"] };
        { jpStr = "ｸﾞｧ" ; rStr = ["gwa"] };{ jpStr = "ｸﾞｨ" ; rStr = ["gwi"] };{ jpStr = "ｸﾞｩ" ; rStr = ["gwu"] };{ jpStr = "ｸﾞｪ" ; rStr = ["gwe"] };{ jpStr = "ｸﾞｫ" ; rStr = ["gwo"] };
        { jpStr = "ﾆｬ" ; rStr = ["nya"] };{ jpStr = "ﾆｨ" ; rStr = ["nyi"] };{ jpStr = "ﾆｭ" ; rStr = ["nyu"] };{ jpStr = "ﾆｪ" ; rStr = ["nye"] };{ jpStr = "ﾆｮ" ; rStr = ["nyo"] };
        { jpStr = "ﾄﾞｧ" ; rStr = ["dwa"] };{ jpStr = "ﾄﾞｨ" ; rStr = ["dwi"] };{ jpStr = "ﾄﾞｩ" ; rStr = ["dwu"] };{ jpStr = "ﾄﾞｪ" ; rStr = ["dwe"] };{ jpStr = "ﾄﾞｫ" ; rStr = ["dwo"] };
        { jpStr = "ﾋｬ" ; rStr = ["hya"] };{ jpStr = "ﾋｨ" ; rStr = ["hyi"] };{ jpStr = "ﾋｭ" ; rStr = ["hyu"] };{ jpStr = "ﾋｪ" ; rStr = ["hye"] };{ jpStr = "ﾋｮ" ; rStr = ["hyo"] };
        { jpStr = "ﾌｬ" ; rStr = ["fya"] };{ jpStr = "ﾌｭ" ; rStr = ["fyu"] };{ jpStr = "ﾌｮ" ; rStr = ["fyo"] };
        { jpStr = "ﾐｬ" ; rStr = ["mya"] };{ jpStr = "ﾐｨ" ; rStr = ["myi"] };{ jpStr = "ﾐｭ" ; rStr = ["myu"] };{ jpStr = "ﾐｪ" ; rStr = ["mye"] };{ jpStr = "ﾐｮ" ; rStr = ["myo"] };
        { jpStr = "ﾂｧ" ; rStr = ["tsa"] };{ jpStr = "ﾂｨ" ; rStr = ["tsi"] };{ jpStr = "ﾂｪ" ; rStr = ["tse"] };{ jpStr = "ﾂｫ" ; rStr = ["tso"] };
        { jpStr = "ﾘｬ" ; rStr = ["rya"] };{ jpStr = "ﾘｨ" ; rStr = ["ryi"] };{ jpStr = "ﾘｭ" ; rStr = ["ryu"] };{ jpStr = "ﾘｪ" ; rStr = ["rye"] };{ jpStr = "ﾘｮ" ; rStr = ["ryo"] };
        { jpStr = "ｷﾞｬ" ; rStr = ["gya"] };{ jpStr = "ｷﾞｨ" ; rStr = ["gyi"] };{ jpStr = "ｷﾞｭ" ; rStr = ["gyu"] };{ jpStr = "ｷﾞｪ" ; rStr = ["gye"] };{ jpStr = "ｷﾞｮ" ; rStr = ["gyo"] };
        { jpStr = "ｳﾞｧ" ; rStr = ["va"] };{ jpStr = "ｳﾞｨ" ; rStr = ["vi";"vyi"] };{ jpStr = "ｳﾞｪ" ; rStr = ["ve";"vye"] };{ jpStr = "ｳﾞｫ" ; rStr = ["vo"] };
        { jpStr = "ｳﾞｬ" ; rStr = ["vya"] };{ jpStr = "ｳﾞｭ" ; rStr = ["vyu"] };{ jpStr = "ｳﾞｮ" ; rStr = ["vyo"] };
        { jpStr = "ｼﾞｬ" ; rStr = ["ja";"jya";"zya"] };{ jpStr = "ｼﾞｨ" ; rStr = ["jyi";"zyi"] };{ jpStr = "ｼﾞｭ" ; rStr = ["ju";"jyu";"zyu"] };{ jpStr = "ｼﾞｪ" ; rStr = ["je";"jye";"zye"] };{ jpStr = "ｼﾞｮ" ; rStr = ["jo";"jyo";"zyo"] };
        { jpStr = "ﾁﾞｬ" ; rStr = ["dya"] };{ jpStr = "ﾁﾞｨ" ; rStr = ["dyi"] };{ jpStr = "ﾁﾞｭ" ; rStr = ["dyu"] };{ jpStr = "ﾁﾞｪ" ; rStr = ["dye"] };{ jpStr = "ﾁﾞｮ" ; rStr = ["dyo"] };
        { jpStr = "ﾃﾞｬ" ; rStr = ["dha"] };{ jpStr = "ﾃﾞｨ" ; rStr = ["dhi"] };{ jpStr = "ﾃﾞｭ" ; rStr = ["dhu"] };{ jpStr = "ﾃﾞｪ" ; rStr = ["dhe"] };{ jpStr = "ﾃﾞｮ" ; rStr = ["dho"] };
        { jpStr = "ﾋﾞｬ" ; rStr = ["bya"] };{ jpStr = "ﾋﾞｨ" ; rStr = ["byi"] };{ jpStr = "ﾋﾞｭ" ; rStr = ["byu"] };{ jpStr = "ﾋﾞｪ" ; rStr = ["bye"] };{ jpStr = "ﾋﾞｮ" ; rStr = ["byo"] };
        { jpStr = "ﾋﾟｬ" ; rStr = ["pya"] };{ jpStr = "ﾋﾟｨ" ; rStr = ["pyi"] };{ jpStr = "ﾋﾟｭ" ; rStr = ["pyu"] };{ jpStr = "ﾋﾟｪ" ; rStr = ["pye"] };{ jpStr = "ﾋﾟｮ" ; rStr = ["pyo"] };
        { jpStr = "ｯｶ" ; rStr = ["kka"] };{ jpStr = "ｯｷ" ; rStr = ["kki"] };{ jpStr = "ｯｸ" ; rStr = ["kku"] };{ jpStr = "ｯｹ" ; rStr = ["kke"] };{ jpStr = "ｯｺ" ; rStr = ["kko"] };
        { jpStr = "ｯｶﾞ" ; rStr = ["gga"] };{ jpStr = "ｯｷﾞ" ; rStr = ["ggi"] };{ jpStr = "ｯｸﾞ" ; rStr = ["ggu"] };{ jpStr = "ｯｹﾞ" ; rStr = ["gge"] };{ jpStr = "ｯｺﾞ" ; rStr = ["ggo"] };
        { jpStr = "ｯｻ" ; rStr = ["ssa"] };{ jpStr = "ｯｼ" ; rStr = ["ssi"] };{ jpStr = "ｯｽ" ; rStr = ["ssu"] };{ jpStr = "ｯｾ" ; rStr = ["sse"] };{ jpStr = "ｯｿ" ; rStr = ["sso"] };
        { jpStr = "ｯｻﾞ" ; rStr = ["zza"] };{ jpStr = "ｯｼﾞ" ; rStr = ["zzi"] };{ jpStr = "ｯｽﾞ" ; rStr = ["zzu"] };{ jpStr = "ｯｾﾞ" ; rStr = ["zze"] };{ jpStr = "ｯｿﾞ" ; rStr = ["zzo"] };
        { jpStr = "ｯﾀ" ; rStr = ["tta"] };{ jpStr = "ｯﾁ" ; rStr = ["tti"] };{ jpStr = "ｯﾂ" ; rStr = ["ttu"] };{ jpStr = "ｯﾃ" ; rStr = ["tte"] };{ jpStr = "ｯﾄ" ; rStr = ["tto"] };
        { jpStr = "ｯﾀﾞ" ; rStr = ["dda"] };{ jpStr = "ｯﾁﾞ" ; rStr = ["ddi"] };{ jpStr = "ｯﾂﾞ" ; rStr = ["ddu"] };{ jpStr = "ｯﾃﾞ" ; rStr = ["dde"] };{ jpStr = "ｯﾄﾞ" ; rStr = ["ddo"] };
        { jpStr = "ｯﾊ" ; rStr = ["hha"] };{ jpStr = "ｯﾋ" ; rStr = ["hhi"] };{ jpStr = "ｯﾌ" ; rStr = ["hhu";"ffu"] };{ jpStr = "ｯﾍ" ; rStr = ["hhe"] };{ jpStr = "ｯﾎ" ; rStr = ["hho"] };
        { jpStr = "ｯﾊﾞ" ; rStr = ["bba"] };{ jpStr = "ｯﾋﾞ" ; rStr = ["bbi"] };{ jpStr = "ｯﾌﾞ" ; rStr = ["bbu"] };{ jpStr = "ｯﾍﾞ" ; rStr = ["bbe"] };{ jpStr = "ｯﾎﾞ" ; rStr = ["bbo"] };
        { jpStr = "ｯﾏ" ; rStr = ["mma"] };{ jpStr = "ｯﾐ" ; rStr = ["mmi"] };{ jpStr = "ｯﾑ" ; rStr = ["mmu"] };{ jpStr = "ｯﾒ" ; rStr = ["mme"] };{ jpStr = "ｯﾓ" ; rStr = ["mmo"] };
        { jpStr = "ｯﾊﾟ" ; rStr = ["ppa"] };{ jpStr = "ｯﾋﾟ" ; rStr = ["ppi"] };{ jpStr = "ｯﾌﾟ" ; rStr = ["ppu"] };{ jpStr = "ｯﾍﾟ" ; rStr = ["ppe"] };{ jpStr = "ｯﾎﾟ" ; rStr = ["ppo"] };
        { jpStr = "ｯﾔ" ; rStr = ["yya"] };{ jpStr = "ｯｲ" ; rStr = ["yyi"] };{ jpStr = "ｯﾕ" ; rStr = ["yyu"] };{ jpStr = "ｯﾖ" ; rStr = ["yyo"] };
        { jpStr = "ｯﾗ" ; rStr = ["rra"] };{ jpStr = "ｯﾘ" ; rStr = ["rri"] };{ jpStr = "ｯﾙ" ; rStr = ["rru"] };{ jpStr = "ｯﾚ" ; rStr = ["rre"] };{ jpStr = "ｯﾛ" ; rStr = ["rro"] };
        { jpStr = "ｯﾜ" ; rStr = ["wwa"] };{ jpStr = "ｯｳ" ; rStr = ["wwu"] };{ jpStr = "ｯｦ" ; rStr = ["wwo"] };
        { jpStr = "ｲｪ" ; rStr = ["ye"] };
        { jpStr = "ｯｧ" ; rStr = ["xxa";"lxa"] };{ jpStr = "ｯｨ" ; rStr = ["xxi";"lxi";"xxyi";"llyi"] };{ jpStr = "ｯｩ" ; rStr = ["xxu";"lxu"] };{ jpStr = "ｯｪ" ; rStr = ["xxe";"lxe";"xxye";"llye"] };{ jpStr = "ｯｫ" ; rStr = ["xxo";"lxo"] };
        { jpStr = "ｯｬ" ; rStr = ["xxya";"llya"] };{ jpStr = "ｯｭ" ; rStr = ["xxyu";"llyu"] };{ jpStr = "ｯｮ" ; rStr = ["xxyo";"llyo"] };
        { jpStr = "ｯｳｨ" ; rStr = ["wwi"] };{ jpStr = "ｯｲｪ" ; rStr = ["yye"] };{ jpStr = "ｯｳｪ" ; rStr = ["wwe"] };
        { jpStr = "," ; rStr = ["､"] };{ jpStr = "." ; rStr = ["｡"] };
    ]