﻿package com.example.test05;

import org.andengine.engine.Engine.EngineLock;
import org.andengine.engine.camera.Camera;
import org.andengine.engine.camera.hud.controls.AnalogOnScreenControl;
import org.andengine.engine.camera.hud.controls.BaseOnScreenControl;
import org.andengine.engine.camera.hud.controls.DigitalOnScreenControl;
import org.andengine.engine.camera.hud.controls.AnalogOnScreenControl.IAnalogOnScreenControlListener;
import org.andengine.engine.camera.hud.controls.BaseOnScreenControl.IOnScreenControlListener;
import org.andengine.engine.handler.IUpdateHandler;
import org.andengine.engine.options.EngineOptions;
import org.andengine.engine.options.ScreenOrientation;
import org.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.andengine.entity.primitive.Rectangle;
import org.andengine.entity.scene.IOnSceneTouchListener;
import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.background.Background;
import org.andengine.entity.sprite.Sprite;
import org.andengine.entity.text.Text;
import org.andengine.entity.util.FPSLogger;
import org.andengine.input.touch.TouchEvent;
import org.andengine.opengl.font.Font;
import org.andengine.opengl.font.FontFactory;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlasTextureRegionFactory;
import org.andengine.opengl.texture.region.ITextureRegion;
import org.andengine.ui.activity.SimpleBaseGameActivity;

import com.example.test05.ResourceUtil;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;
import android.view.Menu;

public class Main extends GameBase {
	private Text text, textAka, textMid, textKoma1, textKoma2;
	private int komaCnt1, komaCnt2;
	
	private Rectangle[][] rect = new Rectangle[7][7];
	
	@Override
	public void  init() {
		scene.detachChildren();
		komaCnt1 = 0;
		komaCnt2 = 0;
		mode = 1;

		scene.drawRect(0, 0, 448, 448);
		for(int y = 0 ; y < 7 ; y++){
			for(int x = 0 ; x < 7 ; x++){
				rect[x][y] = scene.drawRect(x*64+1, y*64+1, 62, 62);
				if(y == 0){
					rect[x][y].setTag(1);
					rect[x][y].setColor(1, 0, 0 );
				}
				else if(y == 6){
					rect[x][y].setTag(2);
					rect[x][y].setColor(0, 1, 0 );
				}
				else{
					rect[x][y].setTag(0);
					rect[x][y].setColor(0, 0, 0 );
				}
			}
		}
		
		scene.drawText(432, 0, "はさみ将棋");
		textAka = scene.drawText(448, 64, ">赤");
		textKoma1 = scene.drawText(500, 64, "☆☆☆");
		textMid = scene.drawText(448, 96, " 緑");
		textKoma2 = scene.drawText(500, 96, "☆☆☆");
		text = scene.drawText(448, 154, "      ");
	}
	
	@Override
	public void update(){
		//t.setText("" + cnt);
	}
	
	private int mode = 1;
	private int px,py;
	@Override
	public void touchControl(int id, float x, float y){
		//t.setText("" + id);
		if (id == 9){
			if(komaCnt1 >= 3 || komaCnt2 >= 3){
				init();
				return;
			}
			if(x < 448 && y < 448){
				int xx = (int)x/64;
				int yy = (int)y/64;
				if ( rect[xx][yy].getTag() == mode ){
					px = xx;
					py = yy;
					
					//移動箇所のクリア
					for(int i = 0 ; i < 7 ;i++){
						for(int j = 0 ; j < 7 ;j++){
							if(rect[i][j].getTag() == 3){
								rect[i][j].setTag(0);
							}
						}
					}
					
					//移動箇所設定
					int cx,cy;
					int[] tx = {-1,1,0,0};
					int[] ty = {0,0,-1,1};
					for(int i = 0 ; i < 4 ;i++){
						cx = 0; cy = 0;
						while(true){
							cx+=tx[i]; cy+=ty[i];
							if( xx + cx < 0 || xx + cx >= 7 || yy + cy < 0 || yy + cy >= 7  ) break;
							if( rect[ xx + cx ][ yy + cy ].getTag() == 0 ){
								rect[ xx + cx ][ yy + cy ].setTag(3);
							}else{
								break;
							}
						}
					}
					
				}else if( rect[xx][yy].getTag() == 3 ){
					//移動処理
					rect[px][py].setTag(0);
					rect[xx][yy].setTag(mode);
					px = xx; py = yy;
					
					//移動範囲消去
					for(int i = 0 ; i < 7 ;i++){
						for(int j = 0 ; j < 7 ;j++){
							if(rect[i][j].getTag() == 3){
								rect[i][j].setTag(0);
							}
						}
					}
					
					if (mode == 1){
						komaCnt1 += komaTori1(xx,yy);//こまを取る処理（はさんだ場合）
						komaCnt1 += komaTori2(xx,yy);//こまを取る処理（囲った場合）
					}else{
						komaCnt2 += komaTori1(xx,yy);
						komaCnt2 += komaTori2(xx,yy);
					}
					
					//先攻後攻切り替え
					if(mode == 1) mode = 2;
					else if(mode == 2) mode = 1;
				}
				
				//カラー設定
				for(int i = 0 ; i < 7 ;i++){
					for(int j = 0 ; j < 7 ;j++){
						if(rect[i][j].getTag() == 0) rect[i][j].setColor(0, 0, 0);
						else if(rect[i][j].getTag() == 1) rect[i][j].setColor(1, 0, 0);
						else if(rect[i][j].getTag() == 2) rect[i][j].setColor(0, 1, 0);
						else if(rect[i][j].getTag() == 3) rect[i][j].setColor(0.5f, 0.5f, 0.5f);
					}
				}
				
				//テキスト設定
				String s = "";
				for(int i = 0 ; i < 3 ; i++){
					if(komaCnt1 <= i) s += "☆";
					else s+= "★";
				}
				textKoma1.setText(s);
				
				s = "";
				for(int i = 0 ; i < 3 ; i++){
					if(komaCnt2 <= i) s += "☆";
					else s+= "★";
				}
				textKoma2.setText(""+s);
				
				if(mode == 1){
					textAka.setText(">赤");
					textMid.setText(" 緑");
				}else{
					textAka.setText(" 赤");
					textMid.setText(">緑");
				}
				
				if(komaCnt1 >= 3){
					text.setText("赤の勝ち!");
				}else if(komaCnt2 >= 3){
					text.setText("緑の勝ち!");
				}else{
					text.setText("");
				}
			}
		}
	}
	
	private int komaTori1(int x, int y){
		//こまを取る処理(はさんだ場合)
		int cnt = 0;
		int cx,cy;
		int[] tx = {-1,1,0,0};
		int[] ty = {0,0,-1,1};
		for(int i = 0 ; i < 4 ;i++){
			//取れるコマがあるかチェック
			boolean chk = false;
			cx = 0; cy = 0;
			while(true){
				cx+=tx[i]; cy+=ty[i];
				if( x + cx < 0 || x + cx >= 7 || y + cy < 0 || y + cy >= 7  ) break;
				if( rect[ x + cx ][ y + cy ].getTag() == mode ){
					chk = true;
					break;
				}else if( rect[ x + cx ][ y + cy ].getTag() == 0 ){
					break;
				}
			}
			
			//とる(もう一度ループ)
			if(chk == true){
				cx = 0; cy = 0;
				while(true){
					cx+=tx[i]; cy+=ty[i];
					if( x + cx < 0 || x + cx >= 7 || y + cy < 0 || y + cy >= 7  ) break;
					if( rect[ x + cx ][ y + cy ].getTag() == mode ){
						break;
					}else{
						rect[ x + cx ][ y + cy ].setTag(0);
						cnt++;
					}
				}
			}
		}
		return cnt;
	}
	
	boolean[][] bk_tag;
	private int komaTori2(int x, int y){
		//こまを取る処理(囲んだ場合)
		int cnt = 0;
		int[] tx = {-1,1,0,0};
		int[] ty = {0,0,-1,1};
		String s = "";
		for(int i = 0 ; i < 4 ;i++){
			bk_tag = new boolean[7][7];
			bk_tag[x][y] = true;
			//取れるコマがあるかチェック
			boolean chk = false;
			if(kakoiChk(x + tx[i] , y + ty[i])){
				cnt += kakoiTori(x + tx[i] , y + ty[i]);
			}
		}
		return cnt;
	}
	
	//囲っているかどうかチェック
	private boolean kakoiChk(int x,int y){
		if(x < 0 || x >= 7 || y < 0 || y >= 7) return true;
		if(rect[x][y].getTag() == mode) return true;
		if(rect[x][y].getTag() == 0) return false;
		
		int[] tx = {-1,1,0,0};
		int[] ty = {0,0,-1,1};
		boolean bk = true;
		bk_tag[x][y] = true;
		for(int i = 0 ; i < 4 ; i++){
			if(x+tx[i] < 0 || x+tx[i] >= 7 || y+ty[i] < 0 || y+ty[i] >= 7){
			}else{
				if(bk_tag[x+tx[i]][y+ty[i]] == false){
					if( kakoiChk(x+tx[i],y+ty[i]) == false ){
						bk = false;
					}
				}
			}
		}
		return bk;
	}
	
	//囲っているこまを取る
	private int kakoiTori(int x,int y){
		if(x < 0 || x >= 7 || y < 0 || y >= 7) return 0;
		if(rect[x][y].getTag() == mode) return 0;
		if(rect[x][y].getTag() == 0) return 0;
		
		int[] tx = {-1,1,0,0};
		int[] ty = {0,0,-1,1};
		int bk = 1;
		rect[x][y].setTag(0);
		for(int i = 0 ; i < 4 ; i++){
			if(x+tx[i] < 0 || x+tx[i] >= 7 || y+ty[i] < 0 || y+ty[i] >= 7){
			}else{
				if(rect[x+tx[i]][y+ty[i]].getTag() != 0){
					bk += kakoiTori(x+tx[i],y+ty[i]);
				}
			}
		}
		return bk;
	}
}

class GameBase extends SimpleBaseGameActivity implements IOnSceneTouchListener {

	private static final int CAMERA_WIDTH = 800;
	private static final int CAMERA_HEIGHT = 480;
	
	private BitmapTextureAtlas mOnScreenControlTexture;
	private ITextureRegion mOnScreenControlBaseTextureRegion;
	private ITextureRegion mOnScreenControlKnobTextureRegion;
	
	private Camera camera;
	private Scene baseScene;
	public ResourceUtil scene;
	
	@Override
	public EngineOptions onCreateEngineOptions() {
		camera = new Camera(0, 0, CAMERA_WIDTH, CAMERA_HEIGHT);
		EngineOptions engineOptions =  new EngineOptions(true, ScreenOrientation.LANDSCAPE_FIXED, new RatioResolutionPolicy(CAMERA_WIDTH, CAMERA_HEIGHT), camera);
		engineOptions.getTouchOptions().setNeedsMultiTouch(true);
		return engineOptions;
	}

	@Override
	public void onCreateResources() {
		
		//コントローラー関係
		BitmapTextureAtlasTextureRegionFactory.setAssetBasePath("gfx/");
		this.mOnScreenControlTexture = new BitmapTextureAtlas(this.getTextureManager(), 256, 128, TextureOptions.BILINEAR);
		this.mOnScreenControlBaseTextureRegion = BitmapTextureAtlasTextureRegionFactory.createFromAsset(this.mOnScreenControlTexture, this, "onscreen_control_base.png", 0, 0);
		this.mOnScreenControlKnobTextureRegion = BitmapTextureAtlasTextureRegionFactory.createFromAsset(this.mOnScreenControlTexture, this, "onscreen_control_knob.png", 128, 0);
		this.mOnScreenControlTexture.load();
	}
	
	public void init(){
		
	}

	@Override
	public Scene onCreateScene() {
		this.mEngine.registerUpdateHandler(new FPSLogger());
		
		//ベースのシーン
		baseScene = new Scene();
		baseScene.setBackground(new Background(1, 1, 1));
		baseScene.setTouchAreaBindingOnActionDownEnabled(true);//エリアのタッチ有効に
		baseScene.setOnSceneTouchListener(this);//シーンのタッチを有効に
		
		scene = new ResourceUtil(this);
		baseScene.attachChild(scene);
		init();
		
		//矩形の表示
		final Rectangle coloredRect = new Rectangle(0, 0, 100, 480, this.getVertexBufferObjectManager());
		coloredRect.setColor(1.0f, 1.0f, 1.0f);
		baseScene.attachChild(coloredRect);
		
		final Rectangle coloredRect2 = new Rectangle(700, 0, 800, 480, this.getVertexBufferObjectManager());
		coloredRect.setColor(1.0f, 1.0f, 1.0f);
		baseScene.attachChild(coloredRect2);
		
		//左アナログコントローラー
		final AnalogOnScreenControl analogOnScreenControl1 =
			 new AnalogOnScreenControl(
			  0, CAMERA_HEIGHT - ( this.mOnScreenControlBaseTextureRegion.getHeight() * 2 ), this.camera,
			  this.mOnScreenControlBaseTextureRegion, this.mOnScreenControlKnobTextureRegion, 0.1f, 200,
			  this.getVertexBufferObjectManager(), new IAnalogOnScreenControlListener() {
				
				//移動時
				@Override
				public void onControlChange(final BaseOnScreenControl pBaseOnScreenControl, final float pValueX, final float pValueY) {
					if(pValueX != 0 && pValueY != 0 ){
						touchControl(5, pValueX, pValueY);
					}
				}
				
				//クリック時
				@Override
				public void onControlClick(final AnalogOnScreenControl pAnalogOnScreenControl) {
				}
				
			});
		baseScene.setChildScene(analogOnScreenControl1);
		
		//右アナログコントローラーの表示
		final AnalogOnScreenControl analogOnScreenControl2 =
			 new AnalogOnScreenControl(
			  CAMERA_WIDTH - this.mOnScreenControlBaseTextureRegion.getWidth(),
			  CAMERA_HEIGHT - ( this.mOnScreenControlBaseTextureRegion.getHeight() * 2 ), this.camera,
			  this.mOnScreenControlBaseTextureRegion, this.mOnScreenControlKnobTextureRegion, 0.1f, 200,
			  this.getVertexBufferObjectManager(), new IAnalogOnScreenControlListener() {
				
				//移動時
				@Override
				public void onControlChange(final BaseOnScreenControl pBaseOnScreenControl, final float pValueX, final float pValueY) {
					if(pValueX != 0 && pValueY != 0 ){
						touchControl(6, pValueX, pValueY);
					}
				}
				
				//クリック時
				@Override
				public void onControlClick(final AnalogOnScreenControl pAnalogOnScreenControl) {
				}
				
			});
		analogOnScreenControl1.setChildScene(analogOnScreenControl2);
		
		//デジタルコントローラーの表示
		final DigitalOnScreenControl digitalOnScreenControl = new DigitalOnScreenControl(
				0, CAMERA_HEIGHT - this.mOnScreenControlBaseTextureRegion.getHeight(),
				this.camera, this.mOnScreenControlBaseTextureRegion,
				this.mOnScreenControlKnobTextureRegion, 0.1f, this.getVertexBufferObjectManager(), new IOnScreenControlListener() {
			
				@Override
				public void onControlChange(final BaseOnScreenControl pBaseOnScreenControl, final float pValueX, final float pValueY) {
					if(pValueX != 0 || pValueY != 0 ){
						touchControl(7, pValueX, pValueY);
					}
				}
		});
		analogOnScreenControl2.setChildScene(digitalOnScreenControl);
		
		//ボタンの追加
		int cnt = 0;
		for(int i = 0 ; i < 2 ; i++){
			for (int j = 0 ; j < 2 ; j++){
				cnt++;
				final Sprite btn = new Sprite(0, 0, this.mOnScreenControlKnobTextureRegion, this.getVertexBufferObjectManager()) {
					@Override
					public boolean onAreaTouched(final TouchEvent pSceneTouchEvent, final float pTouchAreaLocalX, final float pTouchAreaLocalY) {
						if(pSceneTouchEvent.isActionDown()){
							touchControl(this.mTag, pTouchAreaLocalX, pTouchAreaLocalY);
						}
						return true;
					}
					
				};
				btn.setPosition(CAMERA_WIDTH - ( btn.getWidth() * (j+1) ), CAMERA_HEIGHT - ( btn.getHeight() * (i+1) ) );
				btn.setTag(cnt);
				baseScene.attachChild(btn);
				baseScene.registerTouchArea(btn);
			}
		}


		/*更新 */
		baseScene.registerUpdateHandler(new IUpdateHandler() {
			@Override
			public void reset() { }

			@Override
			public void onUpdate(final float pSecondsElapsed) {
				update();
			}
		});

		return baseScene;
	}
	
	public void update(){}
	public void touchControl(int id, float x,float y){}

	@Override
	public boolean onSceneTouchEvent(Scene pScene, TouchEvent pSceneTouchEvent) {
		final EngineLock engineLock = this.mEngine.getEngineLock();
		engineLock.lock();
			if(pSceneTouchEvent.isActionDown() && pSceneTouchEvent.getX() >= 100 && pSceneTouchEvent.getX() < 700){
				touchControl(9, pSceneTouchEvent.getX()-100, pSceneTouchEvent.getY());
			}
		engineLock.unlock();
		return true;
	}
}

class StopWatch {

    private long startTime = 0;
    private long stopTime = 0;
    private long elapsed = 0;
    private boolean running = false;


    public void start() {
        this.startTime = System.nanoTime();
        this.running = true;
    }


    public void stop() {
        this.stopTime = System.nanoTime();
        this.running = false;
    }

    public void reset() {
        this.startTime = 0;
        this.stopTime = 0;
        this.running = false;
    }

    //elaspsed time in microseconds
    public long getElapsedTimeMicro() {
        if (running) {
            elapsed = ((System.nanoTime() - startTime) / 1000);
        }
        else {
            elapsed = ((stopTime - startTime) / 1000);
        }
        return elapsed;
    }

    //elaspsed time in milliseconds
    public long getElapsedTimeMilli() {
        if (running) {
            elapsed = ((System.nanoTime() - startTime) / 1000000);
        }
        else {
            elapsed = ((stopTime - startTime) / 1000000);
        }
        return elapsed;
    }
    
    @Override
    public String toString(){
    	long time = getElapsedTimeMilli();
		return "" + (time/1000) + "." + (time%1000);
    }
}
