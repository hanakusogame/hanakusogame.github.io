/** Automatically generated file. DO NOT MODIFY */
package test.test.test05;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}