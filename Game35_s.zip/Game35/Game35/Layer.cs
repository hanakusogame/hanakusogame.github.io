﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Ink;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Game35 {
    //レイヤークラス
    [Serializable()]
    public class Layer {
        [NonSerialized()]
        public StrokeCollection sc = new StrokeCollection();

        public bool visible = true;
        public int alpha = 100;
        public int baseId;
        public int id;

        private MemoryStream ms;

        public Layer() { }
        public Layer(int bID , int ID) {
            baseId = bID;
            id = ID;
        }

        //ストロークをメモリストリーム形式に変換
        public void save() {
            ms = new MemoryStream();
            sc.Save(ms);
        }

        //メモリストリームをストロークに変換
        public void load() {
            ms.Position = 0;
            sc = new StrokeCollection(ms);
            ms.Dispose();
        }

        public override string ToString() {
            string s;
            if (visible) s = "■";
            else s = "□";
            return s + id + ":[" + alpha + "]";
            //return "" + baseId + ":" + id + ":" + visible;
        }
    }

    //レイヤー管理クラス
    [Serializable()]
    public class LayerManager {
        public List<Layer> list { get; set; }
        public Layer crt { get; set; }

        public LayerManager() {
            list = new List<Layer>();
        }

        private int createID(int baseId) {
            List<Layer> bk_list = list.FindAll(i => i.baseId == baseId);
            int id = 0;
            while (bk_list.Exists(i => i.id == id)) id++;
            return id;
        }

        //追加
        public void add() { add(crt.baseId); }
        public void add(int baseId) {
            crt = new Layer( baseId , createID(baseId) );
            list.Add(crt);
        }

        //コピー
        public void copy() { copy(crt.baseId); }
        public void copy(int baseId) {
            Layer bk_layer = crt;
            crt = new Layer(baseId , createID(baseId) );
            list.Add(crt);
            crt.sc = bk_layer.sc.Clone();
        }

        //カレント削除
        public void del() {
            if (list.FindAll(l => l.baseId == crt.baseId).Count() <= 1) return;
            list.Remove(crt);
            crt = list.Find(l => l.baseId == crt.baseId);
        }

        //全部削除(現在地が行方不明になるので注意)
        public void delAll(int baseId) {
            list.RemoveAll(i => i.baseId == baseId);
        }

        //移動
        public void move(int pos) {
            List<Layer> bk_list = list.FindAll(la => la.baseId == crt.baseId);
            int i = bk_list.FindIndex(la => la == crt);
            if (i + pos >= bk_list.Count || i + pos < 0) return;
            bk_list.RemoveAt(i);
            bk_list.Insert(i + pos, crt);
            list.RemoveAll(la => la.baseId == crt.baseId);
            list.AddRange(bk_list);
        }

        //変更
        public void changeCrt(Layer layer) {
            crt = layer;
        }

        //DrawingVisual生成test
        public DrawingVisual createDV(Layer layer) {
            // 描画先を作成
            DrawingVisual dv = new DrawingVisual();
            DrawingContext dc = dv.RenderOpen();
            layer.sc.Draw(dc);
            dc.Close();
            dv.Opacity = layer.alpha / 100.0;
            return dv;
        }

        //画像生成test
        public void createImage(RenderTargetBitmap rtb, int baseId) {
            // 上記で作成した描画エリア(dc)にInkCanvasのストロークを描画
            list.FindAll(la => la.baseId == baseId)
                .ForEach(la => rtb.Render(createDV(la)));
        }
    }
}
