﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game35 {
    //シーンクラス
    [Serializable()]
    public class Scene {
        public double start { get; set; }
        public double end { get; set; }
        public int linkId { get; set; }
        public int id { get; set; }

        public Scene(int i, int li) {
            id = i;
            linkId = li;
            start = 0.0;
            end = 10.0;
        }

        public override string ToString() {
            //return "" + id + ":" + linkId + ":[" + (start.ToString("00.00")) + "-" + ((start + time).ToString("00.00")) + "]";
            return "[" + (start.ToString("00.00")) + "-" + (end.ToString("00.00")) + "]";
        }
    }

    //シーン管理クラス
    [Serializable()]
    public class SceneManager {
        public List<Scene> list { get; set; }
        public Scene crt { get; set; }
        public CutManager cm;

        public SceneManager(CutManager CM){
            cm = CM;
            list = new List<Scene>();
        }

        //追加
        public void add() {
            int id = 0;
            while (list.Exists(i => i.id == id)) id++;
            list.Add(crt = new Scene(id, id));
            cm.add(crt.linkId);
        }

        //コピー
        public void copy() {
            List<Cut> bk_cutList = cm.list.FindAll(tl => tl.baseId == crt.id);
            int id = 0;
            while (list.Exists(i => i.id == id)) id++;
            list.Add(crt = new Scene(id, id));
            foreach (Cut c in bk_cutList) {
                cm.crt = c;
                cm.copy(crt.linkId);
            }
        }

        //削除
        public void del() {
            if (list.Count <= 1) return;

            int bkId = crt.id;
            int i = list.FindIndex(tl => tl == crt);
            list.Remove(crt);//削除
            if (i != 0) crt = list[i - 1];
            else crt = list[0];//現在シーン設定
            cm.delAll(bkId, crt.id);//コマ削除

            cm.move(0);
        }

        //移動
        public void move(int pos) {
            int i = list.FindIndex(tl => tl == crt);
            if (i + pos >= list.Count || i + pos < 0) return;
            list.RemoveAt(i);
            list.Insert(i + pos, crt);
        }

        //変更
        public void changeCrt(Scene tl) {
            crt = tl;
            cm.changeCrt(cm.list.Find(c => c.baseId == crt.linkId));
        }
    }
}
