﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Game35 {
    //コマクラス
    [Serializable()]
    public class Cut {
        public double time = 0.5;
        //private string name;
        public int baseId;
        public int id;
        public int linkId;

        public Cut(int bi, int i, int li) {
            baseId = bi;
            id = i;
            linkId = li;
        }

        public override string ToString() {
            //return "" + baseId + ":" + id + ":" + linkId + " [" + (time.ToString("00.00")) + "]";
            return "" + (id+1) + ": [" + (time.ToString("00.00")) + "]";
        }
    }

    //コマ管理クラス
    [Serializable()]
    public class CutManager {
        public List<Cut> list { get; set; }
        public Cut crt {get; set;}//現在地
        public LayerManager lm;

        //コンストラクタ
        public CutManager(LayerManager LM) {
            list = new List<Cut>();
            lm = LM;
        }

        //id作成
        private int createId(int baseId){
            List<Cut> bk_list = list.FindAll(i => i.baseId == baseId);
            int id = 0;
            while (bk_list.Exists(i => i.id == id)) id++;
            return id;
        }

        //追加
        public void add() { add(crt.baseId); }
        public void add(int baseId) {
            int id = 0;
            while (list.Exists(i => i.linkId == id)) id++;
            list.Add(crt = new Cut(baseId, createId(baseId), id));
            lm.add(crt.linkId);
        }

        //コピー
        public void copy() { copy(crt.baseId); }
        public void copy(int baseId) {
            List<Layer> bk_LList = lm.list.FindAll(l => crt.linkId == l.baseId);
            int id = 0;
            while (list.Exists(i => i.linkId == id)) id++;
            list.Add(crt = new Cut(baseId, createId(baseId), id));

            foreach (Layer l in bk_LList) {
                lm.crt = l;
                lm.copy(id);
            }
        }

        //カレント削除
        public void del() {
            List<Cut> bk_cl = list.FindAll(c => c.baseId == crt.baseId);
            if (bk_cl.Count() <= 1) return;
            lm.delAll(crt.linkId);//レイヤーを消す

            int i = bk_cl.FindIndex(c => c == crt);
            list.Remove(crt);
            if (i != 0) crt = bk_cl[i - 1];
            else crt = bk_cl[1];

            lm.crt = lm.list.Find(l => l.baseId == crt.linkId);
        }

        //全削除
        public void delAll(int baseId , int next){
            list.FindAll(i => i.baseId == baseId).ForEach(i => lm.delAll(i.linkId));
            list.RemoveAll(i => i.baseId == baseId);
            crt = list.Find(c => c.baseId == next);
            lm.crt = lm.list.Find(l => l.baseId == next);
        }

        //移動
        public void move(int pos) {
            List<Cut> bk_list = list.FindAll(c => c.baseId == crt.baseId);
            int i = bk_list.FindIndex(c => c == crt);
            if (i + pos >= bk_list.Count || i + pos < 0) return;
            bk_list.RemoveAt(i);
            bk_list.Insert(i + pos, crt);
            list.RemoveAll(c => c.baseId == crt.baseId);
            list.AddRange(bk_list);
        }

        //変更
        public void changeCrt(Cut cut) {
            crt = cut;
            lm.changeCrt(lm.list.Find(l => l.baseId == crt.linkId));
        }
    }
}
