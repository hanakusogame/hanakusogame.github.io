﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Game35 {
    class Player {
        private Stopwatch sw = new Stopwatch();
        public int state = 0;
        private SceneManager sm;
        private CutManager cm;
        private LayerManager lm;
        public RenderTargetBitmap rtb;
        public double startTime = 0;
        public double endTime = 0;
        public double nowTime = 0;

        public Player(SceneManager _sm, CutManager _cm, LayerManager _lm) {
            sm = _sm; cm = _cm; lm = _lm;
            rtb = new RenderTargetBitmap(320, 240, 96, 96, PixelFormats.Default);
        }

        public void update() {
            if (sw.IsRunning) {
                double d = sw.Elapsed.TotalSeconds;
                if (endTime > d) {
                    nowTime = d;
                    List<Scene> sl = sm.list.FindAll(i => i.start <= d && i.end > d);
                    rtb.Clear();
                    foreach (Scene s in sl) {
                        List<Cut> cl = cm.list.FindAll(i => i.baseId == s.linkId);
                        double allTime = cl.Sum(i => i.time);
                        double cnt = 0;
                        foreach (Cut c in cl) {
                            cnt += c.time;
                            if ((d - s.start) % allTime < cnt) {
                                lm.createImage(rtb, c.linkId);
                                break;
                            }
                        }
                    }
                }
                else {
                    sw.Restart();
                }
            }
        }

        public void init(double  stime, double etime) {
            startTime = stime;
            endTime = etime;
            state = 1;
        }

        public void start() {
            if (state == 1) { sw.Start(); state = 2; }
            else if (state == 2) { sw.Stop(); state = 1; }
        }

        public void reset() {
            sw.Reset();
            state = 0;
        }

        public override string ToString() {
            return sw.Elapsed.ToString().Substring(3);
        }
    }
}
