﻿using System;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using Imaging = System.Drawing.Imaging;

namespace Game35 {
    class B {
        /// <summary>
        /// BitmapSource をARGB形式の Bitmap に変換する。
        /// </summary>
        /// <param name="src">BitmapSource 。</param>
        /// <returns>Bitmap 。</returns>
        public static Bitmap Convert(BitmapSource src) {
            // フォーマットが異なるならば変換
            BitmapSource s = src;
            if (s.Format != PixelFormats.Bgra32) {
                s = new FormatConvertedBitmap(
                    s,
                    PixelFormats.Bgra32,
                    null,
                    0);
                s.Freeze();
            }

            // ピクセルデータをコピー
            int width = (int)s.Width;
            int height = (int)s.Height;
            int stride = width * 4;
            byte[] datas = new byte[stride * height];
            s.CopyPixels(datas, stride, 0);

            // Bitmap へピクセルデータ書き出し
            Bitmap dest = new Bitmap(
                width,
                height,
                Imaging::PixelFormat.Format32bppArgb);
            Imaging::BitmapData destBits = null;
            try {
                destBits = dest.LockBits(
                    new Rectangle(0, 0, width, height),
                    Imaging::ImageLockMode.WriteOnly,
                    Imaging::PixelFormat.Format32bppArgb);
                Marshal.Copy(datas, 0, destBits.Scan0, datas.Length);
            }
            catch {
                dest.Dispose();
                dest = null;
                throw;
            }
            finally {
                if (dest != null && destBits != null) {
                    dest.UnlockBits(destBits);
                }
            }

            return dest;
        }
    }
}
