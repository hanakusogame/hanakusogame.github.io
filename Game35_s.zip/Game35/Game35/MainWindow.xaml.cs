﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using D = System.Drawing;

using AForge.Video.VFW;

using System.Runtime.InteropServices;
using System.Windows.Ink;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Microsoft.Win32;
using System.Reflection;

namespace Game35 {

    //ウィンドウクラス
    public partial class MainWindow : Window {
        private LayerManager lm;
        private CutManager cm;
        private SceneManager sm;
        private Player player;

        //オニオンスキン用背景関連
        RenderTargetBitmap backImage = new RenderTargetBitmap(320, 240, 96, 96, PixelFormats.Default);
        bool backImageFlg = false;

        InkCanvas crtIk = new InkCanvas();
        private string fileName;

        bool chgIventEscFlg = false;//リスボックス変更時のイベントを避けるためのフラグ

        //[DllImport("AviWave.dll", CallingConvention = CallingConvention.Cdecl)]
        //static extern void AviAndWave(string a, string b, string c);

        //メインウィンドウ
        public MainWindow() {
            InitializeComponent();
            init();
            image1.Source = backImage;
            CompositionTarget.Rendering += CompositionTarget_Rendering;
        }

        //初期化処理
        private void init() {
            lm = new LayerManager();
            cm = new CutManager(lm);
            sm = new SceneManager(cm);
            player = new Player(sm, cm, lm);
            image2.Source = player.rtb;
            fileName = "";
            this.Title = "アニメ制作ツール";
            sm.add(); update();
        }


        public void updateTL() {
            listboxTL.ItemsSource = sm.list.FindAll(tl => true);
            listboxTL.SelectedValue = sm.crt;
        }

        public void updateCut() {
            listboxCut.ItemsSource = cm.list.FindAll(cut => cut.baseId == sm.crt.linkId);
            listboxCut.SelectedValue = cm.crt;
        }

        public InkCanvas createInkCvs(StrokeCollection sc) {
            InkCanvas ic = new InkCanvas();
            ic.Width = 320; ic.Height = 240;
            ic.Background = null;
            ic.Strokes = sc;
            return ic;
        }

        public void updateLayer() {
            LabelLyaerCnt.Content = lm.list.Count;
            LabelCutCnt.Content = cm.list.Count;
            LabelTLCnt.Content = sm.list.Count;

            List<Layer> bkLList = lm.list.FindAll(layer => layer.baseId == cm.crt.linkId);
            listboxLayer.ItemsSource = bkLList;
            listboxLayer.SelectedValue = lm.crt;

            for (int i = 0; i < bkLList.Count; i++) {
                InkCanvas nowInkCvs;
                //レイヤー作成(既に作られている場合は使いまわす)
                if (i >= canvas2.Children.Count) {
                    nowInkCvs = createInkCvs(bkLList[i].sc);
                    canvas2.Children.Add(nowInkCvs);
                }
                else {
                    nowInkCvs = (InkCanvas)canvas2.Children[i];
                    nowInkCvs.Strokes = bkLList[i].sc;
                }

                //編集対象レイヤーとそれ以外で設定を変えてる
                if (lm.crt == bkLList[i]) {
                    InkCanvas bk_Ik = crtIk;
                    crtIk = nowInkCvs;
                    crtIk.IsHitTestVisible = true;
                    crtIk.EditingMode = bk_Ik.EditingMode;
                    crtIk.DefaultDrawingAttributes = bk_Ik.DefaultDrawingAttributes;
                    crtIk.DefaultDrawingAttributes.FitToCurve = true;
                }
                else {
                    nowInkCvs.IsHitTestVisible = false;
                }

                //表示可否の設定反映
                if (bkLList[i].visible) {
                    nowInkCvs.Visibility = System.Windows.Visibility.Visible;
                }
                else {
                    nowInkCvs.Visibility = System.Windows.Visibility.Hidden;
                }

                //透明度の設定反映
                nowInkCvs.Opacity = bkLList[i].alpha / 100.0;

            }
            //余ったら消す
            if (canvas2.Children.Count > bkLList.Count) {
                canvas2.Children.RemoveRange(bkLList.Count, canvas2.Children.Count);
            }
            sliderLayerAlpha.Value = lm.crt.alpha;
        }

        public void update() {
            chgIventEscFlg = true;
            updateTL();
            updateCut();
            updateLayer();
            backImageUpdate();
            chgIventEscFlg = false;
        }


        //ファイル入出力系
        //新規作成
        private void buttonFileNew_Click(object sender, RoutedEventArgs e) {
            init();
        }

        //開く
        private void buttonFileOpen_Click(object sender, RoutedEventArgs e) {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory; 
            dlg.DefaultExt = ".anime"; // Default file extension
            dlg.Filter = "Anime Files (.anime)|*.anime"; // Filter files by extension
            if (dlg.ShowDialog() == true)
            {
                FileStream fs = new FileStream(dlg.FileName, FileMode.Open, FileAccess.Read);
                BinaryFormatter f = new BinaryFormatter();
                //読み込んで逆シリアル化する
                sm = (SceneManager)f.Deserialize(fs);
                cm = sm.cm;
                lm = cm.lm;
                lm.list.ForEach(i => i.load());
                player = new Player(sm, cm, lm);
                image2.Source = player.rtb;
                fs.Close();

                fileName = dlg.FileName;
                this.Title = fileName;
                update();
            }
        }

        //保存処理のみ
        private void save(string path) {
            lm.list.ForEach(i => i.save());
            FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            //シリアル化して書き込む
            bf.Serialize(fs, sm);
            fs.Close();
        }

        //ダイアログから保存
        private void saveNew() {
            // Configure save file dialog box
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            dlg.FileName = "NewFile.anime"; // Default file name
            dlg.DefaultExt = ".anime"; // Default file extension
            dlg.Filter = "Anime Files (.anime)|*.anime"; // Filter files by extension

            if (dlg.ShowDialog() == true) {
                save(dlg.FileName);
                fileName = dlg.FileName;
            }
        }

        //別名保存
        private void buttonFileSaveNew_Click(object sender, RoutedEventArgs e) {
            saveNew();
        }

        //保存
        private void buttonFileSave_Click(object sender, RoutedEventArgs e) {
            if (fileName != "") { save(fileName); }
            else { saveNew(); }
        }

        //ＡＶＩファイル出力
        private void buttonSaveAvi_Click(object sender, RoutedEventArgs e) {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            dlg.FileName = "NewFile.avi"; // Default file name
            dlg.DefaultExt = ".avi"; // Default file extension
            dlg.Filter = "AVI Files (.avi)|*.avi"; // Filter files by extension
            if (dlg.ShowDialog() == true) {
                // 描画先を作成
                DrawingVisual dv = new DrawingVisual();
                DrawingContext dc = dv.RenderOpen();
                RenderTargetBitmap rtb = new RenderTargetBitmap(320, 240, 96, 96, PixelFormats.Default);

                // 描画エリア(dc)に四角形を作成
                Rect rectBounds = new Rect(0, 0, 320, 240);
                dc.DrawRectangle(Brushes.White, null, rectBounds);
                dc.Close();

                //我ながら理解不能
                TimeSpan ts;
                if (TimeSpan.TryParse(("00:" + textboxPlayerLen.Text), out ts)) {
                    double d = ts.TotalSeconds;
                    AVIWriter aviWriter = new AVIWriter();
                    aviWriter.Open(dlg.FileName, 320, 240);
                    for (double i = 0.0; i < ts.TotalSeconds; i += (1.0 / 25.0)) {
                        List<Scene> sl = sm.list.FindAll(j => j.start <= i && j.end > i);
                        rtb.Clear();
                        rtb.Render(dv);
                        foreach (Scene s in sl) {
                            List<Cut> cl = cm.list.FindAll(k => k.baseId == s.linkId);
                            double allTime = cl.Sum(l => l.time);
                            double cnt = 0;
                            foreach (Cut c in cl) {
                                cnt += c.time;
                                if ((i - s.start) % allTime < cnt) {
                                    lm.createImage(rtb, c.linkId);
                                    break;
                                }
                            }
                        }
                        BitmapSource bs = BitmapFrame.Create(rtb);
                        D.Bitmap b = B.Convert(bs);
                        aviWriter.AddFrame(b);
                    }
                    aviWriter.Close();
                }
            }
            //AviAndWave("test.avi", "test1.avi", "test.wav");
        }

        //-----描画モードやブラシ系-----//
        //編集モード
        private void buttonModePen_Click(object sender, RoutedEventArgs e) {
            labelMode.Content = "ペン";
            crtIk.EditingMode = InkCanvasEditingMode.Ink;
        }

        private void buttonModeErase_Click(object sender, RoutedEventArgs e) {
            labelMode.Content = "消ゴム";
            crtIk.EditingMode = InkCanvasEditingMode.EraseByPoint;
        }

        private void buttonModeSelect_Click(object sender, RoutedEventArgs e) {
            labelMode.Content = "選択";
            crtIk.EditingMode = InkCanvasEditingMode.Select;
        }

        //色設定
        private void buttonColor_Click(object sender, RoutedEventArgs e) {
            SolidColorBrush b = (SolidColorBrush)((Button)e.Source).Background;
            SolidColorBrush f = (SolidColorBrush)((Button)e.Source).Foreground;
            labelColor.Background = b;
            labelColor.Foreground = f;
            labelColor.Content = ((Button)e.Source).Name.Substring(6);
            crtIk.DefaultDrawingAttributes.Color = b.Color;
        }

        //太さ変更
        private void sliderSize_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            if (labelSize == null) return;
            labelSize.Content = sliderSize.Value;
            crtIk.DefaultDrawingAttributes.Width = sliderSize.Value;
            crtIk.DefaultDrawingAttributes.Height = sliderSize.Value;
        }

        //背景変更処理
        private void backImageUpdate() {
            if (backImageFlg) {
                backImage.Clear();
                List<Cut> cl = cm.list.FindAll(c => c.baseId == cm.crt.baseId);
                int i = cl.FindIndex(c => c == cm.crt);
                if (i != 0) {
                    Cut j = cm.list.Find(c => c == cl[i-1]);
                    lm.createImage(backImage, j.linkId);
                }
            }
        }

        //背景変更可否変更
        private void btn1_Click(object sender, RoutedEventArgs e) {
            backImageFlg = !backImageFlg;
            if (backImageFlg) {
                backImageUpdate();
            }
            else {
                backImage.Clear();
            }
        }

        //-----シーン関連-----//
        //追加
        private void buttonTLAdd_Click(object sender, RoutedEventArgs e) { sm.add(); update(); }

        //コピー
        private void buttonTLCopy_Click(object sender, RoutedEventArgs e) { sm.copy(); update(); }

        //削除
        private void buttonTLDel_Click(object sender, RoutedEventArgs e) { sm.del(); update(); }

        //変更
        private void listboxTL_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (e.AddedItems.Count == 0 || chgIventEscFlg) return;
            sm.changeCrt((Scene)e.AddedItems[0]);
            update();
        }

        //移動
        private void buttonTLUp_Click(object sender, RoutedEventArgs e) { sm.move(-1); update(); }
        private void buttonTLDown_Click(object sender, RoutedEventArgs e) { sm.move(1); update(); }

        //現在のシーンの開始時間変更
        private void textboxTLStart_TextChanged(object sender, TextChangedEventArgs e) {
            if (sm == null) return;
            double num;
            if (double.TryParse(textboxTLStart.Text, out num)) {
                sm.crt.start = num;
                listboxTL.Items.Refresh();
            }
        }

        //現在のシーンの時間変更
        private void textboxTLTime_TextChanged(object sender, TextChangedEventArgs e) {
            if (sm == null) return;
            double num;
            if (double.TryParse(textboxTLTime.Text, out num)) {
                sm.crt.end = num;
                listboxTL.Items.Refresh();
            }
        }

        //現在のシーンの時間自動設定
        private void buttonTLAuto_Click(object sender, RoutedEventArgs e) {
            int num = sm.list.FindIndex(i => sm.crt.id == i.id);
            if (num == 0) sm.crt.start = 0;
            else sm.crt.start = sm.list[num - 1].end;

            sm.crt.end =
                sm.crt.start + cm.list.FindAll(i => sm.crt.linkId == i.baseId).Sum(i => i.time);
            listboxTL.Items.Refresh();
        }

        //-----コマ関連----//
        //追加
        private void buttonCutAdd_Click(object sender, RoutedEventArgs e) { cm.add(); update(); }

        //コピー
        private void buttonCutCopy_Click(object sender, RoutedEventArgs e) { cm.copy(); update(); }

        //削除
        private void buttonCutDel_Click(object sender, RoutedEventArgs e) { cm.del(); update(); }

        //変更
        private void listboxCut_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (e.AddedItems.Count == 0 || chgIventEscFlg) return;
            cm.changeCrt((Cut)e.AddedItems[0]);
            update();
        }

        //移動
        private void buttonCutUp_Click(object sender, RoutedEventArgs e) { cm.move(-1); update(); }
        private void buttonCutDown_Click(object sender, RoutedEventArgs e) { cm.move(1); update(); }

        //現在のコマの時間設定
        private void textboxCutTime_TextChanged(object sender, TextChangedEventArgs e) {
            if (cm == null) return;
            double num;
            if (double.TryParse(textboxCutTime.Text, out num)) {
                cm.crt.time = num;
                listboxCut.Items.Refresh();
            }
        }

        //現在のコマの時間全設定
        private void buttonCutSetAll_Click(object sender, RoutedEventArgs e) {
            if (cm == null) return;
            double num;
            if (double.TryParse(textboxCutTime.Text, out num)) {
                cm.list.FindAll(i => i.baseId == cm.crt.baseId).ForEach(i => i.time = num);
                listboxCut.Items.Refresh();
            }
        }

        //-----レイヤー関連-----//
        //追加
        private void buttonLayerAdd_Click(object sender, RoutedEventArgs e) { lm.add(); update(); }

        //コピー
        private void buttonLayerCopy_Click(object sender, RoutedEventArgs e) { lm.copy(); update(); }

        //削除
        private void buttonLayerDel_Click(object sender, RoutedEventArgs e) { lm.del(); update(); }

        //変更
        private void listboxLayer_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (e.AddedItems.Count == 0 || chgIventEscFlg) return;
            lm.changeCrt((Layer)e.AddedItems[0]);
            update();
        }

        //移動
        private void buttonLayerUp_Click(object sender, RoutedEventArgs e) { lm.move(-1); update(); }
        private void buttonLayerDown_Click(object sender, RoutedEventArgs e) { lm.move(1); update(); }

        //表示非表示変更
        private void buttonLayerVisible_Click(object sender, RoutedEventArgs e) {
            if (lm == null) return;
            lm.crt.visible = !lm.crt.visible;
            listboxLayer.Items.Refresh();
            if (lm.crt.visible) crtIk.Visibility = System.Windows.Visibility.Visible;
            else crtIk.Visibility = System.Windows.Visibility.Hidden;
        }

        //現在のレイヤーの透明度設定
        private void sliderLayerAlpha_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            if (lm == null) return;
            lm.crt.alpha = (int)sliderLayerAlpha.Value;
            listboxLayer.Items.Refresh();
            labelLayerAlpha.Content = (int)sliderLayerAlpha.Value;
            crtIk.Opacity = sliderLayerAlpha.Value / 100.0;
        }

        //-----プレイヤー系の処理-----//
        //更新処理
        void CompositionTarget_Rendering(object sender, EventArgs e) {
            player.update();
            if (player.state == 2) {
                sliderPlayer.Value = player.nowTime;
                labelPlayTime.Content = player.ToString();
            }
        }

        //再生・停止ボタン
        private void buttonPlayerStart_Click(object sender, RoutedEventArgs e) {
            if (player.state == 0) {
                TimeSpan ts;
                if (TimeSpan.TryParse(("00:" + textboxPlayerLen.Text), out ts)) {
                    sliderPlayer.Maximum = ts.TotalSeconds;
                    player.init(0.0, ts.TotalSeconds);
                    Canvas.SetLeft(canvas1, 0);
                }
            }
            player.start();
            string s;
            if (player.state == 2) s = "停止"; else s = "再生";
            buttonPlayerStart.Content = s;
        }

        //リセットボタン
        private void buttonPlayerStop_Click(object sender, RoutedEventArgs e) {
            player.reset();
            buttonPlayerStart.Content = "再生";
            sliderPlayer.Value = 0;
            Canvas.SetLeft(canvas1, 440);
        }

        //裏機能（モードを右クリックでキャンバスのカーソル変更）
        private void Label_MouseRightButtonDown_1(object sender, MouseButtonEventArgs e) {
            crtIk.UseCustomCursor = !crtIk.UseCustomCursor;
        }
    }
}