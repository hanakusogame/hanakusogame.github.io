﻿//ゲームのメインの処理
module Main

open System
open System.Drawing
open System.Windows.Forms
open System.Collections.Generic
open MyGraphics; open MyInput

//なんかいまいちな選択肢クラス
type SelectBox( x:int, y:int, _l:string list) =
    let mutable l = _l
    let mutable p = 0
    let mutable flg = false//決定されたかどうか
    let mutable visible = true
    let mutable enable = true

    member this.lis
         with get() = l
         and set(value) = l <- value

    member this.v
         with get() = visible
         and set(value) =
            enable <- value
            visible <- value

    member this.draw() =
        if visible then
            setColor(Color.Black)
            fRect x y 100 (16 * l.Length)
            setColor( if enable then Color.White else Color.Gray )
            dRect x y 100 (16 * l.Length)
            setColor( if enable then Color.Red else Color.Gray )
            dRect x ( y + 16 * p ) 100 16

            //選択肢文字列表示
            setColor( if enable then Color.White else Color.Gray )
            List.iteri ( fun i s -> dStr x ( y + 16 * i ) s ) l
    
    member this.update()=
        if enable then
            let chk = (x < mPos().X && x + 100 > mPos().X && y < mPos().Y && y + 16*l.Length > mPos().Y)
            //決定
            if kPush(Keys.Enter) || (mPush(0) && chk) then
                flg <- true

            //選択(マウス)
            if chk then
                p <- (mPos().Y - y)/16

            //選択(キーボード)
            if kPush(Keys.Up  ) then
                if p = 0 then p <- ( l.Length - 1 ) else p <- p - 1
            if kPush(Keys.Down) then
                if p = (l.Length - 1 ) then p <- 0 else p <- p + 1

    member this.getVal(i) =
        if flg then
            flg <- false
            if i > 0 then
                enable <- false
            if i > 1 then
                visible <- false
            p
        else -1

    member this.init() =
        p <- 0
        flg <- false

let mutable initFlg = false
let mutable titleFlg = false
let mutable score = 0
let rnd = new Random()
let gettime() = System.Environment.TickCount
let mutable time = gettime()
let mutable now = time - gettime()

let table = [|"もぐら";"ねこ";"いぬ";"うさぎ";"ねずみ";"うし";"とら";"うま";"ひつじ";"ぶた";"とり";"うなぎ"|]

let mBoxList = new List<SelectBox>()

//リストに選択肢を追加（長いだろ）
let mBoxListAdd() =
    mBoxList.Add(SelectBox( rnd.Next(2,210), rnd.Next(2,210), [ for i in 1 .. rnd.Next(2,10) -> table.[rnd.Next(table.Length)] ]))

mBoxListAdd()

let update() =
    if initFlg = false then
        if kPush(Keys.Space) then
            time <- gettime()
            score <- 0
            initFlg <- true
            titleFlg <- true
    else
        //時間取得
        now <- (gettime() - time)/1000

        mBoxList.ForEach( fun i -> i.update() )

        mBoxList.RemoveAll(
            fun i ->
                let k = i.getVal(0)
                if k = -1 then
                    false
                else
                    if i.lis.[k] = "もぐら" then
                        score <- score + 1
                    if i.lis.[k] = "うなぎ" then
                        score <- 0
                    mBoxListAdd()
                    true
   
        ) |>ignore

        if now >= 30 then
            initFlg <- false

    g.Clear(Color.Black)
    setColor(Color.White)
    dStr 0 0 ("スコア:" + score.ToString())
    dStr 0 20 ("タイム:" + now.ToString())

    if initFlg then
        mBoxList.ForEach(fun i -> i.draw())
    else
        if titleFlg = false then
            dStr 100 110 "もぐらえらびゲーム"
            dStr 100 130 "スペースキーで開始"
            dStr 0 160 "<遊び方>"
            dStr 0 180 "もぐらを選択すると＋１点"
            dStr 0 200 "ウナギを選択すると０点になる"
            dStr 0 220 "３０秒たったら終了"
        else
            dStr 100 110 "ゲームオーバー"
            dStr 100 130 ("スコア:"+score.ToString())
    