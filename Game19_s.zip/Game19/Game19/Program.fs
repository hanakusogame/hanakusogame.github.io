﻿open Microsoft.Xna.Framework
open Microsoft.Xna.Framework.Graphics
open Microsoft.Xna.Framework.Input

//マインスイーパー
type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定

    //メンバ変数的なもの
    let g = new G.MyGraphics(this,320,240)

    let array1 = Array2D.zeroCreate 9 9 //マスの情報 0から8：周辺にいくつ地雷があるか　10:地雷
    let array2 = Array2D.zeroCreate 9 9 //マスの状態　0:開かれていない　1:開かれている　2:フラグが立っている

    let mutable initFlg = false
    let mutable clearChk = 1 //通常:0 クリア:1 ゲームオーバー:2
    let mutable px,py = 0,0 //マウス座標
    let mutable time = 0 //タイム

    let rnd = new System.Random ()//ランダム発生装置

    //初期化処理
    let init () =
        //マス目の値を全部0に戻す
        Array2D.iteri (fun y x _ -> array1.[y,x] <- 0) array1
        Array2D.iteri (fun y x _ -> array2.[y,x] <- 0) array2

        //爆弾を置く関数
        let setMine () =
            let y = rnd.Next(9)
            let x = rnd.Next(9)
            //すでに置いてあったら置かない
            if array1.[y,x] <> 10 then
                array1.[y,x] <- 10
                true
            else
                false

        //１０個おく
        for i = 1 to 10 do
            let mutable flg = false
            while not flg do
                flg <- setMine()

        //周辺を調べる関数
        let lookMine y x i =
            let mutable cnt = 0
            if i <> 10 then
                //八方向確認用テーブル
                let tableY = [| -1; 0; 1;-1; 1; -1; 0; 1 |]
                let tableX = [| -1;-1;-1; 0; 0;  1; 1; 1 |]

                for j = 0 to 7 do
                    //範囲外かどうか
                    if y + tableY.[j] >= 0 && y + tableY.[j] < 9 && x + tableX.[j] >= 0 && x + tableX.[j] < 9 then
                        //自分のマスにどんどん足していく
                        if array1.[y+ tableY.[j],x+ tableX.[j]] = 10 then array1.[y,x] <- array1.[y,x] + 1
                
        //すべてのマスの周辺を調べる
        Array2D.iteri lookMine array1
                
        initFlg <- true
        clearChk <- 0
        time <- 0

    //コンテンツ登録
    override this.LoadContent() =
        g.LoadContent()

    //ゲームロジック
    override this.Update gametime =
        km.setKey()//キー取得

        //マウス位置取得
        px <- km.ms.X
        py <- km.ms.Y

        //終了処理
        if km.kIsPush(Keys.Escape) then this.Exit()

        //初期化処理
        if not initFlg then
            if km.mIsPush(0) then
                init()
        
        //ゲーム処理
        else
            //リセット
            if km.kIsPush(Keys.Space) then init()

            //マスを開ける処理
            let rec openPanel y x =
                //八方向確認用テーブル
                let tableY = [| -1; 0; 1;-1; 1; -1; 0; 1 |]
                let tableX = [| -1;-1;-1; 0; 0;  1; 1; 1 |]

                if y >= 0 && y < 9 && x >=0 && x < 9 then
                    if array2.[ y, x ] = 0 then
                        if array1.[ y, x ] < 10 then
                            array2.[ y , x ] <- 1
                            if array1.[ y, x ] = 0 then
                                for i = 0 to 7 do
                                    openPanel (y+tableY.[i]) (x+tableX.[i])
 
            //マスを開く
            if km.mIsPush(0) then
                let x,y = py/24, px/24
                if y >= 0 && y < 9 && x >=0 && x < 9 then
                    if array2.[ x, y ] = 2 then
                        array2.[ x, y ] <- 0
                    elif array2.[ x, y ] = 0 then
                        //爆弾のとき
                        if array1.[ x, y ] = 10 then
                            clearChk <- 2
                            initFlg <- false
                        else
                            openPanel x y
                            //爆弾以外すべて開かれた場合クリア
                            let mutable sum = 0
                            for i = 0 to 8 do
                                for j = 0 to 8 do
                                    if array2.[ i, j ] = 1 then sum <- sum + 1

                            if sum = ((9*9)-10) then
                                clearChk <- 1
                                initFlg <- false
                            
            //旗を立てる&戻す
            if km.mIsPush(1) then
                if array2.[ py/24, px/24 ] = 0 then array2.[ py/24, px/24 ] <- 2
                elif array2.[ py/24, px/24 ] = 2 then array2.[ py/24, px/24 ] <- 0

            time <- time+1
        
        base.Update gametime
        
    //描画処理
    override this.Draw gametime =
        g.Clear(Color.Black)//画面のクリア

        //マスの背景描画
        let tableColor = [| Color.White; Color.Yellow; Color.Red |] 
        Array2D.iteri (fun y x i -> g.FillRect(x*24,y*24,23,23, tableColor.[clearChk])) array2
 
              
        //マスの数字描画関数
        g.SetColor(Color.Black)
        let drawMine y x i =
            if i = 10 then g.DrawTextM("*",x*24,y*24)
            if i > 0 && i < 10 then g.DrawTextM(i.ToString(),x*24,y*24)

        Array2D.iteri drawMine array1
        
        //マスの前景描画
        if clearChk = 0 then
            let drawPanel y x i = 
                 if i = 0 || i = 2 then g.FillRect(x*24,y*24,23,23, Color.Gray)
                 if i = 2 then g.DrawTextM("P",x*24,y*24)

            Array2D.iteri drawPanel array2

        //マウス位置描画
        g.DrawRect(px/24*24,py/24*24,23,23,Color.Red)

        //情報描画
        g.DrawTextM ("タイム:" + (time/60).ToString() , 0, 220, Color.White)

        if clearChk = 1 then g.DrawTextM ("クリア!!" , 128, 220, Color.Yellow)
        if clearChk = 2 then g.DrawTextM ("ばくし!!" , 128, 220, Color.Yellow)

        g.DrawTextM ("マイン" , 220, 0, Color.Cyan)
        g.DrawTextM ("スイーパー" , 220, 20, Color.Cyan)

        g.DrawTextM ("マス" , 220, 45, Color.Lime)
        g.DrawTextM (" 9X9" , 220, 65, Color.Lime)

        g.DrawTextM ("じらい" , 220, 90, Color.Yellow)
        g.DrawTextM (" 10こ" , 220, 110, Color.Yellow)

        g.DrawTextS ("<あそびかた>" , 220, 140, Color.White)
        g.DrawTextS (" じらいをさけて、からの" , 220, 150, Color.White)
        g.DrawTextS (" マスをすべてひらけ!" , 220, 160, Color.White)

        g.DrawTextS ("<そうさほうほう>" , 220, 180, Color.White)
        g.DrawTextS (" クリック:マスをひらく" , 220, 190, Color.White)
        g.DrawTextS (" みぎクリック:" , 220, 200, Color.White)
        g.DrawTextS (" はたをたてる" , 260, 210, Color.White)
        g.DrawTextS (" スペース:リトライ" , 220, 220, Color.White)
        g.DrawTextS (" ESC:おわる" , 220, 230, Color.White)

        base.Draw gametime

[<EntryPoint>]//プログラム開始位置
let main(args : string[]) =
    let game = new MyGame()
    game.Run()
    game.Dispose()
    0
