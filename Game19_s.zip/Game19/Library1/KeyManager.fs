﻿//キー情報管理モジュール
module km

open Microsoft.Xna.Framework;
open Microsoft.Xna.Framework.Audio;
open Microsoft.Xna.Framework.Content;
open Microsoft.Xna.Framework.Graphics;
open Microsoft.Xna.Framework.Input;

let mutable ks = new KeyboardState()
let mutable private bk_ks = ks
let mutable ms = new MouseState()
let mutable private bk_ms = ms

//キー情報設定
let setKey() =
    bk_ks <- ks
    ks <- Keyboard.GetState()
    bk_ms <- ms
    ms <- Mouse.GetState()
    
//キーボードの押した瞬間・離した瞬間・押されている
let kIsPush key = ks.IsKeyDown(key) && bk_ks.IsKeyUp(key)
let kIsRelease key = ks.IsKeyUp(key) && bk_ks.IsKeyDown(key)
let kIsDown key = ks.IsKeyDown(key)

//マウスの押した瞬間・離した瞬間・押されている
let mIsPush =
    function
    |0 -> (ms.LeftButton = ButtonState.Pressed) && (bk_ms.LeftButton = ButtonState.Released)
    |1 -> (ms.RightButton = ButtonState.Pressed) && (bk_ms.RightButton = ButtonState.Released)
    |2 -> (ms.MiddleButton = ButtonState.Pressed) && (bk_ms.MiddleButton = ButtonState.Released)
    |_ -> false

let mIsRelease =
    function
    |0 -> (ms.LeftButton = ButtonState.Released) && (bk_ms.LeftButton = ButtonState.Pressed)
    |1 -> (ms.RightButton = ButtonState.Released) && (bk_ms.RightButton = ButtonState.Pressed)
    |2 -> (ms.MiddleButton = ButtonState.Released) && (bk_ms.MiddleButton = ButtonState.Pressed)
    |_ -> false

let mIsDown =
    function
    |0 -> ms.LeftButton = ButtonState.Pressed
    |1 -> ms.RightButton = ButtonState.Pressed
    |2 -> ms.MiddleButton = ButtonState.Pressed
    |_ -> false
