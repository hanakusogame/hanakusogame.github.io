﻿//その他いろいろ置いておく（メモ的に使う）
module etc

open System.IO;
open System.Runtime.Serialization.Formatters.Binary;

//ファイル入出力処理(クラス等のシリアライズ)
//引用元→http://fsharpandenglishword.blog83.fc2.com/blog-entry-131.html
let saveValue filename x = 
    use stream = new FileStream(filename,FileMode.Create) 
    (new BinaryFormatter()).Serialize(stream,box x)
    
let loadValue filename =
    use stream = new FileStream(filename,FileMode.Open)
    (new BinaryFormatter()).Deserialize(stream) |> unbox

//-------------ここから完全にメモ---------------
(*

//ランダムな値
let rnd = new System.Random ()

//ファイルからテクスチャ作成
use stream2 = new FileStream("xxx.png",FileMode.Open)
texture = Texture2D.FromStream(this.GraphicsDevice,stream1)


//今回ちょっといらなそうなので退避
    //初期化
    //override  this.Initialize() =
        //base.Initialize()

    //コンテンツ破棄
    //override this.UnloadContent() =

//-----------ゲームクラス基本-------------------
type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定

    //メンバ変数的なもの
    let g = new G.Graphics(this,320,240)

    //コンテンツ登録
    override this.LoadContent() =
        g.LoadContent()

    //ゲームロジック
    override this.Update gametime =
        km.setKey()//キー取得
        base.Update gametime
        
    //描画処理
    override this.Draw gametime =
        g.Clear(Color.Black)//画面のクリア

        base.Draw gametime

[<EntryPoint>]//プログラム開始位置
let main(args : string[]) =
    let game = new MyGame()
    game.Run()
    game.Dispose()
    0// Learn more about F# at http://fsharp.net
//-------------ここまで-----------------------------------

*)