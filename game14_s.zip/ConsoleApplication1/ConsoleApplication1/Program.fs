﻿open Microsoft.Xna.Framework;
open Microsoft.Xna.Framework.Audio;
open Microsoft.Xna.Framework.Content;
open Microsoft.Xna.Framework.Graphics;
open Microsoft.Xna.Framework.Input;
open System.IO;
open System.Runtime.Serialization.Formatters.Binary;

//ゲームクラス
type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定
    let wx = 320
    let wy = 240
    let g = new Graphics.Graphics(this,wx,wy)
        
    let mutable m_num = 0
    let mutable x = 0
    let mutable y = 0
    let mutable score = 0
    let mutable hiScore = [ for i in 1 .. 10 -> 0 ]
    let mutable dieFlg = true
    let mutable startFlg = false
    let rnd = new System.Random () //ランダムな値
    let blockBase = [| for i in 0 .. 14 -> [| for i in 0 .. 9 -> 0 |] |]
    let mutable block = blockBase
    let mutable level = 1
    let playerCreate () = [|for i in 0 .. 1 -> [| for i in 0 .. 1 -> rnd.Next(2) |]|]
    let mutable player = playerCreate ()
    let players = [|for i in 0 .. 2 -> [|for i in 0 .. 1 -> [| for i in 0 .. 1 -> rnd.Next(2) |]|]|]

    //ファイル入出力処理(シリアライズ)
    //引用元→http://fsharpandenglishword.blog83.fc2.com/blog-entry-131.html
    let saveValue filename x = 
        use stream = new FileStream(filename,FileMode.Create) 
        (new BinaryFormatter()).Serialize(stream,box x)
    
    let loadValue filename x = 
        if File.Exists(filename) = false then saveValue filename x

        use stream = new FileStream(filename,FileMode.Open)
        (new BinaryFormatter()).Deserialize(stream) |> unbox
            

    //リトライ処理
    let init () = 
        score <- 0
        dieFlg <- false
        block <- [| for i in 0 .. 14 -> [| for i in 0 .. 9 -> 0 |] |]
        level <- 1
        m_num <- 0

    //コンテンツ登録
    override this.LoadContent () =
        this.Window.Title <- "パズルゲーム2"//ウィンドウタイトル
        g.LoadContent()
        hiScore <- loadValue "score.dat" hiScore

    //コンテンツ破棄
    override this.UnloadContent () =
        saveValue "score.dat" hiScore

    //ゲームロジック
    override this.Update gametime =
        //フレームカウンタ
        m_num <- m_num + 1

        km.setKey()//キー取得

        //マウス座標取得(右端がクリックしにくいのでちょっとずらしておく)
        x <- km.ms.X-20
        y <- km.ms.Y-20

        //レベルアップ処理
        if m_num % 1800 = 0 then level <- level + 1
        
        //クリックされたとき
        if km.mIsPush(0) then
            if x < 160 && x > -32 && y < 240 && y > 0 then
                if dieFlg then
                    if startFlg = false then startFlg <- true
                    init ()
                else
                    //フィールドブロック変更処理
                    for i in 0 .. 1 do
                        for j in 0 .. 1 do
                            let xx = (x/16)+j
                            let yy = (y/16)+i
                            if  yy >= 0 && yy < block.Length && xx >= 0 && xx < block.[yy].Length then
                                block.[yy].[xx] <- block.[yy].[xx] ^^^ player.[i].[j] 
                                player.[i].[j] <- rnd.Next(2)

                    //プレイヤーブロック変更処理
                    player <- players.[0]
                    players.[0] <- players.[1]
                    players.[1] <- players.[2]
                    players.[2] <- playerCreate ()
                    //何もないパターンのとき再作成
                    while (Array.sum players.[2].[0]) + (Array.sum players.[2].[1]) = 0 do
                         players.[2] <- playerCreate ()

                    //一列そろった場合ずらす処理
                    let mutable cnt = 0
                    for i in 0 .. 1 do
                        let yy = (y/16)+i
                        if yy < 15 && yy > 0 && Array.sum block.[yy] = 10 then
                            for j in 0 .. yy-1 do block.[yy-j] <-  block.[yy-j-1]
                            cnt <- cnt+1

                    //スコア追加(１列だと１点、２列同時消しは４点)
                    score <- score + (cnt*cnt)

        //ブロックの列をずらして押し上げる
        if m_num % (400 - (level * 15)) = 0 || km.mIsPush(1) then
            for i in 1 .. 14 do
                block.[i-1] <- block.[i]
            block.[14] <- [| for i in 0 .. 9 -> rnd.Next(2) |]//一番下の列作成
            
        //一番上にブロックがある場合死亡
        if dieFlg = false then
            if Array.sum block.[0] > 0 then 
                dieFlg <- true
                //ハイスコアの設定
                hiScore <- List.rev ( List.sort (score :: hiScore) )
            

        base.Update gametime
        
    //描画処理
    override this.Draw gametime =
        g.Clear(Color.White)
        g.SetColor(Color(50,50,50))
        g.FillRect(0,0,160,240)
        
        //ブロック描画
        for i in 0 .. block.Length-1 do
            for j in 0 .. block.[i].Length-1 do
                if block.[i].[j] = 0 then
                    g.SetColor(Color.Black)
                else
                    if dieFlg then
                        g.SetColor(Color(70,70,70))
                    else
                        //ピンチの時はピンクにする
                        if Array.sum block.[1] > 0 || Array.sum block.[2] > 0 then
                            g.SetColor(Color.Magenta)
                        else
                            g.SetColor(Color(0,255,0))
                g.FillRect(j*16, i*16, 15, 15)
        
        if x < 160 then
            //変更ブロック描画
            for i in 0 .. 1 do
                for j in 0 .. 1 do
                    if player.[j].[i] = 1 then
                        g.FillRect((x/16+i)*16, (y/16+j)*16, 15, 15, Color.Red)
                
            //変更範囲描画
            g.DrawRect(x/16*16-2, y/16*16-2, 34, 34, Color.Red)

        //死亡判定境界線描画
        g.DrawLine(0, 16, 160, 16, Color.Red)
        
        //スコア表示
        g.SetColor(Color.Black)
        g.DrawTextM("レベル:" + level.ToString() , 10, 0)
        g.DrawTextM("スコア:" + score.ToString(), 10, 1)

        //時間表示
        //g.DrawTextS(gametime.TotalGameTime.ToString() , 32, 0)
        //g.DrawTextS(m_num.ToString() , 35, 1)


        //次のブロック表示
        for k in 0 .. 2 do
            g.DrawRect( 176 - 2 , 64 - 2 + k * 48 , 34, 34, Color.DarkGray)
            for i in 0 .. 1 do
                for j in 0 .. 1 do
                    if players.[k].[j].[i] = 1 then
                        g.FillRect( 176 + (k/16+i)*16, 64 + k * 48 + (j*16), 15, 15,Color.Blue)
        
        g.SetColor(Color.Black)
        g.DrawTextM("つぎ", 10, 3)
        g.DrawTextM("のつぎ", 10, 6)
        g.DrawTextM("のつぎ", 10, 9)      

        //ランキング表示
        g.DrawTextM("ランキング", 15, 3)
        for i in 0 .. 7 do
            if hiScore.[i] = score && score <> 0 then
                g.SetColor(Color.Red)
            else if i <> 0 && hiScore.[i] < score && hiScore.[i-1] > score then
                g.SetColor(Color.Blue)
            else
                g.SetColor(Color.Black)

            g.DrawTextM((i+1).ToString() + ":" + hiScore.[i].ToString(), 15, i+4)

        //操作説明
        g.SetColor(Color.Black)
        g.DrawTextS("<あそびかた>", 21, 25)
        g.DrawTextS("ブロックをヨコに1れつならべろ!", 22, 26)

        //操作説明
        g.SetColor(Color.Black)
        g.DrawTextS("<そうさせつめい>", 21, 27)
        g.DrawTextS("クリック:ブロックをおく", 22, 28)
        g.DrawTextS("みぎクリック:ブロックをせりあげる", 22, 29)

        if dieFlg then
            if startFlg = false then
                //スタート画面表示
                g.DrawTextM("パズルゲーム2", 1, 7, Color.Red)
                g.DrawTextS("クリックでスタートできます。", 3, 17, Color.Red)
                g.SetColor(Color.Black)
            else  
                //ゲームオーバー表示
                g.DrawTextM("GAMEOVER", 1, 7, Color.Red)
                g.DrawTextS("クリックでリトライできます。", 3, 17, Color.Red)
                g.SetColor(Color.Black)
        else


        base.Draw gametime

[<EntryPoint>]//開始
let main(args : string[]) =
    let game = new MyGame()
    game.Run()
    game.Dispose()
    0