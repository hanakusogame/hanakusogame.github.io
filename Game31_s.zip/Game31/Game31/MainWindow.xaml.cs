﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace Game31
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        private Stopwatch sw = new Stopwatch();
        private List<TimeSpan> recList = new List<TimeSpan>();
        private int rank = 0;

        private TimeSpan ts = new TimeSpan(0, 3, 0);
        private Stopwatch tsw = new Stopwatch();

        public MainWindow()
        {
            InitializeComponent();
            CompositionTarget.Rendering += Update;
            myStopwatchLabel.Content = sw.Elapsed.ToString("G").Substring(2, 13);
            recButton.Visibility = Visibility.Hidden;
            tReset();
        }
 
        protected void Update(object sender, EventArgs e)
        {
            //ストップウォッチ系
            if (sw.IsRunning)
            {
                myStopwatchLabel.Content = sw.Elapsed.ToString("G").Substring(2, 13);
            }

            //タイマー系
            if (tsw.IsRunning)
            {
                TimeSpan bk_ts = ts.Add(-tsw.Elapsed);
                if (bk_ts.TotalMilliseconds > 0)
                {
                    textBoxTimer.Text = bk_ts.ToString("G").Substring(2, 13);
                }
                else
                {
                    tReset();
                    Console.Beep();
                }
            }

            dateLabel.Content = DateTime.Now.ToString("G");
        }

        private void startButton_Click(object sender, RoutedEventArgs e)
        {
            if (!sw.IsRunning) {
                sw.Start();
                startButton.Content = "ストップ";
                recButton.Visibility = Visibility.Visible;
            }
            else
            {
                sw.Stop();
                myStopwatchLabel.Content = sw.Elapsed.ToString("G").Substring(2, 13);
                recTextBox.Text += "stop | " + myStopwatchLabel.Content + "\n";
                startButton.Content = "スタート";
                recButton.Visibility = Visibility.Hidden;
            }
        }

        private void recButton_Click(object sender, RoutedEventArgs e)
        {
            rank++;
            recTextBox.Text += "" + rank + " | " + sw.Elapsed.ToString("G").Substring(2, 13) + "\n";
        }

        private void resetButton_Click(object sender, RoutedEventArgs e)
        {
            sw.Reset();
            startButton.Content = "スタート";
            myStopwatchLabel.Content = sw.Elapsed.ToString("G").Substring(2, 13);
            recButton.Visibility = Visibility.Hidden;
            rank = 0;
        }

        //履歴のクリア
        private void buttonClear_Click(object sender, RoutedEventArgs e)
        {
            recTextBox.Text = "";
        }

        private void tStartButton_Click(object sender, RoutedEventArgs e)
        {
            if (!tsw.IsRunning)
            {
                if (!textBoxTimer.IsReadOnly)
                {
                    if(TimeSpan.TryParse(textBoxTimer.Text, out ts))
                    {
                        textBoxTimer.IsReadOnly = true;
                    }
                }

                if (textBoxTimer.IsReadOnly)
                {
                    tsw.Start();
                    tStartButton.Content = "ストップ";
                    errorLabel.Content = "";
                }
                else { errorLabel.Content = "不正な値です。"; }
            }
            else
            {
                tsw.Stop();
                tStartButton.Content = "スタート";
            }
        }

        private void tResetButton_Click(object sender, RoutedEventArgs e)
        {
            tReset();
        }

        private void tReset()
        {
            tsw.Reset();
            textBoxTimer.IsReadOnly = false;
            tStartButton.Content = "スタート";
            textBoxTimer.Text = ts.ToString("G").Substring(2, 13);
            errorLabel.Content = "";
        }
    }
}
