﻿//ゲームループ
module MyLoop

open System
open System.Windows.Forms
open System.Drawing
open MyGraphics
open MyInput

type MyLoop () =

    let gettime() = (float)System.Environment.TickCount
    let mutable fpsCnt = 0
    let mutable now = gettime()
    let mutable nextsecond = gettime()
    let mutable nextframe = gettime()
    let fps = 30.0
    let wait = 1000. / fps
    let mutable exitFlg = true

    let mutable realfps = 0

    let mutable init = fun () -> ()
    let mutable update = ( fun () -> () )

    member u.getFps() = realfps

    member u.Init with set p = init <- p
    member u.Update with set p = update <- p
    member u.exit() = exitFlg <- false

    //ｹﾞｰﾑループ
    member u.run() =
        init()
        while exitFlg do
            now <- gettime()
            if now > nextframe then
                nextframe <- nextframe + wait
                if now < nextframe then
                    fpsCnt <- fpsCnt + 1
                    update()
            if now > nextsecond then
                nextsecond <- nextsecond + 1000.0
                realfps <- fpsCnt
                fpsCnt <- 0
            Threading.Thread.Sleep(10)
            Application.DoEvents()


