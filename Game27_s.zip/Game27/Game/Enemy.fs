﻿module Enemy

open System
open System.Windows.Forms
open System.Drawing
open MyGraphics ; open MyLoop ; open MyInput

open Astar
open a2dAstar

//敵クラス
type Enemy(sPos:(int*int),gPos:(int*int),hp) =
    let mutable px,py = 0,0 //現在地
    let r = 50 //半径
    let mutable sx,sy = sPos //スタート地
    let mutable gx,gy = 0 , 0 //目的地(次に向かうべきマス)
    let mutable v = 0 , 0 //移動スピードベクトル
    let speed = 4 //移動スピード
    let mutable root = Some([])
    let mutable state = 0
    let mutable hp = hp
    let mutable dieCnt = 0

    let setSpeed (x1 ,y1) (x2 ,y2) =
        let vx , vy = (x2 - x1) , (y2 - y1)
        let len = int(sqrt( float( vx*vx + vy*vy ) ))
        if len <> 0 then
            ( vx * speed / len ) , ( vy * speed / len )
        else
            0 , 0
    
    member u.getPos() = px,py,r

    //被弾処理
    member u.HitShot(id,power) =
        if hp > 0 then
            hp <- hp - power
            if hp <= 0 then
                state <- 3
    
    //死亡チェック
    member u.dieChk() = state

    //ブロックが置かれたときの処理
    member u.blockChk(i,x,y,arr) =
        //i = 0 ブロック追加　i = 1 ブロック削除
        //ルート内にブロックを置いた場合
        match root with
            |None -> true
            |Some(b) ->
                if i = 1 || List.exists(fun ( xx ,yy ) -> x = xx && y = yy )b then
                    //ルートを作り直す
                    let bk_root = runAstar arr gPos b.Head
                    match bk_root with
                    |None -> false
                    |Some(a) ->
                        root <- bk_root
                        let x,y = a.Head
                        let x,y,_ = arr.[x,y]
                        sx <- px ; sy <- py
                        gx <- x ; gy <- y
                        v <- setSpeed (sx,sy) (gx,gy)
                        true
                else
                    true
    
    //初期処理
    member u.init(arr) =
        root <- runAstar arr gPos sPos
        let x,y = root.Value.Head
        let x,y,_ = arr.[x,y]
        px <- x
        py <- y

    //更新処理
    member u.update(arr:(int*int*int)[,]) =       
        if state = 0 then
            match root with
            |None -> ()
            |Some(a) ->
                if a.Length > 1 then
                    match a.Tail.Head with
                    |(x,y) ->
                        let x2,y2,_ = arr.[x,y]
                        sx <- px ; sy <- py
                        gx <- x2 ; gy <- y2
                        v <- setSpeed (sx,sy) (gx,gy)
                        root <- Some(a.Tail)
                        state <- 1
                else
                    state <- 2

        if state = 0 || state = 1 then
            let vx,vy = v
            if ( ( vx <= 0 && px <= gx ) || ( vx >= 0 && px >= gx ) ) &&
                ( ( vy <= 0 && py <= gy ) || ( vy >= 0 && py >= gy ) ) then
                state <- 0
            else
            px <- px + vx
            py <- py + vy
        
    //描画処理
    member u.draw(g:MyGraphics) =
        let size = 20
        
        match root with
        |None -> ()
        |Some(a) ->
            //ルート描画
            g.setColor( Color.LightBlue )
            List.iter(fun (x,y) ->g.fBox ( x * size ) ( y * size ) 19 )a

            //現在地描画
            let resize(i) = ( i * size / 100 )
            g.setColor( Color.Lime )
            g.fCircle (resize(px-r)) (resize(py-r)) (resize(r*2)) (resize(r*2))
            g.setColor( Color.Black )
            g.dStrS (resize(px-r)) (resize(py-r)) (hp.ToString())
           