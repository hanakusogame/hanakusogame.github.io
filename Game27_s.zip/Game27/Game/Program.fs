﻿open System
open System.Windows.Forms
open System.Drawing
open MyGraphics
open MyLoop
open MyInput
open Enemy
open Tower

open a2dAstar

let mutable w,h = 320,240
let mutable scale = 1
let mutable debugFlg = false

let form = new Form( ClientSize = new Size(w, h) , MaximizeBox = false, FormBorderStyle = FormBorderStyle.FixedSingle)
let g = new MyGraphics(form)
let key = new MyInput(form)
let loop = new MyLoop()
let mutable frameCnt = 0

let mx,my = 10,10
let size = 20
let mutable arr = Array2D.init mx my ( fun x y -> x*100+50 , y*100+50 , 1 )
let mutable level = 0
let mutable money = 300
let mutable life = 5
let mutable startFlg = false
let mutable cnt = -1

let sPos = (0,0)
let gPos = (9,9)

let mutable eList = []
let mutable tList = []

let init() =
    form.Show()
    List.iter(fun (e:Enemy) -> e.init(arr) )eList

//更新処理
let update() =
    if life = 0 then
        if key.kPush(Keys.Space) then
            arr <- Array2D.init mx my ( fun x y -> x*100+50 , y*100+50 , 1 )
            startFlg <- false
            cnt <- -1
            level <-0
            money <- 300
            life <- 5
            eList <- []
            tList <- []
    else
        if cnt % 50 = 0 then
            let e = new Enemy(sPos,gPos,(level*100))
            e.init(arr)
            eList <- e :: eList

        if not(startFlg) && key.kPush(Keys.Space) then startFlg <- true
        if startFlg then cnt <- cnt + 1
        if cnt % 1000 = 0 then level <- level + 1

        let tChk(xx,yy) =
            List.tryFind(
                fun (t:Tower) ->
                    let x,y = t.getPos()
                    if x = xx && y = yy then true
                    else false
            )tList

        if key.mPush(0) then
            let x ,y  = key.mPos(scale)
            let xx,yy = x/size , y/size
            if xx >= 0 && xx < mx  && yy >= 0 && yy < my then
                match arr.[xx,yy] with
                |(x,y,1)->
                    if money >= 5 then
                        arr.[xx,yy] <- x,y,0
                        if (runAstar arr gPos sPos) = None ||
                            List.exists(fun (e:Enemy) -> not(e.blockChk(0,xx,yy,arr)))eList then
                            arr.[xx,yy] <- x,y,1
                        else
                            money <- money - 5

                |(x,y,0)->
                    if money >= 50 && tChk(xx,yy) = None then
                        money <- money - 50
                        tList <- new Tower(xx,yy,arr) :: tList
                |_ ->()

        if key.mPush(1) then
            let x ,y  = key.mPos(scale)
            let xx,yy = x/size , y/size
            if xx >= 0 && xx < mx  && yy >= 0 && yy < my then
                match arr.[xx,yy] with
                |(x,y,0)->

                    match tChk(xx,yy) with
                    |Some(a) ->
                        tList <- List.filter(fun b -> a <> b)tList
                    |None ->
                        arr.[xx,yy] <- x,y,1
                        List.iter(fun (e:Enemy) -> e.blockChk(1,xx,yy,arr)|> ignore  )eList 
                |_ ->()

        List.iter(fun (e:Enemy) -> e.update(arr) )eList
        List.iter(fun (t:Tower) -> t.update(eList) )tList

        eList <- List.filter(
            fun (e:Enemy) ->
                match e.dieChk() with
                | 2 -> life <- life - 1 ; false
                | 3 -> money <- money + 20 ; false
                | _ -> true
        )eList

    //描画処理         
    //マップ描画
    Array2D.iteri(
        fun x y (_,_,i) ->
            g.setColor(if i = 0 then Color.Gray else Color.White)
            g.fBox (x*20) (y*20) 19
    )arr

    //情報描画
    g.setColor(Color.White)
    g.dStr 220 0 ("GOLD：" + money.ToString() + "円")
    g.dStr 220 20 ("LIFE:" + life.ToString())
    g.dStr 220 40 ("LEVEL:" + level.ToString())
    if life = 0 then
        g.dStr 220 60 "GAMEOVER"
    
    g.dStrS 5 200 ("クリックでブロックや砲台配置")
    g.dStrS 5 210 ("ブロック:5円　砲台:50円")
    g.dStrS 5 220 ("Spaceキーでスタート")

    g.dStr 200 225 "ﾀﾜｰﾃﾞｨﾌｪﾝｽβ版"

    List.iter(fun (e:Enemy) -> e.draw(g) )eList
    List.iter(fun (t:Tower) -> t.draw( g ) )tList

let updateBase() =
    key.setMouse()
    key.setKey()

    if form.Created then
        //終了
        if key.kPush(Keys.Escape) then loop.exit()

        //サイズ変更
        match key.getKey(0) with
        |Keys.D1 ->
            scale <- 1
            g.reSize(w,h)

        |Keys.D2 ->
            scale <- 2
            g.reSize( w*scale , h*scale )

        //デバッグ情報表示
        |Keys.D3 ->
            debugFlg <- not(debugFlg)
        |_->()

        g.clear(Color.Black)

        update()

        if debugFlg then
            g.setColor(Color.Lime)
            let x,y = key.mPos(scale)
            g.dStrS 0  0 ( "FPS:" + loop.getFps().ToString() )
            g.dStrS 0 10 ( "W:" + w.ToString() + " H:" + h.ToString() + " S:" + scale.ToString())
            g.dStrS 0 20 ( "X:" + x.ToString() + " Y:" + y.ToString() )
            g.dStrS 0 30 ( "KEY:" + key.getKey(1).ToString() )

        g.render()

        //タイトルバー表示
        form.Text <- ("Game27")
    else
        loop.exit()

    frameCnt <- frameCnt + 1

loop.Update <- updateBase
loop.Init <- init
loop.run()
