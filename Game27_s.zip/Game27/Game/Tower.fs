﻿module Tower

open System
open System.Windows.Forms
open System.Drawing
open MyGraphics ; open MyLoop ; open MyInput
open Enemy
open Shot

//タワークラス
type Tower( x , y , arr:(int*int*int)[,] ) =
    
    let hitChk(x1,y1,r1,x2,y2,r2) =
       (pown (x1-x2) 2) + (pown (y1-y2) 2) <= (pown ( r1 + r2 ) 2) 
    
    let mutable sList = []
    let mutable cnt = 0
    let x2,y2,_ = arr.[x,y]
    let len = 200
    let mutable cList = []
    let r = 50

    member u.getPos() = x,y

    //更新処理
    member u.update( eList:Enemy list ) =
        //攻撃範囲内にいる敵のリスト
        cList <-
            eList |>
            List.rev |>
            List.filter(
                fun (e:Enemy) ->
                    let ex,ey,er = e.getPos()
                    hitChk(ex, ey, er, x2, y2, len)
            )

        //ショット発射
        if cnt % 10 = 0 then
            if cList.Length > 0 then
                sList <- new Shot(x2,y2,len,cList.Head) :: sList

        sList <- List.filter(fun (s:Shot) -> s.update() )sList
        cnt <- cnt + 1

    //描画処理
    member u.draw(g:MyGraphics) =
        let size = 20
        let resize(i) = i * size / 100

        //攻撃範囲描画
        g.setColor( Color.Magenta )
        let len = resize(len)
        let x3,y3 = resize(x2) , resize(y2) 
        g.dCircle ( x3-len ) ( y3-len ) (( len-1 ) * 2 ) (( len-1 ) * 2 )

        //本体描画
        g.setColor( Color.Cyan )
        g.fCircle (x3-10) (y3-10) 19 19

        //ターゲット描画
        g.setColor( Color.Red )
        List.iter(
            fun (c:Enemy) ->
                let x,y,r = c.getPos()
                g.dBox (resize(x-r)) (resize(y-r)) (resize(r*2))
        )cList

        //ショット描画
        List.iter(fun (s:Shot) -> s.draw(g) )sList
