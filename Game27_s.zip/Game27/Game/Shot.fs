﻿module Shot
open System.Drawing
open MyGraphics
open Enemy

//弾クラス
type Shot( x , y , len , e:Enemy ) =
    
    //２点間の距離取得
    let getLength (x1 ,y1) (x2 ,y2) =
        let vx , vy = (x2 - x1) , (y2 - y1)
        int(sqrt( float( vx*vx + vy*vy ) ))
    
    //位置と速度から１フレーム間での移動距離取得
    let getSpeed (x1 ,y1) (x2 ,y2) s =
        let vx , vy = (x2 - x1) , (y2 - y1)
        let len = int(sqrt( float( vx*vx + vy*vy ) ))
        if len <> 0 then ( vx * s / len ) , ( vy * s / len )
        else 0 , 0

    //円と円の衝突判定
    let hitChk(x1,y1,r1,x2,y2,r2) =
       (pown (x1-x2) 2) + (pown (y1-y2) 2) <= (pown ( r1 + r2 ) 2) 

    let id = 1
    let power = 3
    let ex,ey,er = e.getPos()
    let sx,sy = getSpeed ( x , y ) ( ex,ey ) 30
    let mutable px,py = x,y
    let r = 20

    member u.init() = ()

    member u.update() =
        let plen = getLength (x, y) (px,py)
        if plen < len then
            if hitChk(px,py,r,ex,ey,er) then
                e.HitShot(id,power)
                false
            else
                px <- px + sx
                py <- py + sy
                true
        else
            false

    member u.draw(g:MyGraphics) =
        let size = 20
        let resize(i) = ( i * size / 100 )
        g.setColor(Color.Red)
        g.fCircle (resize(px-r)) (resize(py-r)) (resize(r*2)) (resize(r*2))