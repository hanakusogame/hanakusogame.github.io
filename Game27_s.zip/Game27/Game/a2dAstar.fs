﻿//2Dの格子上マップでの最短経路検索用に作ったテスト
module a2dAstar
    open Astar

    //Point -> Point -> int　コストや障害物を加味しない最短距離を返す
    let inline private heuristic (x, y) (u, v) = max (abs (x - u))  (abs (y - v))

    //探索する位置のシークエンスを作成する関数(通行不可な場所はこれで除外)
    let inline private successor (arr : (int*int*int)[,]) (x,y)  =
        let w,h = (arr.GetLength(0)),(arr.GetLength(1))
        let chkList =  [(x,y-1);(x+1,y);(x,y+1);(x-1,y)]
        //斜めも必要なとき足す;(x-1,y-1);(x+1,y-1);(x-1,y+1);(x+1,y+1)
        set[for u,v in chkList do
            if u >= 0 && u < w && v >= 0 && v < h then
                let _,_,a = arr.[u,v]
                if a <> 0 then//0は通行不可能とする
                    yield set [u, v]
           ]
        |> Set.unionMany


    //ソースから最短経路を取得して経路リストを返す
    let inline runAstar (arr:(int*int*int)[,]) (sx,sy) (gx,gy)=
          let start = (sx,sy) //スタート位置
          let finish = (gx,gy) //ゴール位置
          let succ = successor arr//探索する位置を指定する関数(除外する文字の場所はこれで除外)
          let h     = heuristic finish //ゴールまでのコスト無視の最短距離を求める関数   
          let cost(x, y) =
            let _,_,a = arr.[x,y]//指定位置のコストを返す関数
            a
          
          try
            Some(AstarImpl.astar start succ ((=) finish) cost h)
          with
            | Failure(msg) -> None
