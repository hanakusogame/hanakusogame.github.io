﻿//ゲームのメインの処理
module Main

open System
open System.Drawing
open System.Windows.Forms
open MyGraphics; open MyInput

let test mx my =
    let rnd = new Random()
    let a = Array2D.create mx my 0
    let tx = [| -1;+1; 0; 0 |]
    let ty = [|  0; 0;-1;+1 |]

    Array2D.iteri(
        fun x y i ->
            if x = 0 || x = mx-1 || y = 0 || y = my-1 then
                a.[x  ,y] <- 1
            else
                if x%2 = 0 && y%2 = 0 then
                    let mutable flg = false
                    a.[x  ,y] <- 1
                    while flg = false do
                        let r = rnd.Next(4)
                        if a.[x + tx.[r]  ,y + ty.[r]] = 0 then
                            a.[x + tx.[r]  ,y + ty.[r]] <- 1 ; flg <- true
    ) a
    a

let mx,my = 15,15
let mutable visible = false
let s = 32//size
let mutable muki = 0
let mutable px,py = 1,1
let mutable arr = test mx my
let mutable tx:int[][] = null
let mutable ty:int[][] = null
let mutable initFlg = false

let init() =
    visible <- false
    muki <- 0
    px <- 1 ; py <- 1
    arr <- test mx my
    initFlg <- true

let update() =

    if kPush(Keys.Z) then init()
    if kPush(Keys.Left) then
        if muki = 0 then muki <- 3 else muki <- muki-1

    if kPush(Keys.Right) then
        if muki = 3 then muki <- 0 else muki <- muki+1

    if kPush(Keys.Up) then
        match muki with
        |0 -> if arr.[px  ,py-1] = 0 then py <- py-1
        |1 -> if arr.[px+1,py  ] = 0 then px <- px+1
        |2 -> if arr.[px  ,py+1] = 0 then py <- py+1
        |3 -> if arr.[px-1,py  ] = 0 then px <- px-1
        |_ -> ()

    let chk =
        match muki with
        |0 ->
            tx <- [| [|px-1; px  ; px+1|] ; [|px-1; px  ; px+1|] ; [|px-1; px  ; px+1|] |]
            ty <- [| [|py-2; py-2; py-2|] ; [|py-1; py-1; py-1|] ; [|py  ; py  ; py  |] |]
            py-2 >= 0
        |1 ->
            tx <- [| [|px+2; px+2; px+2|] ; [|px+1; px+1; px+1|] ; [|px  ; px  ; px  |] |]
            ty <- [| [|py-1; py  ; py+1|] ; [|py-1; py  ; py+1|] ; [|py-1; py  ; py+1|] |]
            px+2 < mx
        |2 ->
            tx <- [| [|px+1; px  ; px-1|] ; [|px+1; px  ; px-1|] ; [|px+1; px  ; px-1|] |]
            ty <- [| [|py+2; py+2; py+2|] ; [|py+1; py+1; py+1|] ; [|py  ; py  ; py  |] |]
            py+2 < my
        |3 ->
            tx <- [| [|px-2; px-2; px-2|] ; [|px-1; px-1; px-1|] ; [|px  ; px  ; px  |] |]
            ty <- [| [|py+1; py  ; py-1|] ; [|py+1; py  ; py-1|] ; [|py+1; py  ; py-1|] |]
            px-2 >= 0
        |_->false

    if px = 13 && py = 13 then visible <- true
    
    //表示クリア
    g.Clear(Color.Black)

    //マップ表示
    if visible then
        setColor(Color.White)
        Array2D.iteri( fun x y i -> if i = 1 then fBox (200+x*8) (20+y*8) 7 ) arr

        //プレイヤー位置表示
        setColor(Color.Red) ; fBox (200+px*8) (20+py*8) 7

        //スタート位置
        setColor(Color.Lime) ; fBox (200+1*8) (20+1*8) 7

        //ゴール位置
        setColor(Color.Yellow) ; fBox (200+13*8) (20+13*8) 7

    let mapChk u v =
        let c = color
        if tx.[u].[v] >= 13 && ty.[u].[v] >= 13 then
            setColor(Color.Yellow)
        elif tx.[u].[v] <= 1 && ty.[u].[v] <= 1 then
            setColor(Color.Lime)
        else 
            setColor(c)
        arr.[ tx.[u].[v], ty.[u].[v] ] = 1

    //３Ｄマップ表示
    setRgb 100 100 100
    if chk then
        if mapChk 0 0 then fBox (0*s) (2*s) (2*s)
        if mapChk 0 1 then fBox (2*s) (2*s) (2*s)
        if mapChk 0 2 then fBox (4*s) (2*s) (2*s)

    setRgb 150 150 150 
    if mapChk 1 0 then fPoly [ (1*s, 1*s); (2*s, 2*s); (2*s, 4*s); (1*s, 5*s) ]
    if mapChk 1 2 then fPoly [ (4*s, 2*s); (5*s, 1*s); (5*s, 5*s); (4*s, 4*s) ]

    setRgb 200 200 200
    if mapChk 1 0 then fRect (0*s) (1*s) (1*s) (4*s)
    if mapChk 1 1 then fBox  (1*s) (1*s) (4*s)
    if mapChk 1 2 then fRect (5*s) (1*s) (1*s) (4*s)

    setColor(Color.White)
    if mapChk 2 0 then
        fPoly [ (0*s,0*s); (1*s,1*s); (1*s,5*s); (0*s,6*s) ]
    if mapChk 2 2 then
        fPoly [ (5*s,1*s); (6*s,0*s); (6*s,6*s); (5*s,5*s) ]

    setColor(Color.White)
    dBox 0 0 (s*6)

    setColor(Color.Cyan); dStr 200 0 "<疑似3D迷路>"
    setColor(Color.Magenta); dStr 0 200 ("X=" + px.ToString() + " Y=" + py.ToString())
    setColor(Color.Yellow)
    let mukiStr = 
        match muki with
        |0 -> "北"
        |1 -> "東"
        |2 -> "南"
        |_ -> "西"
    dStr 100 200 ("向き=" + mukiStr)
    setColor(Color.Lime)
    dStr 200 140 "遊び方"
    dStr 200 160 "左右:方向転換"
    dStr 200 180 "上　:前方移動"
    dStr 200 200 "Ｚ　:リセット"
