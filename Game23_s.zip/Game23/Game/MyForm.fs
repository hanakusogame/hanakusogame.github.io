﻿//フォームを作っているだけ
module MyForm

open System.Windows.Forms
open System.Drawing

let form = new Form()
form.ClientSize <- new Size(320, 240)
