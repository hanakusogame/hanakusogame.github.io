﻿open Microsoft.Xna.Framework;
open Microsoft.Xna.Framework.Input;



type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定

    //メンバ変数的なもの
    let g = new G.MyGraphics(this,320,240)

    let rnd = new System.Random ()//ランダム

    let array = Array2D.init 4 4 (fun y x -> y*4+x)
    let array2 = Array2D.copy array
    let mutable initFlg = false
    let mutable moveFlg = false
    let mutable moveCnt = 0
    let mutable startTime : System.TimeSpan = System.TimeSpan.Zero
    let mutable time : System.TimeSpan = System.TimeSpan.Zero

    //上移動
    let moveUp y x i =
        if i = 15 && y+1 < 4 then
            array.[y,x] <- array.[y+1,x]
            array.[y+1,x] <- 15
            moveFlg <- true

    //下移動
    let moveDown y x i =
        if i = 15 && y-1 >= 0 then
            array.[y,x] <- array.[y-1,x]
            array.[y-1,x] <- 15
            moveFlg <- true
    
    //左移動
    let moveLeft y x i =
        if i = 15 && x+1 < 4 then
            array.[y,x] <- array.[y,x+1]
            array.[y,x+1] <- 15
            moveFlg <- true

    //右移動
    let moveRight y x i =
        if i = 15 && x-1 >= 0 then
            array.[y,x] <- array.[y,x-1]
            array.[y,x-1] <- 15
            moveFlg <- true

    //コンテンツ登録
    override this.LoadContent() =
        g.LoadContent()

    //ゲームロジック
    override this.Update gametime =
        km.setKey()//キー取得

        if km.kIsPush(Keys.Escape) then this.Exit()//終了処理

        if initFlg then

            moveFlg <- false

            //リセット
            if km.kIsPush(Keys.Space) then
               initFlg <- false 
            
            //パネルを動かす処理
            if km.kIsPush(Keys.Up) then
                Array2D.iteri moveUp (Array2D.copy array)

            if km.kIsPush(Keys.Down) then     
                Array2D.iteri moveDown (Array2D.copy array)

            if km.kIsPush(Keys.Left) then     
                Array2D.iteri moveLeft (Array2D.copy array)

            if km.kIsPush(Keys.Right) then     
                Array2D.iteri moveRight (Array2D.copy array)
                
            if moveFlg then
                moveCnt <- moveCnt+1
                //クリアしたかどうか
                let test = ref 0;
                Array2D.iteri (fun y x i -> if y*4+x = i then test := !test + 1) array
                if !test = 16 then initFlg <- false

            time <- gametime.TotalGameTime - startTime
        else
            //リセット処理
            if km.kIsPush(Keys.Space) then 
                for i = 0 to 500 do
                    match rnd.Next(4) with
                    |0 -> Array2D.iteri moveUp (Array2D.copy array)
                    |1 -> Array2D.iteri moveDown (Array2D.copy array)
                    |2 -> Array2D.iteri moveLeft (Array2D.copy array)
                    |3 -> Array2D.iteri moveRight (Array2D.copy array)
                    |_ -> ()
                
                startTime <- gametime.TotalGameTime
                moveCnt <- 0
                initFlg <- true
        
        base.Update gametime
        
    //描画処理
    override this.Draw gametime =
        g.Clear(Color.Black)//画面のクリア

        //パネルを描く
        if initFlg then g.SetColor(Color.White) else g.SetColor(Color.Yellow)
        Array2D.iteri (
            fun y x i ->
                if i <> 15 then
                    g.FillRect(x*32, y*32, 31, 31)
                    g.DrawTextM((i+1).ToString(), x*32, y*32 ,Color.Black)
            ) array
        
        //答えパネル描画
        g.SetColor(Color.White)
        Array2D.iteri (
            fun y x i ->
                if i <> 15 then
                    g.FillRect(x*16+164, y*16+64, 15, 15)
                    g.DrawTextS((i+1).ToString(), x*16+164, y*16+64 ,Color.Black)
            ) array2

        //情報描画
        g.SetColor (Color.White)
        g.DrawTextM ("<15パズル>", 200, 0)
        g.DrawTextM ("<こたえ>", 156, 40)
        g.DrawTextM ("いどうかいすう:" + moveCnt.ToString(), 0, 128)
        g.DrawTextM ("じかん:" + time.Minutes.ToString() + "ふん" + time.Seconds.ToString() + "びょう", 0, 164)
        g.DrawTextM ("スペースキーでさいスタート", 0, 196)
        base.Draw gametime

[<EntryPoint>]//プログラム開始位置
let main(args : string[]) =
    let game = new MyGame()
    game.Run() ; game.Dispose()
    0

