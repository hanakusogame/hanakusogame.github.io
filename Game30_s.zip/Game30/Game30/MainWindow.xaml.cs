﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Game30
{
    public partial class MainWindow : Window
    {
        private class data
        {
            public decimal d = 0;
            public int opt = -1;
            public data(decimal i) { d = i; }
            public data() { }
        }

        private string str = "0";
        private List<data> list = new List<data>();
        private decimal ans = 0;
        private decimal mem = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private string optToStr(int i)
        {
            if (i == 0) return "+";
            else if (i == 1) return "-";
            else if (i == 2) return "*";
            else if (i == 3) return "/";
            else if (i == 4) return "%";
            else return "";
        }

        private string makeStr()
        {
            string s = "";
            for (int i = 0; i < list.Count; i++)
            {
                s += list[i].d + optToStr(list[i].opt);
            }
            return s;
        }

        //計算
        private decimal keisan(decimal a,decimal d,int opt)
        {
            decimal ans = a;
            if (opt == 0) ans += d;
            if (opt == 1) ans -= d;
            if (opt == 2) ans *= d;
            if (opt == 3) if(d != 0)ans /= d;
            if (opt == 4) ans %= d;
            return ans;
        }

        //答えを出す
        private void answ()
        {
            if (list.Count >= 1)
            {
                list[list.Count - 1].opt = -1;
                ans = list[0].d;
                for (int i = 0; i < list.Count - 1; i++)
                {
                    ans = keisan(ans,list[i + 1].d,list[i].opt);
                }
                label.Content = ans;
                label2.Content = makeStr() + "=" + ans;
                str = ""+ans;
                list.Clear();
                list.Add(new data(ans));
            }
        }

        //演算子設定
        private void addOpt(int i)
        {
            if (list[list.Count - 1].opt == -1)
            {
                list[list.Count - 1].d = decimal.Parse(str);
                str = "0";
            }
            list[list.Count - 1].opt = i;
            label2.Content = makeStr();
        }

        //数字入力
        private void addVal(string i)
        {
            if (ans != 0)
            {
                str = "0";
                ans = 0;
            }

            if (list.Count == 0 || list[list.Count - 1].opt != -1)
            {
                list.Add(new data());
                
            }

            string bk_s = str + i;
            decimal bk_d = 0;
            if (decimal.TryParse(bk_s, out bk_d))
            {
                str = bk_s;
                list[list.Count - 1].d = bk_d;
            }
            label2.Content = makeStr();
            label.Content = decimal.Parse(str);
        }

        //平方根
        private void root()
        {
            decimal bk = decimal.Parse(label.Content.ToString());
            str = Math.Sqrt((double)bk).ToString();
            label.Content = str;
        }

        //１÷ｘ
        private void OneX()
        {
            decimal bk = decimal.Parse(label.Content.ToString());
            if(bk != 0)
            {
                str = "" + 1/bk;
                label.Content = str;
            }
        }

        //プラスマイナス逆転
        private void Cange()
        {
            decimal bk = decimal.Parse(label.Content.ToString());
            if (bk != 0)
            {
                str = "" + (bk * -1);
                label.Content = str;
            }
        }

        //1文字削除
        private void back()
        {
            string bk = label.Content.ToString();
            if ((bk[0] != '-' && bk.Length > 1) || (bk[0] == '-' && bk.Length > 2))
            {
                str = bk.Substring(0, bk.Length - 1);
                label.Content = str;
            }
            else
            {
                str = "" + 0;
                label.Content = str;
            }
        }

        //値削除
        private void del()
        {
            str = "" + 0;
            label.Content = str;
        }

        //全削除
        private void clear()
        {
            list.Clear();
            list.Add(new data());
            str = "0";
            label.Content = str;
            label2.Content = str;
        }

        //メモリに保存
        private void mSave()
        {
            mem = decimal.Parse(label.Content.ToString());
            if (mem != 0) label3.Content = mem;
        }

        //メモリから書き出す
        private void mRelease()
        {
            if (mem != 0)
            {
                str = "" + mem;
                label.Content = str;
            }
        }

        //メモリ削除
        private void mClear()
        {
            mem = 0;
            label3.Content = "";
        }

        //メモリに足す
        private void mPluse()
        {
            mem += decimal.Parse(label.Content.ToString());
            if (mem != 0) label3.Content = mem;
        }

        //メモリから引く
        private void mMinus()
        {
            mem -= decimal.Parse(label.Content.ToString());
            if (mem != 0) label3.Content = mem;
        }

        private void button1_Click(object sender, RoutedEventArgs e){ addVal("1"); }
        private void button2_Click(object sender, RoutedEventArgs e){ addVal("2"); }
        private void button3_Click(object sender, RoutedEventArgs e){ addVal("3"); }
        private void button4_Click(object sender, RoutedEventArgs e){ addVal("4"); }
        private void button5_Click(object sender, RoutedEventArgs e){ addVal("5"); }
        private void button6_Click(object sender, RoutedEventArgs e){ addVal("6"); }
        private void button7_Click(object sender, RoutedEventArgs e){ addVal("7"); }
        private void button8_Click(object sender, RoutedEventArgs e){ addVal("8"); }
        private void button9_Click(object sender, RoutedEventArgs e){ addVal("9"); }
        private void button0_Click(object sender, RoutedEventArgs e){ addVal("0"); }
        private void button00_Click(object sender, RoutedEventArgs e) { addVal("0"); addVal("0"); }
        private void buttonDot_Click(object sender, RoutedEventArgs e) { addVal("."); }

        private void buttonPlus_Click(object sender, RoutedEventArgs e){ addOpt(0);}
        private void buttonMinus_Click(object sender, RoutedEventArgs e){ addOpt(1);}
        private void buttonAsterisk_Click(object sender, RoutedEventArgs e){ addOpt(2);}
        private void buttonSlash_Click(object sender, RoutedEventArgs e){ addOpt(3);}
        private void buttonPercent_Click(object sender, RoutedEventArgs e) { addOpt(4); }

        private void buttonEqual_Click(object sender, RoutedEventArgs e) { answ(); }
        
        //編集系
        private void buttonRoot_Click(object sender, RoutedEventArgs e) { root(); }
        private void buttonOneX_Click(object sender, RoutedEventArgs e) { OneX(); }
        private void buttonBack_Click(object sender, RoutedEventArgs e) { back(); }
        private void buttonCE_Click(object sender, RoutedEventArgs e) { del(); }
        private void buttonCange_Click(object sender, RoutedEventArgs e) { Cange(); }

        //メモリ関係
        private void buttonMS_Click(object sender, RoutedEventArgs e){ mSave(); }
        private void buttonMR_Click(object sender, RoutedEventArgs e){ mRelease(); }
        private void buttonMC_Click(object sender, RoutedEventArgs e){ mClear(); }
        private void buttonMPlus_Click(object sender, RoutedEventArgs e) { mPluse(); }
        private void buttonMMinus_Click(object sender, RoutedEventArgs e) { mMinus(); }

        private void buttonClear_Click(object sender, RoutedEventArgs e) { clear(); }

    }
}
