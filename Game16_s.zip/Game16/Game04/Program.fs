﻿open Microsoft.Xna.Framework;
open Microsoft.Xna.Framework.Audio;
open Microsoft.Xna.Framework.Content;
open Microsoft.Xna.Framework.Graphics;
open Microsoft.Xna.Framework.Input;
open System.IO;

//ゲームクラス
type MyGame() as this =
    inherit Game(IsMouseVisible=true)//スーパークラス設定

    //メンバ変数的なもの
    let g = new G.MyGraphics(this,320,240)
    let mutable array = Array2D.zeroCreate 8 8//盤面
    let mutable array2 = Array2D.zeroCreate 8 8//置けるかどうかチェック用
    let mutable kind = 1 //白黒
    let mutable initFlg = false //初期化フラグ
    let mutable kekka = 0 //結果
    let mutable cpuFlg = false//相手をCPUにするかどうかのフラグ
    let mutable dx = -1
    let mutable dy = -1

    //盤面上の石の数
    let sumKuro = ref 0
    let sumSiro = ref 0

    //テーブル
    //上,右上,右,右下,下,左下,左,左上
    let tx = [| 0; 1; 1; 1; 0;-1;-1;-1|]
    let ty = [|-1;-1; 0; 1; 1;-1; 0; 1|]

    //色設定
    let c =
        function
        | 0 -> Color.LawnGreen
        | 1 -> Color.Black
        | 2 -> Color.White
        |_  -> Color.Gray

    //範囲外
    let posChk(x,y) = y >= 0 && y <= array.GetUpperBound(0) && x >= 0 && x <= array.GetUpperBound(1)

    //白と黒を入れ替えるときに使うだけ
    let flip i = if i = 1 then 2 else 1

    //石をひっくり返してひっくり返した数を返す関数(flgがfalseの場合は石はそのまま)
    let rec chk (x, y, mx, my, flg) =
        let px = x+mx
        let py = y+my
        //範囲外か
        if posChk( px, py ) = false then
            0
        //現在の色と違う色の場合
        else if array.[ px, py ] = flip(kind) then
            let i = chk(px, py, mx, my, flg) //こいつが再帰処理
            if i > 0 then
                if flg then array.[ px, py ] <- kind
                i+1
            else i
        //何も置かれていない場合
        else if  array.[ px, py ] = 0 then
            0
        //現在の色と同じ色の場合
        else
            1

    //置けるかどうか
    let boardChk () =
        let mutable max = 0 //ひっくり返せる最大の石の数
        let mutable maxX = 0
        let mutable maxY = 0
        for y = 0 to 7 do
            for x = 0 to 7 do
                if array.[x,y] = 0 then //何も置いていないマス目のとき
                    let mutable sum = 0
                    for k = 0 to 7 do
                        let l = chk( x, y,  tx.[k], ty.[k], false )
                        if l > 1 then
                            sum <- sum + (l-1)
                    array2.[x,y] <- sum
                    if max < sum then
                        max <- sum
                        maxX <- x
                        maxY <- y
                else
                    array2.[x,y] <- 0
        (max,maxX,maxY)

    //石の数を数える
    let sumIsi () =
        sumKuro := 0
        sumSiro := 0
        Array2D.iter (fun i -> if i = 1 then sumKuro := (sumKuro.Value + 1) ) array
        Array2D.iter (fun i -> if i = 2 then sumSiro := (sumSiro.Value + 1) ) array


    //初期化処理
    let init () =
        kekka <- 0
        kind <- 1
        dx <- -1
        dy <- -1
        array <- Array2D.zeroCreate 8 8
        array.[3,3] <- 1
        array.[3,4] <- 2
        array.[4,3] <- 2
        array.[4,4] <- 1
        boardChk () |> ignore
        sumIsi ()
        initFlg <- true

    //コンテンツ登録
    override this.LoadContent() =
        g.LoadContent()

    //-------------------ゲームロジック-----------------------
    override this.Update gametime =
        km.setKey()//キー取得
        if km.kIsPush(Keys.Escape) then base.Exit()//終了処理

        if initFlg = false then
            if km.mIsPush(0) then
                init()//初期化処理
                
        else
            //CPUに切り替える
            if km.kIsPush(Keys.Space) then
                cpuFlg <- not cpuFlg
                 
            //石を置く処理
            if km.mIsPush(0) then
                //マウス位置からマス目を算出
                let mutable px = km.ms.X/24
                let mutable py = km.ms.Y/24

                //CPUの場合
                if kind = 2 && cpuFlg then
                    let (max,x,y) = boardChk()
                    px <- x
                    py <- y              
                
                //盤面の範囲内 + マスに何もない + ひっくり返る石がある の場合 
                if posChk(px,py) && array.[ px, py ] = 0 && array2.[ px, py ] > 0 then
                    array.[ px, py ] <- kind //石を置く
                    dx <- px
                    dy <- py

                    //石を裏返す
                    for i = 0 to 7 do
                        chk( px, py,  tx.[i], ty.[i] , true) |> ignore

                    //石の数を数える
                    sumIsi ()

                    kind <- flip(kind) //白黒交代
                    let (max,x,y) = boardChk()
                    if max = 0 then
                        kind <- flip(kind) //白黒交代
                        let (max,x,y) = boardChk()
                        if max = 0 then
                            //白も黒も置けないようなので終了処理
                            if !sumKuro > !sumSiro then kekka <- 1      //黒のかち
                            else if !sumKuro < !sumSiro then kekka <- 2//白のかち
                            else kekka <- 3 //ドロー

                            initFlg <- false
 
        base.Update gametime
        
    //-----------------------描画処理--------------------------------
    override this.Draw gametime =
        g.Clear(Color.Black)//画面のクリア

        //盤面あたりのの背景
        g.FillRect(0, 0, 24*8, 24*8, Color.DarkGreen)

        //盤面の描画関数
        let drawTile x y i =
            g.FillRect(x*24, y*24, 23, 23, c i)
            if array2.[x,y] <> 0 then g.DrawTextM( (string)array2.[x,y] ,x*24, y*24, Color.Black)
        
        //盤面の描画
        Array2D.iteri drawTile array

        //四角形カーソル描画
        if not (kind = 2 && cpuFlg) then
            g.DrawRect ( km.ms.X/24*24, km.ms.Y/24*24, 24, 24, Color.Red )
        
        //直前におかれた石の位置を表示
        g.DrawRect ( dx*24, dy*24, 24, 24, Color.Red )

        //ゲーム名表示
        g.DrawTextM("<オセロ>" ,200, 0, Color.White)
        //石の数表示
        if kind = 1 then g.SetColor(Color.Red) else g.SetColor(Color.White)
        g.DrawTextM("くろ:" + (string)!sumKuro ,220, 32)
        if kind = 2 then g.SetColor(Color.Red) else g.SetColor(Color.White)
        g.DrawTextM("しろ:" + (string)!sumSiro ,220, 48)

        //CPUかどうか表示
        if cpuFlg then
            g.DrawTextM("CPU",220,64,Color.Yellow)

        //結果の文言
        let kekkaStr =
            function
            | 1 -> "くろのかち"
            | 2 -> "しろのかち"
            | 3 -> "ひきわけ"
            |_  -> ""

        //結果表示
        g.DrawTextM(kekkaStr(kekka),220,80,Color.White)

        //ヘルプ表示
        g.SetColor(Color.White)
        g.DrawTextM("スペースキーで",200,128)
        g.DrawTextM("しろをCPUに",200,148)
        g.DrawTextM("きりかえられる",200,168)

[<EntryPoint>]//プログラム開始位置
let main(args : string[]) =
    let game = new MyGame()
    game.Run()
    game.Dispose()
    0

