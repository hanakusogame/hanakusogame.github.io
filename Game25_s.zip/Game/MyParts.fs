﻿//パーツモジュール
module MyParts
open System
open System.Drawing
open System.Windows.Forms
open System.Collections.Generic
open MyGraphics; open MyInput

//ボタンクラス
type Button( x:int, y:int, _str:string) =
    let mutable focusFlg = false //フォーカスが当たっているかどうか
    let mutable _status = 0 //動作状態 0:動作中 1:停止中 2:非表示
    let mutable str = _str
    
    //フォーカスのチェック関数
    let chk() = (x < mPos().X && x + 100 > mPos().X && y < mPos().Y && y + 16 > mPos().Y)

    member this.Str with get() = str and set(i) = str <- i

    //動作状態取得・設定
    member this.status
         with get() = _status
         and set(i) = _status <- i
    
    //フォーカス取得
    member this.chkFocus() = focusFlg

    //更新
    member this.update() =
        if _status = 0 then
            focusFlg <- chk()
            if focusFlg && ( kPush(Keys.Enter) || mPush(0)) then
                true
            else
                false
        else
            false
    
    //描画
    member this.draw() =
        if _status = 0 || _status = 1 then

            //背景
            setColor(Color.Blue)
            fRect x y 100 15

            //フォーカスが当たっている
            if _status = 0 && focusFlg then
                setColor(Color.Red)
                dRect x y 100 16

            //選択肢文字列表示
            setColor( if _status = 0 then Color.White else Color.Gray )
            dStr x y str


//選択肢クラス(ボタンを並べているだけ)
type SelectBox( _x:int, _y:int, l:string list) =
    let mutable x = _x
    let mutable y = _y
    let createBtnList (l:string list) = [ for i in 0 .. (l.Length-1) -> new Button( x, (y + 16 * i), (l.[i]) ) ]

    let mutable btnList = createBtnList l
    let mutable _status = 0 //動作状態 0:動作中 1:停止中 2:非表示

    //リスト変更
    member this.list
         with get() = btnList
         and set(i) = btnList <- createBtnList i

    //動作状態取得・設定
    member this.status
         with get() = _status
         and set(i) =
            List.iter(fun (b:Button) -> b.status <- i )btnList
            _status <- i
    
    //フォーカス位置取得
    member this.chkFocus()=
        match List.tryFindIndex( fun (b:Button) -> b.chkFocus() )btnList with
        | Some value -> value
        | None -> -1

    //更新
    member this.update()=
        match List.tryFindIndex( fun (b:Button) -> b.update() )btnList with
        | Some value -> value
        | None -> -1

    //描画
    member this.draw() =
        List.iter(fun (b:Button) -> b.draw() )btnList


//文字列を表示するだけクラスtest
type MesBox(x:int, y:int, w:int, h:int) =
    let mutable _str = [""]

    member this.str
        with get() = _str
        and set(i) = _str <- i


    member this.clear() =
        _str <- []

    member this.add(s) =
        _str <- _str @ [s]

    //描画
    member this.draw() =
        setColor(Color.DarkGreen)
        fRect x y w h
        setColor(Color.Gray)
        dRect x y w h
        setColor(Color.White)
        List.iteri (fun i s -> dStrS (x+2) (i*10+y+2) s) _str