﻿module Gatya

open System
open System.Drawing
open System.Windows.Forms
open System.Collections.Generic
open System.IO
open System.Runtime.Serialization.Formatters.Binary

open MyGraphics; open MyInput; open MyParts
open Actor; open Command; open CmdManager
open Battle
open Load
open Home
open State

//ガチャ
type Gatya(sBox:SelectBox,mBox:MesBox) =
    let mutable initFlg = false
    let mutable state = 0
    let mutable next = State.Gatya
    let mutable p = None
    let mutable cnt = 0
    let priceList = [ (1,9,300) ; (10,20,1000) ; (20,30,5000) ; (30,40,10000) ]

    let init() =
        sBox.list <- ["Lv:1～9";"Lv:10～19";"Lv:20～29";"Lv:30～39";"戻る"]
        state <- 0
        next <- State.Gatya
        cnt <- 0
        initFlg <- true

    member this.update() =

        if not(initFlg) then init()
        
        match state with
        | 0 -> 
            match sBox.update() with
            |  4 -> initFlg <- false ; next <- State.Home
            | -1 -> ()
            | a  ->
                let min,max,price = priceList.[a]
                if price > actMng.gold then
                    mBox.str <- ["お金が足りません"]
                else
                    actMng.gold <- actMng.gold - price
                    p <- Some({actMng.aListBase.[rnd.Next(50)] with order = -1})
                    levelUpI p.Value (rnd.Next(min,max))
                    actMng.pList <- p.Value :: actMng.pList

                    sBox.list <- []
                    state <- 1

            setColor(Color.White)
            dStr 2 2 "<料金>" 
            List.iteri(fun i (min,max,price) ->
                dStr 20 (i * 40 + 20) ( "Lv:" + min.ToString() + "～" + max.ToString() )
                dStr 60 (i * 40 + 40) (price.ToString() + "円")
            )priceList

            next
        | 1 ->
            if cnt = 60 then
                mBox.str <- [ p.Value.name + " Lv" + p.Value.lv.ToString() + " が 仲間になった" ]
                state <- 2
            else
                setColor(Color.White)
                dRect 60 cnt 100 55
                cnt <- cnt + 1
            State.Gatya
        | 2 ->
            if mPush(0) then
                initFlg <- false
                State.Home
            else
                actMng.draw 60 60 p.Value
                State.Gatya

        | _ ->
            State.Error