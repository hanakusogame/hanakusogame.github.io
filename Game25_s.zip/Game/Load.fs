﻿//道関連
module Load

open System
open System.Drawing
open System.Windows.Forms
open System.Collections.Generic
open MyGraphics; open MyInput; open MyParts
open Actor; open Command; open CmdManager
open Battle
open State

type LoadParam ={
                name : string
                mutable flg : bool
                length : int
                eList  : int list
                eLevel : int * int
                bList  : int list
                bLevel : int
            }

let mutable loadIndex = 0

let mutable loadList = []

type Map(sBox:SelectBox,mBox:MesBox)=

    let mutable initFlg = false
    let mutable next = State.Map

    let init() =
        let list = List.filter(fun i -> i.flg = true)loadList
        sBox.list <- [ for i in list -> i.name ] @ ["戻る"]
        next <- State.Map
        initFlg <- true

    member this.update() =
        if initFlg = false then init()

        match sBox.update() with
        | -1 -> State.Map
        |  a ->
            if a = (sBox.list.Length - 1) then
                initFlg <- false
                State.Home
            else
                loadIndex <- a
                initFlg <- false
                State.Stage

type Load(sBox:SelectBox,mBox:MesBox)=
    let mutable initFlg = false
    let mutable next = State.Stage
    let mutable state = 0
    let mutable nowPos = 0
    let mutable aList:Actor list = []
    let battle = new Battle(sBox,mBox)

    let setParam (a:Actor) = a.hp <- a.hpMax; a.mp <- a.mpMax; a.at <- a.atBase ; a.df <- a.dfBase ; a.sp <- a.spBase ; a

    let init() =
        //味方の情報を設定
        aList <- []
        let p =
            actMng.pList |>
            List.sortBy(fun i -> i.order)
        
        for i in 0 .. 2 do
            aList <- setParam(List.find(fun j -> j.order = i)actMng.pList) :: aList

        sBox.list <- [ "進む"; "戻る" ]
        initFlg <- true
        state <- 0
        nowPos <- 0
        next <- State.Stage

    let createActorList() =

        //味方の情報を設定
        actMng.aList <- aList

        //敵の情報設定
        let l = actMng.aListBase
        let load = loadList.[loadIndex]
        let mutable eList = []

        //ボスのとき
        if nowPos = load.length then
            //敵リスト作成
            for i in 0 .. 2 do
                eList <- {l.[ load.bList.[i] ] with order = i ; id = 1} :: eList
        
        //普通の敵
        else
            //敵リスト作成
            for i in 0 .. 2 do
                eList <- {l.[ load.eList.[ rnd.Next(0,load.eList.Length) ] ] with order = i ; id = 1} :: eList
        
            //レベルアップ処理
            List.iter(fun a ->
                let min,max = load.eLevel
                levelUpI a (rnd.Next(min,max))
                setParam(a) |> ignore
                )eList

        //戦闘に出すリストに追加
        actMng.aList <- eList @ actMng.aList

    member this.update() =

        if initFlg = false then init()

        let load = loadList.[loadIndex]

        if state = 0 then
            if nowPos = load.length then
                
                if loadList.Length-1 > loadIndex then
                    loadList.[loadIndex+1].flg <- true
                    mBox.str <- ["クリア!!"]
                else
                    mBox.str <- ["全面クリア!!　おめでとうございます。";"そしてプレイありがとうございます。";"　製作者：はなくそ"]
                
                sBox.list <- [ "戻る" ]
                state <- 2

            match sBox.update() with
            |  0 ->
                nowPos <- nowPos + 1
                if rnd.Next(2) = 0 || nowPos = load.length then
                    createActorList()
                    state <- 1
            |  1 ->
                if nowPos > 0 then
                    nowPos <- nowPos - 1
                    if rnd.Next(3) = 0 then
                        createActorList()
                        state <- 1
                else
                    initFlg <- false ; next <- State.Home
            |  _ -> ()
        
            //描画
            setColor(Color.White)
            dStr 0 0 ("位置:" + nowPos.ToString() + "/" + load.length.ToString())
            dStr 220 0 load.name

            //Actor情報表示
            actMng.alldraw(aList)
        elif state = 1 then
            match battle.update() with
            | 1 ->
                state <- 0
                List.iter(fun a -> a.at <- a.atBase ; a.df <- a.dfBase ; a.sp <- a.spBase)aList
                sBox.list <- [ "進む"; "戻る" ]
            | 2 ->
                initFlg <- false ; next <- State.Home
            | _ -> ()
        else
            match sBox.update() with
            | 0 ->
                initFlg <- false ; next <- State.Home
            | _ -> ()

        next
