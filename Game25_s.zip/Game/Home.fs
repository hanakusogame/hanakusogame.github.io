﻿module Home

open System
open System.Drawing
open System.Windows.Forms
open System.Collections.Generic
open MyGraphics; open MyInput; open MyParts
open Actor; open Command; open CmdManager
open State

//ホーム画面
type Home(sBox:SelectBox,mBox:MesBox) =
    let mutable party:Actor Option [] = [|None;None;None|]
    let mutable state = 0
    let mutable initFlg = false
    let mutable bkFocus = -1
    let mutable actCnt = 0
    let mutable actFocus = -1
    let mutable wazaList:BaseCmd list = []
    

    let setParty () =
        for i in 0 .. 2 do
            party.[i] <- List.tryFind(fun a -> a.order = i )actMng.pList

    let astr (a:Actor) =
            [
                a.name + " Lv:" + a.lv.ToString() + " HP:" + a.hpMax.ToString() + " MP:" + a.mpMax.ToString()
                "属性:" + a.strAttr() + " 攻撃:" + a.atBase.ToString() + " 守備:" + a.dfBase.ToString() + " 速さ:" + a.spBase.ToString()
                "経験値:" + a.exp.ToString()
            ]

    let init() =
        sBox.list <- [ "討伐"; "ガチャ"; "セーブ"; "ロード" ]
        setParty ()

    member this.update() =
        if initFlg = false then init() ; initFlg <- true
        let x,y = mPos().X, mPos().Y
        let focus = sBox.chkFocus()

        if focus <> bkFocus then
            match focus with
            | 0 -> mBox.str <- [ "<討伐>"    ; "鬼の討伐に赴きます"]
            | 1 -> mBox.str <- [ "<ガチャ>"  ; "仲間を手に入れます"]
            | 2 -> mBox.str <- [ "<セーブ>"  ; "セーブします"]
            | 3 -> mBox.str <- [ "<ロード>"  ; "ロードします"]
            | _ -> mBox.str <- [ "<HOME画面>"; "われらの秘密基地です"]

        //上へ
        if x > 105 && y > 14 && x < 105+32 && y < 14+18 then
            if mPush(0) then
                if actCnt <> 0 then
                    actCnt <- actCnt - 1
        
        //下へ
        if x > 105 && y > 34 && x < 105+32 && y < 34+18 then
            if mPush(0) then
                actCnt <- actCnt + 1
        
        //フォーカス位置から設定
        if x < 102 && y > 16 && y < 164 then
            let bkFocus = actFocus
            actFocus <-  ( mPos().Y - 14 ) / 16
            if actMng.pList.Length <= actFocus+actCnt then
                actFocus <- -1
            
            if actFocus <> -1 then
                if actFocus <> bkFocus then
                    let a = actMng.pList.[actFocus+actCnt]
                    mBox.str <- astr a
                    wazaList <- [for i in a.cmdList -> (selectCmd a i)]
                if mPush(0) then
                    //パーティメンバー選択
                    let index = actFocus+actCnt
                    actMng.pList.[index].order <-
                        match actMng.pList.[index].order with
                        |0|1|2 -> -1
                        |_ ->
                            if not(List.exists(fun a -> a.order = 0 )actMng.pList) then
                                0
                            elif not(List.exists(fun a -> a.order = 1 )actMng.pList) then
                                1
                            elif not(List.exists(fun a -> a.order = 2 )actMng.pList) then
                                2
                            else actMng.pList.[index].order

                    setParty ()

        //フォーカス位置から設定(技)
        if x > 105 && y > 68 && x < 210 && y < 188 then
            let index = (y-70)/10
            if index >= 0 && index < wazaList.Length then
                mBox.str <- wazaList.[index].info
        

        bkFocus <- sBox.chkFocus()

        //////////////////描画処理///////////////////////

        setColor(Color.White)
        dStr 210 3 "ＨＯＭＥ画面"

        dStrS 2 2 ("<仲間一覧>")

        dStrS 130 2 ("<パーティー>")

        dStrS 110 56 ("<わざ>")

        dStrS 3 178 ("お金:" + (actMng.gold.ToString().PadLeft(10)) + "円")

        //仲間一覧
        for i in 0 .. 9 do

            if i = actFocus then setColor(Color.Blue)
            else setColor(Color.DarkBlue)
            fRect (2) (14 + (i *16)) 100 15
            
            if i+actCnt < actMng.pList.Length then
                let p = actMng.pList.[i+actCnt]
                if p.order = -1 then setColor(Color.White)
                else setColor(Color.Red)
                dStrS (4) (16 + (i *16)) ("lv:" + p.lv.ToString())
                dStrS (40) (16 + (i *16)) p.name
        
        setColor(Color.DarkRed)
        fRect 105 14 18 18
        fRect 105 34 18 18

        setColor(Color.White)
        dStr 103 14 "上"
        dStr 103 34 "下"

        //パーティーメンバー表示
        let mutable i = 0
        for p in party do
            match p with
            | None -> ()
            | Some(a) ->
                dStrS 124 ( i * 12 + 16 ) ("lv:" + a.lv.ToString() + " " + a.name) 
            i <- i + 1

        //技一覧表示
        setColor(Color.DarkGreen)
        fRect 105 68 105 120
        setColor(Color.White)
        List.iteri(fun i (a:BaseCmd) -> dStrS 110 (i*10+70) (a.name) )wazaList
        
        match sBox.update() with
        | -1 -> State.Home
        |  a ->
            match a with
            | 0 ->
                if ( party.[0] = None || party.[1] = None || party.[2] = None ) then
                    mBox.str <- [ "パーティーのメンバーが足りません";"３匹選んでください"]
                    State.Home
                else
                    initFlg <- false
                    Map
            | 1 -> initFlg <- false ; Gatya
            | 2 -> initFlg <- false ; SaveData
            | 3 -> initFlg <- false ; LoadData
            | _ -> initFlg <- false ; Error 