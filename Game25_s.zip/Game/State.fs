﻿module State

type State =
| Home
| Gatya
| Map
| Stage
| SaveData
| LoadData
| Error