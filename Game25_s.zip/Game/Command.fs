﻿//コマンド
module Command
open System
open MyParts
open Actor

let mutable rnd = new Random()

let attrStr=
    function
    |1-> "火"
    |2-> "氷"
    |3-> "雷"
    |_-> "無" 

//コマンド基本
[<AbstractClass>]
type BaseCmd(_pp:Actor) =

    let mutable _p = _pp //実行者
    let mutable _order = _p.sp //順番
    let mutable _sList:Actor list = []//対象者
    let mutable _mList:Actor list = []//命中者
    let mutable _endFlg = false //終了フラグ

    //プロパティ
    member this.p with get() = _p and set i = _p <- i
    member this.order with get() = _order and set i = _order <- i
    member this.sList with get() = _sList and set i = _sList <- i
    member this.mList with get() = _mList and set i = _mList <- i
    member this.endFlg with get() = _endFlg and set i = _endFlg <- i

    abstract member name : string //コマンド名
    abstract member info : string list//説明文
    abstract member runChk : MesBox -> bool //単体攻撃かどうかのフラグ
    abstract member singleFlg : bool //単体攻撃かどうかのフラグ
    abstract member setSList : Actor -> bool
    abstract member run : MesBox -> bool

//待機(何もしない)クラス
type Sleep(p:Actor) =
    inherit BaseCmd(p)
    override this.name = "待機"
    override this.info = [this.name ; "なにもしない"]
    override this.runChk mb = true
    override this.singleFlg = false //意外と重要
    override this.setSList a = false
    override this.run mb =
        mb.str <- [p.name + " は、ぼーっとしている"]
        this.endFlg <- true
        true

//物理攻撃基本クラス
type AttackBase(p:Actor) =
    inherit BaseCmd(p)

    //表示名
    override this.name = "攻撃基本"

    member this.infoBase = 
          [
            this.name + " 攻撃力:" + this.power.ToString() + "% 命中率:" + this.accuracy.ToString() + "%"
            "属性:" + attrStr(this.attribute) + " " + if this.singleFlg then "単体" else "全体"
          ]      

    //情報表示
    override this.info = this.infoBase @ ["攻撃の基本となるコマンド"]

    //実行可能かどうか
    override this.runChk mb = true

    //単体攻撃どうかフラグ
    override this.singleFlg = true

    //属性
    abstract member attribute : int
    default this.attribute = 0
    
    //攻撃力（％）
    abstract member power : int
    default this.power = 100
    
    //命中率 (%)
    abstract member accuracy : int
    default this.accuracy = 100

    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order

    //攻撃
    member this.Attack (mb:MesBox) e =
        //対象者が死んでいない
        if e.hp > 0 then
            //命中したかどうか
            if rnd.Next(100) < this.accuracy then
                let mutable power = this.power

                //得意技(属性が同じ)かどうか
                if this.attribute <> 0 && this.attribute = this.p.attr then
                    mb.add( (this.p.name) + " の得意技!!" )
                    power <- power * 150 / 100

                //効果は抜群かどうか
                if (this.attribute = 1 && e.attr = 3) || (this.attribute = 2 && e.attr = 1) || (this.attribute = 3 && e.attr = 2) then
                    mb.add( "効果は抜群だ！！" )
                    power <- power * 150 / 100

                //効果はいまひとつだ
                elif (this.attribute = 1 && e.attr = 2) || (this.attribute = 2 && e.attr = 3) || (this.attribute = 3 && e.attr = 1) then
                    mb.add( "効果はいまひとつ" )
                    power <- power * 50 / 100

                //ダメージ算出
                let damage = 
                    let d = this.p.at * power / 100 - e.df
                    if d > 0 then d else 1

                //ダメージを与える
                e.hp <- e.hp - damage
                mb.add((e.name)+ " に " + damage.ToString() + "のダメージ" )

                if e.hp <= 0 then
                    e.hp <- 0
                    mb.add((e.name)+ " をたおした" )
                true
            else
                mb.add("ミス！！" )
                false
        else
            mb.add((e.name)+ "はすでに死んでいる" )
            false

    //行動する
    override this.run mb =
        mb.clear()
        this.endFlg <- true//終了フラグを立てる
        //実行者が死んでいない
        if this.p.hp > 0 then
            mb.add( this.p.name + " の " + this.name )

            //命中した奴のリストを入れる
            this.mList <- 
                List.filter(this.Attack mb )this.sList
            true
        else
            false

//魔法基本クラス
type MagicBase(p:Actor) =
    inherit BaseCmd(p)

    //表示名
    override this.name = "魔法基本"

    member this.infoBase =
        [
            this.name + " 攻撃力:" + this.power.ToString() + " 命中率:" + this.accuracy.ToString() + "%"
            "属性:" + attrStr(this.attribute) + " " + (if this.singleFlg then "単体" else "全体") + " 消費MP:" + this.costMp.ToString()
        ]

    override this.info = this.infoBase @ [ "魔法の基本となるコマンド" ]

    override this.runChk mb =
        if this.p.mp >= this.costMp then
            true
        else
            mb.str <- ["MPが足りない"]
            false

    //単体攻撃どうかフラグ
    override this.singleFlg = true

    //変更対象ステータス(HP,MP,攻撃,守備,素早)
    abstract member tergetStatus : (bool * bool * bool * bool * bool)
    default this.tergetStatus = (true,false,false,false,false)

    //属性
    abstract member attribute : int
    default this.attribute = 2

    //威力
    abstract member power : int
    default this.power = 4

    //命中率 (%)
    abstract member accuracy : int
    default this.accuracy = 100

    //消費MP
    abstract member costMp : int
    default this.costMp = 3

    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id

    member this.Attack (mb:MesBox) e =
        //対象者が死んでいる
        if e.hp <= 0 then
            mb.add((e.name)+ "はすでに死んでいる" )
            false
        else
            //命中したかどうか
            if rnd.Next(100) >= this.accuracy then
                mb.add("ミス！！" )
                false
            else
                let mutable power = this.power

                //得意技(属性が同じ)かどうか
                if this.attribute <> 0 && this.attribute = this.p.attr then
                    mb.add( (this.p.name) + " の得意技!!" )
                    power <- power * 150 / 100

                //効果は抜群かどうか
                power <-
                    match ( this.attribute, e.attr ) with
                    |(1,3)|(2,1)|(3,2) -> mb.add( "効果は抜群だ！！" ) ; power * 150 / 100
                    |(1,2)|(2,3)|(3,1) -> mb.add( "効果はいまひとつ" ) ; power * 50 / 100
                    |_ -> power

                match this.tergetStatus with
                //HP
                |(true,_,_,_,_) ->
                    power <-
                        if e.hp - power <= 0 then e.hp
                        elif e.hp - power > e.hpMax then e.hp - e.hpMax
                        else power

                    //ダメージを与える
                    e.hp <- e.hp - power
                    mb.add((e.name)+ " に " + ( if power > 0 then power.ToString() + " のダメージ" else (-power).ToString() + " 回復" ) )
                    if e.hp <= 0 then
                        e.hp <- 0
                        mb.add((e.name)+ " は死んだ" )
                //MP
                |(_,true,_,_,_) ->
                    power <-
                        if e.mp - power <= 0 then e.mp
                        elif e.mp - power > e.mpMax then e.mp - e.mpMax
                        else power

                    //ダメージを与える
                    e.mp <- e.mp - power
                    mb.add((e.name)+ " のMPが " + ( if power > 0 then power.ToString() + " へった" else (-power).ToString() + " ふえた" ) )

                //攻撃力
                |(_,_,true,_,_) ->
                    //ダメージを与える
                    e.at <- e.at - power
                    mb.add( (e.name)+ " の攻撃力が " + ( if power > 0 then power.ToString() + " へった" else (-power).ToString() + " ふえた" ) )

                //防御力
                |(_,_,_,true,_) ->
                    //ダメージを与える
                    e.df <- e.df - power
                    mb.add( (e.name)+ " の守備力が " + ( if power > 0 then power.ToString() + " へった" else (-power).ToString() + " ふえた" ) )

                //素早さ
                |(_,_,_,_,true) ->
                    //ダメージを与える
                    e.sp <- e.sp - power
                    mb.add( (e.name)+ " の素早さが " + ( if power > 0 then power.ToString() + " へった" else (-power).ToString() + " ふえた" ) )


                |_ -> ()

                true




    //行動する
    override this.run mb =
        mb.clear()
        this.endFlg <- true//終了フラグを立てる
        //実行者が死んでいる
        if this.p.hp <= 0 then
            false
        else
            mb.str <- [ this.p.name + " の " + this.name ]
            //MPが足りない
            if this.p.mp < this.costMp then
                mb.add("ＭＰが足りない！！")
            else
                this.p.mp <- this.p.mp - this.costMp
                this.mList <- List.filter(this.Attack mb)this.sList
            true

//石投げ
type Attack01(p:Actor) =
    inherit AttackBase(p)
    override this.name = "石投げ"
    override this.info = this.infoBase @ ["好きな位置に攻撃できる"]
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id

//体当たり
type Attack02(p:Actor) =
    inherit AttackBase(p)
    override this.name = "たいあたり"
    override this.info = this.infoBase @ ["前方に攻撃"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 100
    override this.accuracy = 95
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order

//つつく
type Attack03(p:Actor) =
    inherit AttackBase(p)
    override this.name = "つつく"
    override this.info = this.infoBase @ ["斜めに攻撃"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 100
    override this.accuracy = 100
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && ( this.p.order = a.order + 1 || this.p.order = a.order - 1 )

//かみつく
type Attack04(p:Actor) =
    inherit AttackBase(p)
    override this.name = "かみつく"
    override this.info = this.infoBase @ ["前方に攻撃"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 110
    override this.accuracy = 90
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order

//炎パンチ
type Attack05(p:Actor) =
    inherit AttackBase(p)
    override this.name = "炎パンチ"
    override this.info = this.infoBase @ ["前方に攻撃"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 1//属性
    override this.power = 100
    override this.accuracy = 95
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order

//氷パンチ
type Attack06(p:Actor) =
    inherit AttackBase(p)
    override this.name = "氷パンチ"
    override this.info = this.infoBase @ ["前方に攻撃"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 2//属性
    override this.power = 100
    override this.accuracy = 95
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order

//雷パンチ
type Attack07(p:Actor) =
    inherit AttackBase(p)
    override this.name = "雷パンチ"
    override this.info = this.infoBase @ ["前方に攻撃"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 3//属性
    override this.power = 100
    override this.accuracy = 95
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order

//とび蹴り
type Attack08(p:Actor) =
    inherit AttackBase(p)
    override this.name = "とびげり"
    override this.info = this.infoBase @ ["遠くに攻撃"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 140
    override this.accuracy = 85
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && ( this.p.order = a.order + 2 || this.p.order = a.order - 2 )

//回し蹴り
type Attack09(p:Actor) =
    inherit AttackBase(p)
    override this.name = "回しげり"
    override this.info = this.infoBase @ ["全体に攻撃"]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 0//属性
    override this.power = 90
    override this.accuracy = 80
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id

//メガパンチ
type Attack10(p:Actor) =
    inherit AttackBase(p)
    override this.name = "メガパンチ"
    override this.info = this.infoBase @ ["前方に大ダメージ"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 170
    override this.accuracy = 70
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order

//頭突き
type Attack11(p:Actor) =
    inherit AttackBase(p)
    override this.name = "ずつき"
    override this.info = this.infoBase @ ["前方に攻撃。自分もダメージ"]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 150
    override this.accuracy = 80
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order
    override this.run mb =
        let flg = base.run mb
        let d = this.p.at * 85 / 100 - this.p.df
        let dd = if d > 0 then d else 1
        this.p.hp <- this.p.hp - dd
        mb.add(this.p.name + " は " + dd.ToString() + " のダメージ")
        if this.p.hp <= 0 then
            this.p.hp <- 0
            mb.add(this.p.name + " は死んだ")

        flg

//自爆
type Attack12(p:Actor) =
    inherit AttackBase(p)
    override this.name = "じばく"
    override this.info = this.infoBase @ ["敵全体に大ダメージ。自分は死ぬ"]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 0//属性
    override this.power = 250
    override this.accuracy = 100
    //対象選択
    override this.setSList a = a.hp > 0 && a.id <> this.p.id
    override this.run mb =
        let flg = base.run mb
        this.p.hp <- 0
        mb.add(this.p.name + " は はじけとんだ")
        flg

///////////////無属性魔法/////////////////

//小爆発
type Magic01(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "小ばくはつ"
    override this.info = this.infoBase @ [ "謎の爆発により全員に小ダメージ" ]
    override this.singleFlg = false //全体攻撃
    override this.attribute = 0//無属性
    override this.power = 4
    override this.accuracy = 85
    override this.costMp = 6

//ガス爆発
type Magic02(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "ガスばくはつ"
    override this.info = this.infoBase @ [ "ガス爆発により全員に中ダメージ" ]
    override this.singleFlg = false //全体攻撃
    override this.attribute = 0//無属性
    override this.power = 10
    override this.accuracy = 85
    override this.costMp = 15

//核爆発
type Magic03(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "核ばくはつ"
    override this.info = this.infoBase @ [ "核爆発により全員に大ダメージ" ]
    override this.singleFlg = false //全体攻撃
    override this.attribute = 0//無属性
    override this.power = 40
    override this.accuracy = 85
    override this.costMp = 36

//吸血
type Magic04(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "吸血"
    override this.info = this.infoBase @ [ "敵のHPを吸収する" ]
    override this.singleFlg = true //全体攻撃
    override this.attribute = 0//無属性
    override this.power = 20
    override this.accuracy = 100
    override this.costMp = 19
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order
    override this.run mb =
        let flg = base.run mb
        this.p.hp <- this.p.hp + 20
        if this.p.hp > this.p.hpMax then this.p.hp <- this.p.hpMax
        mb.add(this.p.name + " は HPを 20 吸収！")
        flg

//波動砲
type Magic05(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "波動砲"
    override this.info = this.infoBase @ [ "単体に大ダメージ" ]
    override this.singleFlg = true //全体攻撃
    override this.attribute = 0//無属性
    override this.power = 45
    override this.accuracy = 95
    override this.costMp = 23
    override this.setSList a = a.hp > 0 && a.id <> this.p.id && this.p.order = a.order

/////////////火属性魔法//////////////////

//火の玉
type Magic06(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "火の玉"
    override this.info = this.infoBase @ [ "火の玉をぶつける" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 1//属性
    override this.power = 5
    override this.accuracy = 95
    override this.costMp = 3

//火のこ
type Magic07(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "火のこ"
    override this.info = this.infoBase @ [ "前方３匹に火のこをまきちらす" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 1//属性
    override this.power = 5
    override this.accuracy = 90
    override this.costMp = 8
    override this.setSList a =
        base.setSList(a) && ( this.p.order <= a.order + 1 && this.p.order >= a.order - 1 )

//火ばしら
type Magic08(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "火ばしら"
    override this.info = this.infoBase @ [ "正面の相手に火ばしらがふきだす" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 1//属性
    override this.power = 20
    override this.accuracy = 100
    override this.costMp = 15
    override this.setSList a =
        base.setSList(a) && this.p.order = a.order

//火の矢
type Magic09(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "火の矢"
    override this.info = this.infoBase @ [ "ななめの相手に火の矢を放つ" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 1//属性
    override this.power = 20
    override this.accuracy = 90
    override this.costMp = 20
    override this.setSList a =
        base.setSList(a) && ( this.p.order = a.order+1 || this.p.order = a.order-1 )

//大炎上
type Magic10(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "大炎上"
    override this.info = this.infoBase @ [ "巨大な炎を放つ" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 1//属性
    override this.power = 40
    override this.accuracy = 85
    override this.costMp = 45

//炎のうず
type Magic11(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    let mutable cnt = 0
    override this.name = "火のうず"
    override this.info = this.infoBase @ [ "火のうずをまとわりつかせる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 1//属性
    override this.power = 7
    override this.accuracy = 100
    override this.costMp = 20
    override this.run mb =
        let mutable flg = false

        if cnt = 0 then
            flg <- base.run mb
            this.endFlg <- false
        else
            mb.str <- ["火の渦がまとわりつく！"]
            this.mList <- List.filter(this.Attack mb)this.sList
            flg <- true

        if cnt >= 3 then
            mb.add("火の渦の効果が切れた")
            this.endFlg <- true

        cnt <- cnt + 1
        flg

///////////////氷属性魔法////////////////

//冷たい息
type Magic12(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "冷たい息"
    override this.info = this.infoBase @ [ "冷気をあびせる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 2//氷属性
    override this.power = 4
    override this.accuracy = 100
    override this.costMp = 4

//雪玉投げ
type Magic13(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "雪玉投げ"
    override this.info = this.infoBase @ [ "斜めの相手に雪の玉を投げる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 2//氷属性
    override this.power = 12
    override this.accuracy = 95
    override this.costMp = 9
    override this.setSList a =
        base.setSList(a) && ( this.p.order = a.order+1 || this.p.order = a.order-1 )

//雪あらし
type Magic14(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "雪あらし"
    override this.info = this.infoBase @ [ "敵全員に中ダメージ" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 2//氷属性
    override this.power = 22
    override this.accuracy = 90
    override this.costMp = 20

//猛吹雪
type Magic15(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "猛吹雪"
    override this.info = this.infoBase @ [ "敵全員に大ダメージ" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 2//氷属性
    override this.power = 41
    override this.accuracy = 90
    override this.costMp = 40

//クレバス
type Magic16(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "クレバス"
    override this.info = this.infoBase @ [ "敵１体を氷の割れ目に突き落とす";"１～８０のランダムダメージ" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 2//氷属性
    override this.power = rnd.Next(1,81)
    override this.accuracy = 100
    override this.costMp = 29

/////////////雷属性魔法//////////////

//静電気
type Magic17(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "静電気"
    override this.info = this.infoBase @ [ "敵に電流を流す" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 3//雷属性
    override this.power = 7
    override this.accuracy = 80
    override this.costMp = 4

//ろう電
type Magic18(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    let mutable cnt = 0
    override this.name = "ろう電"
    override this.info = this.infoBase @ [ "電気が漏れ出す。３ターン継続ダメージ" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 3//雷属性
    override this.power = 7
    override this.accuracy = 100
    override this.costMp = 15
    override this.run mb =
        let mutable flg = false

        if cnt = 0 then
            flg <- base.run mb
            this.endFlg <- false
        else
            mb.str <- ["ビリビリビリ！"]
            this.mList <- List.filter(this.Attack mb)this.sList
            flg <- true

        if cnt >= 3 then
            mb.add("ろう電の効果が切れた")
            this.endFlg <- true

        cnt <- cnt + 1
        flg

//10万ボルト
type Magic19(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "10万ボルト"
    override this.info = this.infoBase @ [ "敵全体に中ダメージ" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 3//雷属性
    override this.power = 23
    override this.accuracy = 95
    override this.costMp = 25

//落雷
type Magic20(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "落雷"
    override this.info = this.infoBase @ [ "単体に大ダメージ" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 3//雷属性
    override this.power = 48
    override this.accuracy = 95
    override this.costMp = 33

//雷神の怒り
type Magic21(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "雷神の怒り"
    override this.info = this.infoBase @ [ "全体に大ダメージ" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 3//雷属性
    override this.power = 40
    override this.accuracy = 90
    override this.costMp = 50

/////////////回復魔法系//////////////

//自己再生
type Magic22(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "自己再生"
    override this.info = this.infoBase @ [ "自分のHPを1/3回復" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = -this.p.hpMax * 30 /100
    override this.accuracy = 100
    override this.costMp = 13
    override this.setSList a = a.hp > 0 && a = this.p

//応急処置
type Magic23(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "応急処置"
    override this.info = this.infoBase @ [ "隣の相手のHPを少し回復" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = -10
    override this.accuracy = 100
    override this.costMp = 4
    override this.setSList a = a.hp > 0 && a.id = this.p.id && ( this.p.order = a.order-1 || this.p.order = a.order+1 )

//ヒール
type Magic24(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "ヒール"
    override this.info = this.infoBase @ [ "HPを回復" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = -30
    override this.accuracy = 100
    override this.costMp = 10
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//炎ヒール
type Magic25(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "炎ヒール"
    override this.info = this.infoBase @ [ "温めることにより HPを回復" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 1//属性
    override this.power = -30
    override this.accuracy = 100
    override this.costMp = 10
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//氷のヒール
type Magic26(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "氷のヒール"
    override this.info = this.infoBase @ [ "冷やすことにより HPを回復" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 2//属性
    override this.power = -30
    override this.accuracy = 100
    override this.costMp = 10
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//電気ヒール
type Magic27(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "電気ヒール"
    override this.info = this.infoBase @ [ "電気を流すことにより HPを回復" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 3//属性
    override this.power = -30
    override this.accuracy = 100
    override this.costMp = 10
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//癒しの風
type Magic28(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "癒しの風"
    override this.info = this.infoBase @ [ "味方全員のHPを回復" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 0//属性
    override this.power = -30
    override this.accuracy = 100
    override this.costMp = 15
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//大ヒール
type Magic29(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "大ヒール"
    override this.info = this.infoBase @ [ "HPをすごく回復" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = -80
    override this.accuracy = 100
    override this.costMp = 20
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//天使の微笑
type Magic30(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "天使の微笑"
    override this.info = this.infoBase @ [ "HPをすごく回復" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 0//属性
    override this.power = -80
    override this.accuracy = 100
    override this.costMp = 50
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//MAXヒール
type Magic31(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "MAXヒール"
    override this.info = this.infoBase @ [ "HPを 1000 回復" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = -1000
    override this.accuracy = 100
    override this.costMp = 37
    override this.setSList a = a.hp > 0 && a.id = this.p.id

///////////ステータス変化系//////////

////////あんまり意味無い系///////////

//鳴き声
type MagicSub01(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "鳴き声"
    override this.info = this.infoBase @ [ "たまにに素早さがちょっと下がる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 2
    override this.accuracy = 60
    override this.costMp = 0
    override this.tergetStatus = ( false, false, false, false, true )
    override this.setSList a = a.hp > 0 && a.id <> this.p.id

//にらむ
type MagicSub02(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "にらむ"
    override this.info = this.infoBase @ [ "たまにに守備力がちょっと下がる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 2
    override this.accuracy = 60
    override this.costMp = 0
    override this.tergetStatus = ( false, false, false, true, false )
    override this.setSList a = a.hp > 0 && a.id <> this.p.id

//いかく
type MagicSub03(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "いかく"
    override this.info = this.infoBase @ [ "たまにに攻撃力をちょっと下げる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 2
    override this.accuracy = 60
    override this.costMp = 0
    override this.tergetStatus = ( false, false, true, false, false )
    override this.setSList a = a.hp > 0 && a.id <> this.p.id

//いねむり
type MagicSub04(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "いねむり"
    override this.info = this.infoBase @ [ "たまににHP,MPがちょっと上がる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = -5
    override this.accuracy = 40
    override this.costMp = 0
    override this.tergetStatus = ( true, true, false, false, false )
    override this.setSList a = a.hp > 0 && a = this.p

//目をこする
type MagicSub05(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "目をこする"
    override this.info = this.infoBase @ [ "たまにに攻撃力,守備力がちょっと上がる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = -3
    override this.accuracy = 60
    override this.costMp = 0
    override this.tergetStatus = ( false, false, true, true, false )
    override this.setSList a = a.hp > 0 && a = this.p

//あくび
type MagicSub06(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "あくび"
    override this.info = this.infoBase @ [ "たまにに素早さがちょっと上がる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = -2
    override this.accuracy = 60
    override this.costMp = 0
    override this.tergetStatus = ( false, false, false, false, true )
    override this.setSList a = a.hp > 0 && a = this.p

//しっぽふり
type MagicSub07(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "しっぽふり"
    override this.info = this.infoBase @ [ "たまににMPをちょっと下げる" ]
    override this.singleFlg = true //単体攻撃
    override this.attribute = 0//属性
    override this.power = 2
    override this.accuracy = 60
    override this.costMp = 0
    override this.tergetStatus = ( false, true, false, false, false )
    override this.setSList a = a.hp > 0 && a.id <> this.p.id

/////////意味ありげ系//////////

//炎のサンバ
type MagicSub08(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "炎のサンバ"
    override this.info = this.infoBase @ [ "味方全体の攻撃力を上げる" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 1//属性
    override this.power = -20
    override this.accuracy = 100
    override this.costMp = 5
    override this.tergetStatus = ( false, false, true, false, false )
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//氷のワルツ
type MagicSub09(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "氷のワルツ"
    override this.info = this.infoBase @ [ "味方全体の守備力を上げる" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 1//属性
    override this.power = -20
    override this.accuracy = 100
    override this.costMp = 5
    override this.tergetStatus = ( false, false, false, true, false )
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//雷だいこ
type MagicSub10(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "雷だいこ"
    override this.info = this.infoBase @ [ "味方全体の素早さを上げる" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 1//属性
    override this.power = -20
    override this.accuracy = 100
    override this.costMp = 5
    override this.tergetStatus = ( false, false, false, false, true )
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//ふしぎなおどり
type MagicSub11(p:Actor) =
    inherit MagicBase(p)//魔法基本クラスを継承
    override this.name = "ふしぎなおどり"
    override this.info = this.infoBase @ [ "味方全体のMPを上げる" ]
    override this.singleFlg = false //単体攻撃
    override this.attribute = 0//属性
    override this.power = -20
    override this.accuracy = 100
    override this.costMp = 0
    override this.tergetStatus = ( false, true, false, false, false )
    override this.setSList a = a.hp > 0 && a.id = this.p.id

//コマンド選択
let selectCmd (a:Actor) =
    function
    |0  -> Sleep(a) :> BaseCmd
    |1  -> Attack01(a) :> BaseCmd
    |2  -> Attack02(a) :> BaseCmd
    |3  -> Attack03(a) :> BaseCmd
    |4  -> Attack04(a) :> BaseCmd
    |5  -> Attack05(a) :> BaseCmd
    |6  -> Attack06(a) :> BaseCmd
    |7  -> Attack07(a) :> BaseCmd
    |8  -> Attack08(a) :> BaseCmd
    |9  -> Attack09(a) :> BaseCmd
    |10 -> Attack10(a) :> BaseCmd
    |11 -> Attack11(a) :> BaseCmd
    |12 -> Attack12(a) :> BaseCmd
    |13 -> Magic01(a) :> BaseCmd
    |14 -> Magic02(a) :> BaseCmd
    |15 -> Magic03(a) :> BaseCmd
    |16 -> Magic04(a) :> BaseCmd
    |17 -> Magic05(a) :> BaseCmd
    |18 -> Magic06(a) :> BaseCmd
    |19 -> Magic07(a) :> BaseCmd
    |20 -> Magic08(a) :> BaseCmd
    |21 -> Magic09(a) :> BaseCmd
    |22 -> Magic10(a) :> BaseCmd
    |23 -> Magic11(a) :> BaseCmd
    |24 -> Magic12(a) :> BaseCmd
    |25 -> Magic13(a) :> BaseCmd
    |26 -> Magic14(a) :> BaseCmd
    |27 -> Magic15(a) :> BaseCmd
    |28 -> Magic16(a) :> BaseCmd
    |29 -> Magic17(a) :> BaseCmd
    |30 -> Magic18(a) :> BaseCmd
    |31 -> Magic19(a) :> BaseCmd
    |32 -> Magic20(a) :> BaseCmd
    |33 -> Magic21(a) :> BaseCmd
    |34 -> Magic22(a) :> BaseCmd
    |35 -> Magic23(a) :> BaseCmd
    |36 -> Magic24(a) :> BaseCmd
    |37 -> Magic25(a) :> BaseCmd
    |38 -> Magic26(a) :> BaseCmd
    |39 -> Magic27(a) :> BaseCmd
    |40 -> Magic28(a) :> BaseCmd
    |41 -> Magic29(a) :> BaseCmd
    |42 -> Magic30(a) :> BaseCmd
    |43 -> Magic31(a) :> BaseCmd
    |44 -> MagicSub01(a) :> BaseCmd
    |45 -> MagicSub02(a) :> BaseCmd
    |46 -> MagicSub03(a) :> BaseCmd
    |47 -> MagicSub04(a) :> BaseCmd
    |48 -> MagicSub05(a) :> BaseCmd
    |49 -> MagicSub06(a) :> BaseCmd
    |50 -> Sleep(a) :> BaseCmd
    |51 -> MagicSub07(a) :> BaseCmd
    |52 -> MagicSub08(a) :> BaseCmd
    |53 -> MagicSub09(a) :> BaseCmd
    |54 -> MagicSub10(a) :> BaseCmd
    |55 -> MagicSub11(a) :> BaseCmd
    |_ -> Sleep(a) :> BaseCmd