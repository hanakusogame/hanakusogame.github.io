﻿//コマンド管理モジュール
module CmdManager
open Command
open Actor

//コマンド管理クラス
type CmdManager() =
    //編集中のコマンド
    let mutable _nowCmd:BaseCmd = selectCmd actHoge 0

    let mutable cmdList:BaseCmd list = []

    let mutable cnt = -1

    //ゲッターセッター
    member this.list with get() = cmdList and set i = cmdList <- i
    member this.nowCmd with get() = _nowCmd and set i = _nowCmd <- i
    
    //追加
    member this.add(i) = cmdList <- i :: cmdList
    
    //初期処理（並べ替え)
    member this.init() =
        cmdList <-
            cmdList |>
            List.sortBy(fun i -> i.order) |>
            List.rev

    //終了処理
    member this.finish() =
        //終了したものははじく
        cmdList <-
            cmdList |>
            List.filter (fun i -> not(i.endFlg) )

    //次のコマンドを実行
    member this.runNext mb =
        //初期処理
        if cnt = -1 then this.init()
        
        let mutable flg = false
        while not flg do
            cnt <- cnt+1
            if cnt < cmdList.Length then
                this.nowCmd <- cmdList.[cnt]
                if this.nowCmd.p.hp > 0 then
                    flg <- this.nowCmd.run mb //実行
            //全部終わったら
            else
                //終了したものははじく
                this.finish()
                cnt <- -1
                flg <- true
        
        //全部終了時trueを返す
        if cnt = -1 then true else false

    //全コマンド実行
    member this.runAll mb =
        //全コマンド実行
        List.iter(fun (i:BaseCmd) -> i.run mb |> ignore) cmdList

        //終了したものははじく
        this.finish()

let cmdMng = new CmdManager()