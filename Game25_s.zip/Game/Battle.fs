﻿//バトルシーン用
module Battle

open System
open System.Drawing
open System.Windows.Forms
open System.Collections.Generic
open MyGraphics; open MyInput; open MyParts
open Actor; open Command; open CmdManager
open State

//コマンド選択クラス
type GetCommand(sb:SelectBox, mb:MesBox, am:ActorManager, cm:CmdManager) =

    let mutable cmdList = []
    let mutable initFlg = false

    let init () =
        let a = am.p.Value
        //コマンドリストを作る(最後に待機を追加)
        //cmdList <- [for i in a.cmdList -> selectCmd a i ] @ [ selectCmd a 0 ]
        let maxIndex = a.cmdList.Length
        cmdList <- [for i in 0 .. 3 -> selectCmd a (a.cmdList.[rnd.Next(0,maxIndex)]) ] @ [ selectCmd a 0 ]

    let main () =

        //コマンド選択肢設定
        sb.list <- [ for i in 0 .. cmdList.Length-1 -> cmdList.[i].name ]

        //選択肢から選ぶ
        match sb.update() with
        | -1->
            match sb.chkFocus() with
            | -1 -> ()
            |  a ->
                //フォーカス位置の情報
                mb.str <-cmdList.[a].info
                am.sList <- List.filter( cmdList.[a].setSList ) am.aList
            0
        | c ->
            cm.nowCmd <- cmdList.[c]
            1

    member this.setInit() = initFlg <-false

    member this.run() =
        if initFlg = false then init() ; initFlg <- true
        main()

//ターゲット選択クラス(どうあがいてもややこしい)
type GetTerget(sb:SelectBox, mb:MesBox, am:ActorManager, cm:CmdManager) =
    let mutable initFlg = false
    let mutable sList = []

    //リスト取得と選択肢作成
    let init() =
        let cmd = cm.nowCmd
        if cmd.runChk(mb) then
            //選択するかどうか
            if cmd.singleFlg then
                //フィルタをかけてからソート
                sList <- List.sortBy(fun i -> i.order)(List.filter( cmd.setSList ) am.aList)
                sb.list <- [ for i in sList -> i.name ] @ ["戻る"]
            else
                sList <- List.filter( cmd.setSList ) am.aList
                sb.list <- ["決定";"戻る"]
        else
            sb.list <- ["戻る"]
    
    //ターゲット設定
    let main() =
        let cmd = cm.nowCmd
        //選択する場合
        match sb.update() with
        | -1->
            match sb.chkFocus() with
            | -1 -> ()
            |  a ->
                if sb.list.[a].Str = "決定" then
                    mb.str <- ["決定！！"]
                elif sb.list.[a].Str = "戻る"then
                    ()
                else
                    mb.str <- [sList.[a].name]
                    am.sList <- [ sList.[a] ]

            0 //保留
        | a ->
            if sb.list.[a].Str = "決定" then
                cmd.sList <- sList
                cm.add(cmdMng.nowCmd)//コマンド登録
                1 //確定
            elif sb.list.[a].Str = "戻る"then
                2 //戻る
            else
                cmd.sList <- [ sList.[a] ]
                cm.add(cmdMng.nowCmd)//コマンド登録
                1 //確定

    member this.setInit() = initFlg <-false

    member this.run() =
        if initFlg = false then init() ; initFlg <- true
        main()

//コマンド実行クラス
type RunCommand(sb:SelectBox, mb:MesBox, am:ActorManager, cm:CmdManager) =
    let mutable state = 0
    let endChk() =
        //敵全滅
        if not(List.exists ( fun i -> i.id = 1 && i.hp > 0) am.aList) then 2
        //味方全滅
        elif not(List.exists ( fun i -> i.id = 0 && i.hp > 0) am.aList) then 3
        else 1

    let main() =
        if mPush(0) then
            if cm.runNext mb then
                match endChk() with
                //終了時
                | 1 ->
                    //死んでいるやつの並びを一番下にする
                    for j in 0 .. 1 do
                        List.filter ( fun i -> i.id = j) am.aList |>
                        List.sortBy(fun i -> if i.hp <=0 then 99 else i.order)|>
                        List.iteri (fun i a -> a.order <- i)

                    1
                //コマンドがまだ残っている
                | a -> a
            else
                am.p <- Some(cm.nowCmd.p)
                am.tList <- cm.nowCmd.mList//命中したリストを入れる
                state <- 1
                0
        else 0

    let mutable cnt = 0
    let wait() =
        if cnt < 5 then
            cnt <- cnt + 1
        else
            am.tList <- []
            cnt <- 0
            state <- 0
        
    member this.run() =
        match state with
        | 0 -> main()
        | 1 -> wait() ; 0
        |_  -> 99//たぶん通らない

let lvUpIndex a =
    match a.lvUp with
    | 0 ->  80
    | 1 ->  90
    | 2 -> 100
    | 3 -> 110
    | 4 -> 120
    |_  -> 130

let lvUpVal i =
    match i with
    | 1 -> rnd.Next(0,2)
    | 2 -> rnd.Next(0,3)
    | 3 -> rnd.Next(1,3)
    | 4 -> rnd.Next(1,4)
    | 5 -> rnd.Next(2,4)
    |_  -> 0


let setExpI a i = a.exp <- i * i * lvUpIndex(a) / 100
let setExp a = setExpI a a.lv

let lvUpChk a = a.exp > (a.lv+1)*(a.lv+1)*lvUpIndex(a)/100

//パラメータを基準値に戻す
let prmInit a =
    a.hp <- a.hpMax
    a.mp <- a.mpMax
    a.at <- a.atBase
    a.df <- a.dfBase
    a.sp <- a.spBase

//レベルアップ時に技を覚える
let levelUpCmd a =
        List.exists(
            fun (lv,c) ->
                if a.lv = lv then
                    a.cmdList <- c :: a.cmdList
                    true
                else
                    false
            )a.lvUpCmdList 

//レベルアップ処理
let levelUp a =
        a.lv <- a.lv + 1
        a.hpMax  <- a.hpMax  + lvUpVal(a.lvUpHp) + 1
        a.mpMax  <- a.mpMax  + lvUpVal(a.lvUpMp)
        a.atBase <- a.atBase + lvUpVal(a.lvUpAt)
        a.dfBase <- a.dfBase + lvUpVal(a.lvUpDf)
        a.spBase <- a.spBase + lvUpVal(a.lvUpSp)
        a.gExp <- a.gExp + lvUpVal(a.lvUp)
        a.gGold <- a.gGold + rnd.Next(1,3)
        levelUpCmd a

//第二引数で指定されたレベルまで上げる
let levelUpI a i =
        while a.lv < i do
            levelUp a |> ignore
        setExp a
        prmInit a

//レベルアップクラス
type LevelUp(sb:SelectBox, mb:MesBox, am:ActorManager, cm:CmdManager) =
    let mutable pl:Actor list = []
    let mutable initFlg = false
    let mutable state = 0
    let mutable strList:string list = [] 


    //初期処理
    let init () =
        strList <- []

        let expSum =
            List.filter (fun i -> i.id = 1)am.aList |>
            List.sumBy (fun i -> i.gExp)

        let goldSum =
            List.filter (fun i -> i.id = 1)am.aList |>
            List.sumBy (fun i -> i.gGold)
        
        //プレイヤーのリスト取得
        pl <- List.filter(fun i -> i.id = 0 && i.hp > 0) am.aList

        //経験値追加
        List.iter(fun i -> if i.hp > 0 then i.exp <- (i.exp + expSum) )pl

        am.gold <- am.gold + goldSum
        
        mb.str <- [
            "勝利した!!"
            "経験値 " + expSum.ToString() + " を手に入れた。"
            "お金 " + goldSum.ToString() + " を手に入れた。"
        ]

       
        List.iter(fun a ->
            while lvUpChk(a) do
                let flg = levelUp(a)

                let mutable str = (a.name + " は lv" + a.lv.ToString() + "になった!")

                if flg then
                    str <- str + "技を覚えた！"

                strList <- strList @ [str]
        )pl

    //実行
    member this.run() =

        if initFlg = false then init() ; initFlg <- true

        if mPush(0) then
            if strList.Length > 0 then
                mb.str <- [ strList.Head ]
                strList <- strList.Tail
                0
            else
                initFlg <- false
                1
        else
            0
    
type Battle (sBox:SelectBox,mBox:MesBox) =
    let mutable pList:Actor list = []

    let getCmd = new GetCommand(sBox,mBox,actMng,cmdMng)
    let getTar = new GetTerget(sBox,mBox,actMng,cmdMng)
    let runCmd = new RunCommand(sBox,mBox,actMng,cmdMng)
    let lvUp = new LevelUp(sBox,mBox,actMng,cmdMng)

    let mutable eListList = [1;2;3;4;5]

    //敵のコマンド作成
    let enemyCmdSet() =
        List.filter( fun i -> i.id = 1 && i.hp > 0 ) actMng.aList |>
        List.iter(fun a ->
            let cl = [ for i in 0 .. 3 -> selectCmd a ( a.cmdList.[ rnd.Next(0,a.cmdList.Length) ] ) ]

            let c_op = List.tryPick(fun (a:BaseCmd) -> if a.runChk(mBox) then Some(a) else None )cl
            let c =
                match c_op with
                |None -> selectCmd a 0
                |Some(a) -> a

            //対象設定
            c.sList <- List.filter( c.setSList ) actMng.aList
            if c.sList.Length > 0 then
                if c.singleFlg then
                    
                    //適当に選択
                    c.sList <- [ c.sList.[ rnd.Next(0,c.sList.Length) ] ]
                
                cmdMng.add(c)//コマンド登録
        )
        mBox.str <- ["ターン開始"]

    let mutable state = 0//現在の状態
    let mutable aCnt = 0//選択
    let mutable next = 0
    let mutable initFlg = false

    //初期処理
    let init () =
        next <- 0
        state <- 0
        cmdMng.list <- []
        initFlg <- true

    //更新処理
    member this.update() =
        if initFlg = false then init()
        match state with
        //ターン開始処理
        | 0 ->
            pList <-
                List.filter( fun i -> i.id = 0 && i.hp > 0 ) actMng.aList |>
                List.sortBy( fun a -> a.order )
            
            aCnt <- 0
            actMng.p <- Some(pList.[aCnt])

            mBox.clear()
            state <- 1

        //コマンド取得
        | 1 -> 
            match getCmd.run() with
            |1 -> getTar.setInit() ; state <- 2
            |_ -> ()
    
        //対象設定
        | 2 ->
            match getTar.run() with
            |1 -> state <- 3 ; getCmd.setInit()
            |2 -> state <- 1
            |_ -> ()
    
        //次へ
        | 3 ->
            if aCnt+1 < pList.Length then
                aCnt <- aCnt + 1
                actMng.p <- Some(pList.[aCnt])
                state <- 1
            else
                actMng.sList <- []
                state <- 4
    
        //敵の行動設定
        | 4 ->
            sBox.list <- []
            enemyCmdSet()
            state <- 5

        //コマンド実行処理
        |5 ->
            match runCmd.run() with
            | 1 -> state <- 0 //コマンド設定に戻る
            | 2 -> state <-  8 //勝利
            | 3 -> mBox.str <- ["全滅した。お金が半分になった"] ; state <-  9 //全滅
            |_  -> ()//待機状態

        //レベルアップ処理
        |8 ->
            match lvUp.run() with
            | 1 -> state <- 10
            |_  -> ()

        |9 ->
            if mPush(0) then
                actMng.gold <- actMng.gold/2
                mBox.str <- []
                initFlg <- false
                next <- 2

        |10 ->
            mBox.str <- []
            initFlg <- false
            next <- 1

        |_ ->mBox.add("エラー")

        ////////////描画処理///////////////

        //行動対象の名前表示
        setColor(Color.White)
        dStr 220 0 pList.[aCnt].name

        //
        setColor(Color.Red) ; dStrS 5 3 "ENEMY"
        setColor(Color.Cyan); dStrS 110 3 "PLAYER"

        //Actor情報表示
        actMng.alldraw(actMng.aList)

        //コマンド情報表示
        if state = 5 then
            List.iteri(fun i (c:BaseCmd) ->
                setColor( if c = cmdMng.nowCmd then Color.Red else Color.Gray)
                dStrS 210 (i*10+20) (c.p.name + ":" + c.name)
            )cmdMng.list

        next