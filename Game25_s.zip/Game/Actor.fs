﻿//登場人物の情報
module Actor
open System
open System.Drawing
open MyGraphics

let mutable rnd = new Random()

//登場人物レコード
[<Serializable>]
type Actor =
    {
        mutable id:int //敵か味方かの判別に使おう
        mutable name:string
        mutable attr:int //属性
        mutable order:int //位置
        mutable lv:int
        mutable hp:int
        mutable hpMax:int
        mutable mp:int
        mutable mpMax:int
        mutable at:int
        mutable df:int
        mutable sp:int

        mutable gExp :int
        mutable gGold:int

        mutable atBase:int
        mutable dfBase:int
        mutable spBase:int

        mutable lvUp:int
        mutable lvUpHp:int
        mutable lvUpMp:int
        mutable lvUpAt:int
        mutable lvUpDf:int
        mutable lvUpSp:int
        mutable lvUpCmdList:(int * int) list

        mutable exp:int
        mutable cmdList:int list
    }
    member this.strAttr() =
       match this.attr with
       | 0 ->"無"
       | 1 ->"火"
       | 2 ->"氷"
       | 3 ->"雷"
       |_  ->""

//Actor管理クラス（だんだん関係ないものが・・・）
type ActorManager () =

    //コマンドの実行者用Actor
    let mutable _aListBase:Actor list = []//すべてのActorの基礎となるリスト

    let mutable _gold = 0//お金！！！

    let mutable _pList:Actor list = []//プレイヤー用

    let mutable _p:Actor Option = None 
    let mutable _aList:Actor list = []//戦闘画面に表示するActorのリスト
    let mutable _sList:Actor list = []

    let mutable _tList:Actor list = []

    let mutable cnt = 0

    member this.aListBase with get() = _aListBase and set i = _aListBase <- i
    member this.gold with get() = _gold and set i = _gold <- i

    member this.p with get() = _p and set i = _p <- i
    member this.aList with get() = _aList and set i = _aList <- i
    member this.sList with get() = _sList and set i = _sList <- i
    member this.pList with get() = _pList and set i = _pList <- i

    member this.tList with get() = _tList and set i = _tList <- i  

    //Actor作成
    member this.create (id,name,attr,order,lv,hp,mp,at,df,sp,gExp,gGold,lvUp,lvUpHp,lvUpMp,lvUpAt,lvUpDf,lvUpSp,lvUpCmdList,exp,cmdList) =
        {
            id = id
            name = name
            attr = attr
            order = order
            lv = lv

            hp = hp ; hpMax = hp
            mp = mp ; mpMax = mp
            at = at ; atBase = at
            df = df ; dfBase = df
            sp = sp ; spBase = sp

            gExp = gExp
            gGold= gGold

            lvUp = lvUp
            lvUpHp = lvUpHp
            lvUpMp = lvUpMp
            lvUpAt = lvUpAt
            lvUpDf = lvUpDf
            lvUpSp = lvUpSp
            lvUpCmdList = lvUpCmdList

            exp = exp
            cmdList = cmdList
        }

    //Actorコピー?
    member this.copy (a:Actor) = {a with id = a.id}

    //仮Actor作成
    member this.createHoge () = this.create(0,"ほげ",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,[],0,[0])

    //描画
    member this.draw x y a =
        
        let pflg =
            match _p with
            |None -> false
            |Some(b) -> a = b

        let tflg = List.exists(fun i -> i = a)this.sList

        //背景色を設定
        setColor(
            //生きているとき
            if a.hp > 0 then
                //攻撃されているとき
                if List.exists(fun i -> i = a)this.tList && rnd.Next(2) = 0 then
                    Color.Red
                //それ以外
                else
                    match a.attr with
                    | 1 -> Color.DarkMagenta
                    | 2 -> Color.DarkBlue
                    | 3 -> Color.SaddleBrown
                    |_  -> Color.DimGray
            //死んでいるとき
            else
                Color.Black
        )

        fRect x y 100 55 //背景

        setColor(
            if a.hp > 0 then
                if tflg then Color.Yellow
                elif pflg then Color.Cyan
                else Color.Gray
            else Color.Gray
        )
        dRect x y 100 55 //外枠

    
        //ＨＰ
        setColor(Color.Yellow) ; fRect (x + 15) (y + 23) 80 5
        setColor(Color.Black)  ; fRect (x + 15) (y + 23) (80-(a.hp*80/a.hpMax)) 5
        setColor(Color.Gray)   ; dRect (x + 15) (y + 23) 80 5

        //MP
        setColor(if a.hp <= 0 then Color.Black else Color.Cyan)
        fRect (x + 15) (y + 38) 80 5
        setColor(Color.Black)  ; fRect (x + 15) (y + 38) (80-(a.mp*80/a.mpMax)) 5
        setColor(Color.Gray)   ; dRect (x + 15) (y + 38) 80 5

        //文字列
        setColor(
            if a.hp > 0 then
                Color.White
            else
                Color.Gray
        )

        dStrSD (x) ( y + (10 * 0) + 3 ) ( a.name + " Lv:" ) a.lv //名前とレベル
        if a.hp > 0 then
            dStrS (5 + x) ( y + 13) ("HP:" + a.hp.ToString() + "/" + a.hpMax.ToString())
        else
            dStrS (5 + x) ( y + 13 ) ("HP:死亡")
        dStrS  (5 + x) ( y + (12 * 2) + 5 ) ("MP:" + a.mp.ToString() + "/" + a.mpMax.ToString())
        
        let color i j =
            if a.hp > 0 then
               if i > j then Color.Yellow
               elif i < j then Color.Red
               else Color.White 
            else
                Color.Gray

        setColor(color (a.at) (a.atBase))
        dStrSD (1 + x + 0) ( y + 44 ) "攻" a.at

        setColor(color (a.df) (a.dfBase))
        dStrSD (5 + x + 28)( y + 44 ) "守" a.df

        setColor(color (a.sp) (a.spBase))
        dStrSD (5 + x + 62)( y + 44 ) "速" a.sp


    //情報全表示
    member this.alldraw(abl:Actor list)=
        cnt <- cnt + 1;
        for i in 0 .. abl.Length - 1 do
            let a = abl.[i]
            let x = if a.id = 0 then 110 else 5
            let y = a.order * 58 + 15
            this.draw x y a

let actMng = new ActorManager()
let actHoge = actMng.create(0,"ほげ",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,[],0,[0])