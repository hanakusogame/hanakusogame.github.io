﻿using Game36;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

//シーンのビジュアル部分
namespace Game36 {
    //ラベル(長すぎる)
    public class SceneLabel : Label {
        public Scene sc;
        public TimeLine c;
        public List<Scene> sl;

        public Image image = new Image();

        public SceneLabel(Scene sc, TimeLine c, List<Scene> sl) {
            this.sc = sc;
            this.c = c;
            this.Content = sc;
            this.sl = sl;
            this.Background = Brushes.Lime;
            this.Width = (sc.end - sc.start) * c.scale;
            Canvas.SetLeft(this, (sc.start * c.scale));
            Canvas.SetTop(this, (sc.y));

            RenderTargetBitmap rtb = new RenderTargetBitmap(sc.sw, sc.sh, 96, 96, PixelFormats.Default);
            image.Source = rtb;
            image.RenderTransformOrigin = new Point(0.5, 0.5);//中心点の移動
            
            this.MouseLeftButtonDown += mark0_MouseLeftButtonDown;
            this.MouseLeftButtonUp += mark0_MouseLeftButtonUp;
            this.MouseMove += mark0_MouseMove;
        }

        private void printPos(UIElement el) {
            int x = (int)Canvas.GetLeft(el);
            int y = (int)Canvas.GetTop(el);
            this.Content = sc.ToString();
            //this.Content = string.Format("x:{0} y:{1}", x, y);
        }

        private void setWidth(double w) {
            if (w > 0) {
                this.Width = w;
            }
        }

        private bool _isDrag = false;
        private int _mode = 0;
        private Point _dragOffset;


        // ドラッグ開始
        private void mark0_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            _isDrag = true;
            _dragOffset = e.GetPosition(this);
            if (_dragOffset.X < 5) _mode = 1;
            else if (_dragOffset.X > this.Width - 5) _mode = 2;
            else _mode = 0;
            this.CaptureMouse();
        }

        // ドラッグ終了
        private void mark0_MouseLeftButtonUp(object sender, MouseButtonEventArgs e) {
            if (_isDrag == true) {
                UIElement el = sender as UIElement;
                el.ReleaseMouseCapture();
                _isDrag = false;
                sc.start = (Canvas.GetLeft(el)) / c.scale;
                sc.end = sc.start + this.Width / c.scale;
                sc.y = (Canvas.GetTop(el));
            }
        }

        // ドラック中
        private void mark0_MouseMove(object sender, MouseEventArgs e) {
            if (_isDrag == true) {
                Point pt = Mouse.GetPosition(c);
                //移動
                if (_mode == 0) {
                    double x = pt.X - _dragOffset.X;
                    Scene bk_s;

                    //---y軸の補正---//
                    if (pt.Y - _dragOffset.Y > 0) Canvas.SetTop(this, pt.Y - _dragOffset.Y);
                    else Canvas.SetTop(this, 0);

                    //0より小さい
                    if (x < 0) {
                        Canvas.SetLeft(this, 0);
                        return;
                    }

                    //開始位置と近い開始位置がある
                    bk_s = sl.Find(s => s != sc && ((s.start * c.scale) + 10 > x) && ((s.start * c.scale) - 10 < x));
                    if (bk_s != null) {
                        Canvas.SetLeft(this, bk_s.start * c.scale);
                        return;
                    }

                    //開始位置と近い終了位置がある
                    bk_s = sl.Find(s => s != sc && ((s.end * c.scale) + 10 > x) && ((s.end * c.scale) - 10 < x));
                    if (bk_s != null) {
                        Canvas.SetLeft(this, bk_s.end * c.scale);
                        return;
                    }

                    double xx = x + this.Width;
                    //終了位置と近い開始位置がある
                    bk_s = sl.Find(s => s != sc && ((s.start * c.scale) + 10 > xx) && ((s.start * c.scale) - 10 < xx));
                    if (bk_s != null) {
                        Canvas.SetLeft(this, (bk_s.start * c.scale) - this.Width);
                        return;
                    }

                    //終了位置と近い終了位置がある
                    bk_s = sl.Find(s => s != sc && ((s.end * c.scale) + 10 > xx) && ((s.end * c.scale) - 10 < xx));
                    if (bk_s != null) {
                        Canvas.SetLeft(this, bk_s.end * c.scale - this.Width);
                        return;
                    }

                    Canvas.SetLeft(this, x);
                }

                //開始位置移動
                if (_mode == 1) {
                    double d = Canvas.GetLeft(this);
                    if (pt.X - _dragOffset.X < 0) {
                        Canvas.SetLeft(this, 0);
                        setWidth(this.Width + d);
                        return;
                    }

                    double x = pt.X;
                    Scene bk_s;

                    //近い開始位置がある
                    bk_s = sl.Find(s => s != sc && ((s.start * c.scale) + 10 > x) && ((s.start * c.scale) - 10 < x));
                    if (bk_s != null) {
                        Canvas.SetLeft(this, bk_s.start * c.scale);
                        setWidth(this.Width + (d - bk_s.start * c.scale));
                        return;
                    }

                    //近い終了位置がある
                    bk_s = sl.Find(s => s != sc && ((s.end * c.scale) + 10 > x) && ((s.end * c.scale) - 10 < x));
                    if (bk_s != null) {
                        Canvas.SetLeft(this, bk_s.end * c.scale);
                        setWidth(this.Width + (d - bk_s.end * c.scale));
                        return;
                    }

                    //開始位置が終了位置を超えない場合
                    if (this.Width + d - x > 0) {
                        Canvas.SetLeft(this, x);
                        setWidth(this.Width + d - x);
                    }

                }

                //終了位置移動
                if (_mode == 2) {
                    double x = pt.X;
                    Scene bk_s;

                    //近い開始位置がある
                    bk_s = sl.Find(s => s != sc && ((s.start * c.scale) + 10 > x) && ((s.start * c.scale) - 10 < x));
                    if (bk_s != null) {
                        setWidth((bk_s.start * c.scale) - Canvas.GetLeft(this));
                        return;
                    }

                    //終了位置がある
                    bk_s = sl.Find(s => s != sc && ((s.end * c.scale) + 10 > x) && ((s.end * c.scale) - 10 < x));
                    if (bk_s != null) {
                        setWidth((bk_s.end * c.scale) - Canvas.GetLeft(this));
                        return;
                    }

                    if (Mouse.GetPosition(this).X > 0) {
                        setWidth(Mouse.GetPosition(this).X);
                        return;
                    }
                }
                UIElement el = sender as UIElement;
                sc.start = (Canvas.GetLeft(el)) / c.scale;
                sc.end = sc.start + this.Width / c.scale;
                sc.y = (Canvas.GetTop(el));

                printPos(this);

            }
        }
    }

    //キャンバス
    public class TimeLine:Canvas {
        public RenderTargetBitmap rtb;
        public SceneManager sm;
        public double startTime = 0;
        public double endTime = 10;
        public double nowTime = 0;
        public double scale = 30;
        public Line startLine = new Line();
        public Line endLine = new Line();
        public Line nowLine = new Line();
        public Canvas canvasBack = new Canvas();
        public Canvas canvasMain = new Canvas();
        public Canvas canvasView;
        public Rectangle rect = new Rectangle();

        public KeyFrameView kfv;
        public KeyFrameView2 kfv2;

        private DispatcherTimer dTimer = new DispatcherTimer(DispatcherPriority.Normal);
        private Stopwatch sw = new Stopwatch();

        private bool moveFlg = false;

        public int playmode = 0;//再生モード

        private SceneLabel crtSl;
        public double[] arr = new double[5];

        //
        private void updateLine(double d,Line l){
            l.X1 = d * scale;
            l.Y1 = 0;
            l.X2 = d * scale;
            l.Y2 = this.Height;
        }

        public void init() {
            canvasMain.Children.Clear();
            sm.list.ForEach(s => canvasMain.Children.Add(new SceneLabel(s, this, sm.list)));
            foreach(SceneLabel sl in canvasMain.Children){
                if (sl.sc == sm.crt) {
                    crtSl = sl;
                    sl.Background = Brushes.Red;
                }
            }
        }

        //更新というより読み込み
        public void update() {
            if (sm.crt == null) return;
            init();
            kfv.init(sm.crt.km, "rotate");
            kfv2.init(sm.crt.km);
        }

        //コンストラクタ
        public TimeLine(Canvas c,SceneManager sm) {
            this.sm = sm;
            this.Background = Brushes.White;
            this.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            this.Height = 75;
            this.Width = sm.time * scale;
            canvasView = c;
            rect.Stroke = Brushes.Red;
            endTime = sm.time;

            canvasBack.Background = Brushes.Black;
            canvasBack.Height = this.Height;
            canvasBack.Width = this.Width;
            canvasBack.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;

            rtb = new RenderTargetBitmap( sm.pw , sm.ph , 96 , 96 , PixelFormats.Default);

            startLine.Stroke = Brushes.Lime;
            endLine.Stroke = Brushes.Blue;
            nowLine.Stroke = Brushes.Red;

            updateLine(startTime, startLine);
            updateLine(  endTime, endLine  );
            updateLine(  nowTime, nowLine  );

            canvasBack.Children.Add(startLine);
            canvasBack.Children.Add(endLine);
            canvasBack.Children.Add(nowLine);

            this.Children.Add(canvasBack);
            this.Children.Add(canvasMain);

            dTimer.Interval = new TimeSpan(0,0,0,0,40);
            dTimer.Tick += dispatcherTimer_Tick;

            kfv = new KeyFrameView();
            kfv2 = new KeyFrameView2();

            this.MouseLeftButtonDown += TimeLine_MouseLeftButtonDown;
            this.MouseLeftButtonUp += TimeLine_MouseLeftButtonUp;
            this.MouseMove += canvasBack_MouseMove;
            this.MouseLeave += ((s, e) => moveFlg = false);
            this.MouseRightButtonDown += TimeLine_MouseRightButtonDown;
            return;
        }

        //プロジェクト全体の時間設定
        public void setTime(double t) {
            sm.time = t;
            this.Width = sm.time * scale;
            canvasBack.Width = this.Width;
            endTime = sm.time;
            updateLine(endTime, endLine);
        }



        //タイマーイベント
        void dispatcherTimer_Tick(object sender, EventArgs e) {
            if (playmode == 0) {
                if (sw.Elapsed.TotalSeconds > endTime) sw.Restart();
                setNowTime(sw.Elapsed.TotalSeconds);
            }
            else if (playmode == 1) {
                if (sw.Elapsed.TotalSeconds + sm.crt.start > sm.crt.end) sw.Restart();
                setNowTime(sw.Elapsed.TotalSeconds + sm.crt.start);
            }
        }

        public void setNowTime(double time) {
            nowTime = time;
            updateLine(nowTime, nowLine);
            canvasView.Children.Clear();
            foreach (SceneLabel sl in canvasMain.Children) {
                sl.image.Width = sl.sc.sw;
                sl.image.Height = sl.sc.sh;
                RenderTargetBitmap rtb = (RenderTargetBitmap)(sl.image.Source);
                sm.getImg2(rtb, sl.sc, nowTime);        
                canvasView.Children.Add(sl.image); 
                //マトリックス変換
                sl.image.RenderTransform = new MatrixTransform(sl.sc.km.getMatrix(nowTime));
            }
            arr = crtSl.sc.km.getPos(nowTime);
        }

        public void getBmp(RenderTargetBitmap rtb2,double time) {
            nowTime = time;
            updateLine(nowTime, nowLine);
            canvasView.Children.Clear();
            foreach (SceneLabel sl in canvasMain.Children) {
                sl.image.Width = sl.sc.sw;
                sl.image.Height = sl.sc.sh;
                RenderTargetBitmap rtb3 = (RenderTargetBitmap)(sl.image.Source);
                sm.getImg2(rtb3, sl.sc, nowTime);
                canvasView.Children.Add(sl.image);
                //マトリックス変換
                sl.image.RenderTransform = new MatrixTransform(sl.sc.km.getMatrix(nowTime));
                BitmapCache bc = new BitmapCache();
                
                rtb2.Render(sl.image);
            }
            arr = crtSl.sc.km.getPos(nowTime);
                
        }

        public void saveBmp() {

            updateLine(nowTime, nowLine);
            

            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(rtb));
            using (var stream = System.IO.File.Create("image.png")) {
                encoder.Save(stream);
            }
        }

        void canvasBack_MouseMove(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) {
                if (moveFlg) setNowTime(Mouse.GetPosition(this).X / scale);
                else setNowTime(nowTime);
                kfv.updateLine(nowTime);
                kfv2.updateLine(nowTime);
            }
        }

        void TimeLine_MouseRightButtonDown(object sender, MouseButtonEventArgs e) {
        }

        void TimeLine_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            SceneLabel sl = null;
            foreach (SceneLabel s in canvasMain.Children) {
                if (s.IsMouseOver) { sl = s; break; }
            }
            if (sl != null) {
                //選択シーン変更
                sm.crt = sl.sc;
                foreach (SceneLabel s in canvasMain.Children) {
                    if (s == sl) {
                        crtSl = sl;
                        s.Background = Brushes.Red;
                    }
                    else s.Background = Brushes.Lime;
                }
                moveFlg = false;
            }
            else {
                //現在地更新
                setNowTime(Mouse.GetPosition(this).X / scale);
                moveFlg = true;
            }
            //キーフレームビュー更新
            kfv.init(sm.crt.km);
            kfv.update();
            kfv2.update();
        }

        void TimeLine_MouseLeftButtonUp(object sender, MouseButtonEventArgs e) {
            sm.list.Sort((s1, s2) => (int)(s2.y - s1.y));
            
            kfv2.init(sm.crt.km);
            kfv.update();
            kfv2.update();
            init();
            moveFlg = false;
        }

        public void add() {sm.add(nowTime);update();}
        public void copy() {sm.copy(nowTime);update();}
        public void del() {sm.del();update();}

        public void move() {
        }

        public double bk_time;
        public void play() {
            if (dTimer.IsEnabled) {
                dTimer.Stop();
                sw.Stop();
            }
            else {
                bk_time = nowTime;
                dTimer.Start();
                sw.Start();
            }
        }

        public void setSize(int w, int h){
            this.sm.pw = w;
            this.sm.ph = h;
            rtb = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Default);
        }

        public void addKeyFrame(double val) {
            kfv.addKey(nowTime,val);
            kfv.update();
        }

        public void addKeyFrame2(double val,string t) {
            kfv2.addKey(nowTime, val,t);
            kfv2.update();
        }

        public void setKeyView() {
            kfv.init(sm.crt.km);
        }

        public void setKeyView(string type) {
            kfv.init(sm.crt.km,type);
        }

        public void updateKeyView(){
            kfv.update();
            kfv2.update();
        }

        public void setKeyView2() {
            kfv2.init(sm.crt.km);
            kfv2.update();
        }

        public void setRot(double val){
            if (crtSl != null) {
                arr[0] += val;
                Matrix m = crtSl.sc.km.createMatrix(nowTime - crtSl.sc.start, arr);
                crtSl.image.RenderTransform = new MatrixTransform(m);
            }
        }

        internal void setMove(double p1, double p2) {
            if (crtSl != null) {
                arr[1] += p1; arr[2] += p2;
                Matrix m = crtSl.sc.km.createMatrix(nowTime - crtSl.sc.start, arr);
                crtSl.image.RenderTransform = new MatrixTransform(m);
            }
        }

        internal void setScale(double p1, double p2) {
            if (crtSl != null) {
                arr[3] += (p1 * 0.01); arr[4] += (p2 * 0.01);
                Matrix m = crtSl.sc.km.createMatrix(nowTime - crtSl.sc.start, arr);
                crtSl.image.RenderTransform = new MatrixTransform(m);
            }
        }
    }
}
