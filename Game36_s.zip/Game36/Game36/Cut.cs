﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Game36 {
    //コマクラス
    [Serializable()]
    public class Cut {
        public double time = 0.5;
        public int baseId;
        public int id;
        public int linkId;

        public Cut(int bi, int i, int li,int sw, int sh) {
            baseId = bi;
            id = i;
            linkId = li;
        }

        public override string ToString() {
            //return "" + baseId + ":" + id + ":" + linkId + " [" + (time.ToString("00.00")) + "]";
            return "" + (id+1) + ": [" + (time.ToString("00.00")) + "]";
        }
    }

    //コマ表示用パネルクラス
    public class CutPanel : StackPanel {
        public Cut c;
        public TextBox tb;
        public CutPanel(Cut c,SceneManager sm,LayerManager lm) {
            this.c = c;

            Grid g = new Grid();
            Image img = new Image();
            tb = new TextBox();
            RenderTargetBitmap rtb = new RenderTargetBitmap(sm.pw, sm.ph, 96, 96, PixelFormats.Default);
            RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);
            g.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            g.Background = Brushes.White;
            img.Width = 64;
            img.Height = 48;
            lm.createImage(rtb, c.linkId);
            img.Source = rtb;
            g.Children.Add(img);
            //tb.Width = 100;
            tb.TextChanged += tb_TextChanged;
            tb.Text = c.time.ToString("00.00");
            this.Children.Add(g);
            this.Children.Add(tb);
        }

        void tb_TextChanged(object sender, TextChangedEventArgs e) {
            double d;
            if(double.TryParse(tb.Text,out d)){
                c.time = d;
            }
        }
    }

    //コマ管理クラス
    [Serializable()]
    public class CutManager {
        public List<Cut> list { get; set; }
        public Cut crt {get; set;}//現在地
        public SceneManager sm;
        public LayerManager lm;

        //コンストラクタ
        public CutManager(LayerManager lm) {
            list = new List<Cut>();
            this.lm = lm;
        }

        //パネル作成
        public CutPanel createPanel(Cut c) {
            return new CutPanel(c, sm, lm);
        }

        //id作成
        private int createId(int baseId){
            List<Cut> bk_list = list.FindAll(i => i.baseId == baseId);
            int id = 0;
            while (bk_list.Exists(i => i.id == id)) id++;
            return id;
        }

        //追加
        public void add() { add(crt.baseId,sm.pw,sm.ph); }
        public void add(int baseId,int sw,int sh) {
            int id = 0;
            while (list.Exists(i => i.linkId == id)) id++;
            list.Add(crt = new Cut(baseId, createId(baseId), id, sm.crt.sw, sm.crt.sh));
            lm.add(crt.linkId);
        }

        //コピー
        public void copy() { copy(crt.baseId); }
        public void copy(int baseId) {
            List<Layer> bk_LList = lm.list.FindAll(l => crt.linkId == l.baseId);
            int id = 0;
            while (list.Exists(i => i.linkId == id)) id++;
            list.Add(crt = new Cut(baseId, createId(baseId), id, sm.crt.sw, sm.crt.sh));

            foreach (Layer l in bk_LList) {
                lm.crt = l;
                lm.copy(id);
            }
        }

        //カレント削除
        public void del() {
            List<Cut> bk_cl = list.FindAll(c => c.baseId == crt.baseId);
            if (bk_cl.Count() <= 1) return;
            lm.delAll(crt.linkId);//レイヤーを消す

            int i = bk_cl.FindIndex(c => c == crt);
            list.Remove(crt);
            if (i != 0) crt = bk_cl[i - 1];
            else crt = bk_cl[1];

            lm.crt = lm.list.Find(l => l.baseId == crt.linkId);
        }

        //全削除
        public void delAll(int baseId , int next){
            list.FindAll(i => i.baseId == baseId).ForEach(i => lm.delAll(i.linkId));
            list.RemoveAll(i => i.baseId == baseId);
            crt = list.Find(c => c.baseId == next);
            lm.crt = lm.list.Find(l => l.baseId == next);
        }

        //移動
        public void move(int pos) {
            List<Cut> bk_list = list.FindAll(c => c.baseId == crt.baseId);
            int i = bk_list.FindIndex(c => c == crt);
            if (i + pos >= bk_list.Count || i + pos < 0) return;
            bk_list.RemoveAt(i);
            bk_list.Insert(i + pos, crt);
            list.RemoveAll(c => c.baseId == crt.baseId);
            list.AddRange(bk_list);
        }

        //変更
        public void changeCrt(int i) {
            Cut cut = list.FindAll(c => c.baseId == crt.baseId)[i];
            crt = cut;
            lm.changeCrt(lm.list.Find(l => l.baseId == crt.linkId));
        }

        //画像取得(時間から)
        public void getImg(RenderTargetBitmap rtb,double baseId, double time) {
            List<Cut> bkList = list.FindAll(c => c.baseId == baseId);
            double time2 = time%(bkList.Sum(c => c.time));
            double cnt = 0;
            foreach (Cut c in bkList) {
                cnt += c.time;
                if (time2 < cnt) {
                    lm.createImage(rtb, c.linkId);
                    return;
                }
            }
        }

        //１コマ前の画像取得


        //取得
        public void setCanvas(Canvas canvas) {
            lm.setCanvas(canvas, sm.crt.sw, sm.crt.sh, crt.linkId);
        }
    }
}
