﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

//すべてのキーフレームを表示できるビュー
namespace Game36 {
    public class KeyFrameView2 : Canvas{

        //キーフレームの位置を表示するボタン風アイテム
        public class KeyThumb : Thumb {
            public KeyFrame kf;
            private double scale;
            public KeyThumb(KeyFrame kf, double scale ,int pos) {
                this.kf = kf;
                this.scale = scale;
                this.Height = 19;
                this.Width = 12;
                Canvas.SetLeft(this, (kf.pos * scale - 6));
                Canvas.SetTop(this, pos);
                this.DragDelta += KeyThumb_DragDelta;
                this.MouseRightButtonDown += KeyThumb_MouseRightButtonDown;
            }

            void KeyThumb_MouseRightButtonDown(object sender, MouseButtonEventArgs e) {
            }

            void KeyThumb_DragDelta(object sender, DragDeltaEventArgs e) {
                double d;
                d = Canvas.GetLeft(this) + e.HorizontalChange;
                kf.pos = ((d + 5) / scale);
                Canvas.SetLeft(this, d);
            }
        }

        public KeyManager km { get; set; }

        private List<KeyThumb> keyList = new List<KeyThumb>();

        public double scaleW = 100.0;
        private String type = null;
        public Line line = new Line();

        public KeyFrameView2() {
            line.Y1 = 0;
            line.Y2 = 100;
            line.Stroke = Brushes.Red;

            this.MouseMove += KeyFrameView_MouseMove;
            this.MouseLeftButtonDown += KeyFrameView2_MouseLeftButtonDown;
            this.MouseLeftButtonUp += KeyFrameView2_MouseLeftButtonUp;
            this.MouseRightButtonDown += KeyFrameView2_MouseRightButtonDown;
        }

        //初期処理？
        public void init(KeyManager km) {
            this.km = km;
            this.VerticalAlignment = System.Windows.VerticalAlignment.Top;
            this.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            this.Height = 100;
            this.Background = Brushes.Black;
        }

        void KeyFrameView2_MouseLeftButtonUp(object sender, MouseButtonEventArgs e) {
            type = null;
        }

        void KeyFrameView2_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            KeyThumb key = keyList.Find(k => k.IsMouseOver);
            if (key != null) type = key.kf.kc.type;
        }

        void KeyFrameView_MouseMove(object sender, System.Windows.Input.MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) {
                line.X1 = e.GetPosition(this).X;
                line.X2= e.GetPosition(this).X;
                //根本から並びかえているので注意
                if(type != null)
                    km.keyDict[type].list.Sort((k1, k2) => (int)((k1.pos - k2.pos) * 100));
            }
        }

        void KeyFrameView2_MouseRightButtonDown(object sender, MouseButtonEventArgs e) {
            KeyThumb kt = keyList.Find(t => t.IsMouseOver);
            if (kt != null) {
                km.keyDict[kt.kf.kc.type].list.Remove(kt.kf);
                keyList.Remove(kt);
            }
            update();
        }

        public void updateLine(double time){
            line.X1 = (time - km.scene.start) * scaleW;
            line.X2 = (time - km.scene.start) * scaleW;
        }

        //キーの追加
        public void addKey(double time, double val, string t) {
            km.keyDict[t].addKeyFrame(time, val);
        }

        //更新処理
        public void update() {
            this.Width = (km.scene.end - km.scene.start) * scaleW;
            this.Children.Clear();
            keyList.Clear();
            int cnt = 0;
            foreach (String key in km.keyDict.Keys) {
                Line l = new Line();
                l.Stroke = Brushes.Lime;
                l.X1 = 0; l.Y1 = 19 * cnt; l.X2 = Width; l.Y2 = 19 * cnt;
                this.Children.Add(l);
                foreach (KeyFrame k in km.keyDict[key].list) {
                    KeyThumb kt = new KeyThumb(k, scaleW, cnt*19);
                    keyList.Add(kt);
                    this.Children.Add(kt);
                }
                cnt++;
            }
            this.Children.Add(line);
        }

        public void setScaleW(double d) {
            scaleW = d * 100;
        }
    }
}
