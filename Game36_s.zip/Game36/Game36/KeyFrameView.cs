﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Game36 {

    //キーフレームの情報を表示するキャンバス
    public class KeyFrameView : Canvas {

        //キーフレームの位置を表示するボタン風アイテム
        public class KeyThumb : Thumb {
            public KeyFrame kf;
            private double scale;
            public KeyThumb(KeyFrame kf, double scale) {
                this.kf = kf;
                this.scale = scale;
                this.Height = 10;
                this.Width = 10;
                Canvas.SetLeft(this, (kf.pos * scale - 5));
                double d = (kf.val - kf.kc.min) * (100 / (kf.kc.max - kf.kc.min)) - 5;
                Canvas.SetTop(this, d);
                this.DragDelta += KeyThumb_DragDelta;
            }

            void KeyThumb_DragDelta(object sender, DragDeltaEventArgs e) {
                double d;
                d = Canvas.GetLeft(this) + e.HorizontalChange;
                kf.pos = ((d + 5) / scale);
                Canvas.SetLeft(this, d);

                d = Canvas.GetTop(this) + e.VerticalChange;
                kf.val = (d + 5) * ((kf.kc.max - kf.kc.min) / 100) + kf.kc.min;
                Console.WriteLine(kf.val);
                Canvas.SetTop(this, d);
            }
        }

        public KeyManager km { get; set; }

        private List<KeyThumb> keyList = new List<KeyThumb>();

        private string type = "rotate";
        public double scaleW = 100.0;
        private Polyline pl = new Polyline();
        public Line line = new Line();

        public KeyFrameView() {
            line.Y1 = 0;
            line.Y2 = 100;
            line.Stroke = Brushes.Red;

            this.MouseMove += KeyFrameView_MouseMove;
            this.MouseRightButtonDown +=KeyFrameView_MouseRightButtonDown;
        }

        //初期化
        public void init(KeyManager km) { init(km, type); }
        public void init(KeyManager km, string type) {
            this.type = type;
            this.km = km;
            this.VerticalAlignment = System.Windows.VerticalAlignment.Top;
            this.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            this.Height = 100;
            this.Background = Brushes.Black;
            this.Width = (km.scene.end - km.scene.start) * scaleW;
            pl.Stroke = Brushes.Red;
            update();
        }

        //更新
        public  void update() {
            this.Children.Clear();
            this.keyList.Clear();
            pl.Points.Clear();
            foreach (KeyFrame k in km.keyDict[type].list) {
                KeyThumb kt = new KeyThumb(k, scaleW);
                pl.Points.Add(new Point(scaleW * k.pos, (k.val-k.kc.min) * (100/(k.kc.max - k.kc.min))));
                this.Children.Add(kt);
                this.keyList.Add(kt);
            }
            this.Children.Add(pl);
            this.Children.Add(line);
        }

        //キーの追加
        public void addKey(double time,double val) {
            km.keyDict[type].addKeyFrame(time, val);
        }

        //キーの削除
        void KeyFrameView_MouseRightButtonDown(object sender, MouseButtonEventArgs e) {
            KeyThumb kt = keyList.Find(t => t.IsMouseOver);
            if (kt != null) {
                km.keyDict[kt.kf.kc.type].list.Remove(kt.kf);
                keyList.Remove(kt);
            }
            update();
        }

        void KeyFrameView_MouseMove(object sender, System.Windows.Input.MouseEventArgs e) {
            //いちいち線を作りなおす
            if (e.LeftButton == MouseButtonState.Pressed) {
                line.X1 = e.GetPosition(this).X;
                line.X2 = e.GetPosition(this).X;

                pl.Points.Clear();
                //根本から並びかえているので注意
                km.keyDict[type].list.Sort((k1, k2) => (int)((k1.pos - k2.pos) * 100));
                foreach (KeyFrame k in km.keyDict[type].list) {
                    pl.Points.Add(new Point(scaleW * k.pos, (k.val - k.kc.min) * (100 / (k.kc.max - k.kc.min))));
                }
            }
        }

        public void updateLine(double time) {
            line.X1 = (time - km.scene.start) * scaleW;
            line.X2 = (time - km.scene.start) * scaleW;
        }

        public void setScaleW(double d) {
            scaleW = d * 100;
        }
    }
}
