﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Game36 {

    //シーンクラス
    [Serializable()]
    public class Scene {
        public double start { get; set; }
        public double end { get; set; }
        public double y { get; set; }
        public int linkId { get; set; }
        public int id { get; set; }
        public int sw { get; set; }
        public int sh { get; set; }

        //マトリックス座標
        public KeyManager km { get; set; }

        public Scene(int i, int li,int w, int h,double s,double e) {
            km = new KeyManager(this);
            id = i;
            linkId = li;
            start = s;
            end = e;
            y = 0.0;
            sw = w;
            sh = h;
        }

        public override string ToString() {
            //return "" + id + ":" + linkId + ":[" + (start.ToString("00.00")) + "-" + ((start + time).ToString("00.00")) + "]";
            return "[" + (start.ToString("00.00")) + "-" + (end.ToString("00.00")) + "]";
        }
    }

    //シーン管理クラス
    [Serializable()]
    public class SceneManager {
        public List<Scene> list { get; set; }
        public Scene crt { get; set; }
        public CutManager cm;
        public double defaultLen = 3.0;
        public int pw = 320;
        public int ph = 240;
        public int bkColorIndex = 0;
        public double time = 5.0;

        public SceneManager(CutManager CM){
            cm = CM;
            list = new List<Scene>();
        }

        //追加
        public void add(double time) {
            int id = 0;
            while (list.Exists(i => i.id == id)) id++;
            list.Add(crt = new Scene(id, id, pw, ph, time, time+defaultLen));
            cm.add(crt.linkId, crt.sw, crt.sh);
        }

        //コピー
        public void copy(double time) {
            List<Cut> bk_cutList = cm.list.FindAll(tl => tl.baseId == crt.id);
            int id = 0;
            while (list.Exists(i => i.id == id)) id++;
            list.Add(crt = new Scene(id, id, crt.sh, crt.sw, time, time + crt.end - crt.start));
            foreach (Cut c in bk_cutList) {
                cm.crt = c;
                cm.copy(crt.linkId);
            }
        }

        //削除
        public void del() {
            if (list.Count <= 1) return;

            int bkId = crt.id;
            int i = list.FindIndex(tl => tl == crt);
            list.Remove(crt);//削除
            if (i != 0) crt = list[i - 1];
            else crt = list[0];//現在シーン設定
            cm.delAll(bkId, crt.id);//コマ削除

            cm.move(0);
        }

        //移動
        public void move(int pos) {
            int i = list.FindIndex(tl => tl == crt);
            if (i + pos >= list.Count || i + pos < 0) return;
            list.RemoveAt(i);
            list.Insert(i + pos, crt);
        }

        //変更
        public void changeCrt(Scene tl) {
            crt = tl;
            cm.crt = cm.list.Find(c => c.baseId == crt.linkId);
            cm.changeCrt(0);
        }

        //画像取得(時間の全部)
        public void getImg(RenderTargetBitmap rtb, double time) {
            rtb.Clear();
            foreach(Scene s in list){
                if(s.start <= time && s.end > time){
                    cm.getImg(rtb,s.linkId,(time - s.start));
                }
            }
        }

        //画像の取得
        public void getImg2(RenderTargetBitmap rtb,Scene s, double time) {
            rtb.Clear();
            if (s.start <= time && s.end > time) {
                cm.getImg(rtb, s.linkId, (time - s.start));
            }
        }
    }
}
