﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Game36 {
    //キーフレームクラス
    [Serializable()]
    public class KeyFrame {
        public KeyCollection kc;
        public double pos { get; set; }
        public double val { get; set; }
        public KeyFrame(double pos, double val, KeyCollection kc) {
            this.kc = kc;
            this.pos = pos;
            this.val = val;
        }
    }

    //キーフレームのコレクションクラス
    [Serializable()]
    public class KeyCollection {
        public Scene scene;
        public List<KeyFrame> list { get; set; }
        public double defVal;
        public double min;
        public double max;
        public string type;

        public KeyCollection(Scene scene,string type, double defVal,double min, double max) {
            this.type = type;
            this.scene = scene;
            this.defVal = defVal;
            this.min = min;
            this.max = max;
            list = new List<KeyFrame>();
        }

        //マトリックスの取得
        public double getValTime(double time) {
            double t = time - scene.start;
            KeyFrame bk_k = new KeyFrame(0, 0,this);
            double y = defVal;
            int cnt = 0;
            foreach (KeyFrame kf in list) {
                if (t < kf.pos) {
                    //線形補完
                    if (cnt != 0) {
                        y = bk_k.val + (kf.val - bk_k.val) * (t - bk_k.pos) / (kf.pos - bk_k.pos);
                    }
                    else{
                        y = kf.val;
                    }
                    break;
                }
                bk_k = kf;
                y = kf.val;
                cnt++;
            }
            return y;
        }

        //キーフレームを打つ
        public void addKeyFrame(double time, double val) {
            if (time >= scene.start && time < scene.end) {
                double t = time - scene.start;
                list.Remove(list.Find(k => k.pos == t));
                list.Add(new KeyFrame(t, val,this));
                list.Sort((x, y) => (int)((x.pos - y.pos)*100));
                list.ForEach(x => Console.WriteLine("" + x.pos + " " + x.val));
            }
        }
    }

    //キー管理クラス
    [Serializable()]
    public class KeyManager{
        public Scene scene;
        public Dictionary<string, KeyCollection> keyDict;

        public KeyManager(Scene scene) {
            this.scene = scene;
            keyDict = new Dictionary<string, KeyCollection>();
            keyDict.Add("rotate"    , new KeyCollection(scene,"rotate"    , 0.0, -360 , 360 ));
            keyDict.Add("TranslateX", new KeyCollection(scene, "TranslateX", 0.0, -200, 200));
            keyDict.Add("TranslateY", new KeyCollection(scene, "TranslateY", 0.0, -200, 200));
            keyDict.Add("scaleX"    , new KeyCollection(scene,"scaleX"    , 1.0, 0.0  , 2.0 ));
            keyDict.Add("scaleY"    , new KeyCollection(scene,"scaleY"    , 1.0, 0.0  , 2.0 ));
        }

        public double[] getPos(double time) {
            double[] arr= new double[5];
            arr[0] = keyDict["rotate"].getValTime(time);
            arr[1] = keyDict["TranslateX"].getValTime(time);
            arr[2] = keyDict["TranslateY"].getValTime(time);
            arr[3] = keyDict["scaleX"].getValTime(time);
            arr[4] = keyDict["scaleY"].getValTime(time);
            return arr;
        }

        public Matrix getMatrix(double time) {
            Matrix m = new Matrix();
            double r, mx, my, sx, sy;
            mx = keyDict["TranslateX"].getValTime(time);
            my = keyDict["TranslateY"].getValTime(time);
            sx = keyDict["scaleX"].getValTime(time);
            sy = keyDict["scaleY"].getValTime(time);
            r = keyDict["rotate"].getValTime(time);
            m.Scale(sx, sy);
            m.Rotate(r);
            m.Translate(mx,my);

            return m;
        }

        public Matrix createMatrix(double time,double[] arr) {
            Matrix m = new Matrix();
            m.Scale(arr[3], arr[4]);
            m.Rotate(arr[0]);
            m.Translate(arr[1], arr[2]);
            return m;
        }
    }
}
