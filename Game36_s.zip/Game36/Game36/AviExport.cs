﻿using AForge.Video.VFW;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using D = System.Drawing;

namespace Game36 {
    class AviExport {
        TimeLine tl;
        RenderTargetBitmap rtb;
        DrawingVisual dv = new DrawingVisual();
        AVIWriter aviWriter;
        double endtime;
        double nowtime;
        public bool flg = false;

        //レンダリング
        public void render() {
            if (nowtime < endtime) {
                rtb.Clear();
                rtb.Render(dv);
                tl.getBmp(rtb, nowtime);
                D.Bitmap b = B.Convert(BitmapFrame.Create(rtb));
                aviWriter.AddFrame(b);
                nowtime += (1.0 / 25.0);
            }
            else {
                aviWriter.Close();
                flg = false;
            }
        }

        //ＡＶＩファイル出力開始
        public void start(TimeLine tl) {
            this.tl = tl;
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            dlg.FileName = "NewFile.avi"; // Default file name
            dlg.DefaultExt = ".avi"; // Default file extension
            dlg.Filter = "AVI Files (.avi)|*.avi"; // Filter files by extension
            if (dlg.ShowDialog() == true) {
                // 描画先を作成
                DrawingContext dc = dv.RenderOpen();
                rtb = new RenderTargetBitmap(tl.sm.pw, tl.sm.ph, 96, 96, PixelFormats.Default);
                endtime = tl.sm.time;
                nowtime = 0.0;

                // 描画エリア(dc)に四角形を作成
                Rect rectBounds = new Rect(0, 0, 320, 240);
                if (tl.sm.bkColorIndex == 0) dc.DrawRectangle(Brushes.White, null, rectBounds);
                if (tl.sm.bkColorIndex == 1) dc.DrawRectangle(Brushes.Black, null, rectBounds);
                if (tl.sm.bkColorIndex == 2) dc.DrawRectangle(Brushes.Navy, null, rectBounds);
                
                dc.Close();

                //我ながら理解不能
                double d = tl.sm.time;
                aviWriter = new AVIWriter();
                aviWriter.Open( dlg.FileName, tl.sm.pw, tl.sm.ph );
                flg = true;
            }
            //AviAndWave("test.avi", "test1.avi", "test.wav");
        }
    }
}
