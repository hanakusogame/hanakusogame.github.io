﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Game36 {
    //レイヤークラス
    [Serializable()]
    public class Layer {
        [NonSerialized()]
        public StrokeCollection sc = new StrokeCollection();

        public bool visible = true;
        public int alpha = 100;
        public int baseId;
        public int id;

        private MemoryStream ms;

        public Layer() { }
        public Layer(int bID , int ID) {
            baseId = bID;
            id = ID;
        }

        //ストロークをメモリストリーム形式に変換
        public void save() {
            ms = new MemoryStream();
            sc.Save(ms);
        }

        //メモリストリームをストロークに変換
        public void load() {
            ms.Position = 0;
            sc = new StrokeCollection(ms);
            ms.Dispose();
        }

        public override string ToString() {
            string s;
            if (visible) s = "■";
            else s = "□";
            return s + id + ":[" + alpha + "]";
            //return "" + baseId + ":" + id + ":" + visible;
        }
    }

    //レイヤー管理クラス
    [Serializable()]
    public class LayerManager {
        public List<Layer> list { get; set; }
        public Layer crt { get; set; }

        [NonSerialized()]
        public InkCanvas ic;

        public LayerManager() {
            list = new List<Layer>();
            inkCvsInit();
        }

        public void inkCvsInit(){
            ic = new InkCanvas();
            ic.Background = null;
            ic.DefaultDrawingAttributes.FitToCurve = true;
        }

        private int createID(int baseId) {
            List<Layer> bk_list = list.FindAll(i => i.baseId == baseId);
            int id = 0;
            while (bk_list.Exists(i => i.id == id)) id++;
            return id;
        }

        //追加
        public void add() { add(crt.baseId); }
        public void add(int baseId) {
            crt = new Layer( baseId , createID(baseId) );
            list.Add(crt);
        }

        //コピー
        public void copy() { copy(crt.baseId); }
        public void copy(int baseId) {
            Layer bk_layer = crt;
            crt = new Layer(baseId , createID(baseId) );
            list.Add(crt);
            crt.sc = bk_layer.sc.Clone();
        }

        //カレント削除
        public void del() {
            if (list.FindAll(l => l.baseId == crt.baseId).Count() <= 1) return;
            list.Remove(crt);
            crt = list.Find(l => l.baseId == crt.baseId);
        }

        //全部削除(現在地が行方不明になるので注意)
        public void delAll(int baseId) {
            list.RemoveAll(i => i.baseId == baseId);
        }

        //移動
        public void move(int pos) {
            List<Layer> bk_list = list.FindAll(la => la.baseId == crt.baseId);
            int i = bk_list.FindIndex(la => la == crt);
            if (i + pos >= bk_list.Count || i + pos < 0) return;
            bk_list.RemoveAt(i);
            bk_list.Insert(i + pos, crt);
            list.RemoveAll(la => la.baseId == crt.baseId);
            list.AddRange(bk_list);
        }

        //変更
        public void changeCrt(Layer layer) {
            crt = layer;
        }

        //DrawingVisual生成test
        public DrawingVisual createDV(Layer layer) {
            // 描画先を作成
            DrawingVisual dv = new DrawingVisual();
            DrawingContext dc = dv.RenderOpen();
            layer.sc.Draw(dc);
            dc.Close();
            dv.Opacity = layer.alpha / 100.0;
            return dv;
        }

        //DrawingGroup生成test(失敗)
        public DrawingGroup createDG(Layer layer) {
            // 描画先を作成
            Rectangle rect = new Rectangle();
            DrawingGroup dg = new DrawingGroup();
            DrawingContext dc = dg.Open();
            dc.DrawRectangle(Brushes.Red, null, new Rect(0, 0, 320, 240));
            layer.sc.Draw(dc);
            dc.Close();
            dg.Opacity = layer.alpha / 100.0;
            return dg;
        }

        //画像生成(対象コマの全レイヤー適合)
        public void createImage(RenderTargetBitmap rtb, int baseId) {
            // 上記で作成した描画エリア(dc)にInkCanvasのストロークを描画
            list.FindAll(la => la.baseId == baseId)
                .ForEach(la => rtb.Render(createDV(la)));
        }

        //キャンバスにレイヤー作成;
        public void setCanvas(Canvas c, int w,int h, int baseId) {
            c.Width = w; c.Height = h;
            c.Children.Clear();
            // 上記で作成した描画エリア(dc)にInkCanvasのストロークを描画
            List<Layer> bk_list = list.FindAll(la => la.baseId == baseId);
            foreach (Layer l in bk_list){
                if (l != crt) {
                    RenderTargetBitmap rtb = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Default);
                    Image image = new Image();
                    image.Width = w; image.Height = h;
                    image.IsHitTestVisible = false;
                    if (l.visible == false)
                        image.Visibility = System.Windows.Visibility.Collapsed;
                    rtb.Render(createDV(l));
                    image.Source = rtb;
                    c.Children.Add(image);
                }
                else {
                    ic.Width = w; ic.Height = h;
                    ic.Strokes = l.sc;
                    ic.Opacity = l.alpha / 100.0;
                    if (l.visible == false)
                        ic.Visibility = System.Windows.Visibility.Collapsed;
                    else
                        ic.Visibility = System.Windows.Visibility.Visible;
                    c.Children.Add(ic);

                }
            }
        }
    }
}
