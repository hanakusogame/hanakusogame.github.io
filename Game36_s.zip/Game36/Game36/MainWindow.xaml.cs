﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using D = System.Drawing;

using AForge.Video.VFW;

using System.Runtime.InteropServices;
using System.Windows.Ink;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Microsoft.Win32;
using System.Reflection;
using System.Windows.Controls.Primitives;

namespace Game36 {

    //ウィンドウクラス
    public partial class MainWindow : Window {
        private LayerManager lm;
        private CutManager cm;
        private SceneManager sm;
        private TimeLine tl;
        private AviExport ae;
        private int mode = 0;

        //オニオンスキン用背景関連
        RenderTargetBitmap backImage = new RenderTargetBitmap(320, 240, 96, 96, PixelFormats.Default);
        bool backImageFlg = false;

        InkCanvas crtIk = new InkCanvas();
        private string fileName;

        private int keyViewMode = 0;

        bool chgIventEscFlg = false;//リスボックス変更時のイベントを避けるためのフラグ

        //[DllImport("AviWave.dll", CallingConvention = CallingConvention.Cdecl)]
        //static extern void AviAndWave(string a, string b, string c);

        //メインウィンドウ
        public MainWindow() {
            InitializeComponent();
            init();
            image1.Source = backImage;
            ae = new AviExport();
            CompositionTarget.Rendering += CompositionTarget_Rendering; ;
        }

        void CompositionTarget_Rendering(object sender, EventArgs e) {
            if (ae.flg == true) {
                ae.render();
            }
        }

        //初期化処理
        private void init() {

            lm = new LayerManager();
            cm = new CutManager(lm);
            sm = new SceneManager(cm);
            cm.sm = sm;
            tl = new TimeLine(canvasView,sm);
            image2.Source = tl.rtb;
            scrollViewKey.Content = tl.kfv;
            scrollViewKey2.Content = tl.kfv2;
            scrollviewer.Content = tl;
            fileName = "";
            this.Title = "アニメ制作ツール2";
            modeChange(0);
            canvasColor2.Visibility = System.Windows.Visibility.Collapsed;
            tl.add(); update();
            tl.update();
            lm.ic.StrokeCollected += ic_StrokeCollected;
            initCanvas();
        }

        private void initCanvas() {
            canvas1.Width = sm.pw;
            canvas1.Height = sm.ph;
            image2.Width = sm.pw;
            image2.Height = sm.ph;
            image2.Source = tl.rtb;
            canvasPlayer.Width = sm.pw;
            canvasPlayer.Height = sm.ph;

            if (sm.bkColorIndex == 0) canvas1.Background = Brushes.White;
            if (sm.bkColorIndex == 1) canvas1.Background = Brushes.Black;
            if (sm.bkColorIndex == 2) canvas1.Background = Brushes.Navy;

            scrollviewer.Content = tl;
            scrollViewKey.Content = tl.kfv;
            scrollViewKey2.Content = tl.kfv2;
        }

        void ic_StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e) {
            update();
        }

        //モード変更
        private void modeChange(int i) {
            mode = i;
            //タイムラインモード
            if (mode == 0) {
                panelPaint.Visibility = Visibility.Collapsed;
                gridCut.Visibility = Visibility.Collapsed;
                gridTimeLine.Visibility = Visibility.Visible;
                canvasPaintBase.Visibility = Visibility.Collapsed;
                canvasPlayer.Visibility = Visibility.Visible;
                if(keyViewMode == 1) gridKeyFrame.Visibility = Visibility.Visible;
                else gridKeyFrame.Visibility = Visibility.Collapsed;
                if(keyViewMode == 2) GridKeyFrame2.Visibility = Visibility.Visible;
                else GridKeyFrame2.Visibility = Visibility.Collapsed;
                gridProject.Visibility = Visibility.Collapsed;
                canvas1.Width = sm.pw;
                canvas1.Height = sm.ph;
                tl.update();
            }
            //ペイントモード
            if (mode == 1) {
                panelPaint.Visibility = Visibility.Visible;
                gridCut.Visibility = Visibility.Visible;
                gridTimeLine.Visibility = Visibility.Collapsed;
                canvasPaintBase.Visibility = Visibility.Visible;
                canvasPlayer.Visibility = Visibility.Collapsed;
                gridKeyFrame.Visibility = Visibility.Collapsed;
                GridKeyFrame2.Visibility = Visibility.Collapsed;
                gridProject.Visibility = Visibility.Collapsed;
                canvas1.Width = sm.crt.sw;
                canvas1.Height = sm.crt.sh;
            }
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e) {
            modeChange(0);
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e) {
            modeChange(1);
        }

        public void updateCut() {
            List<Cut> lc = cm.list.FindAll(cut => cut.baseId == sm.crt.linkId);
            if (cm.crt.baseId != sm.crt.linkId) cm.crt = cm.list.Find(c => c.baseId == sm.crt.linkId);
            listboxCut.Items.Clear();
            int cnt = 0;
            foreach(Cut c in lc){
                listboxCut.Items.Add(cm.createPanel(c));
                if (cm.crt == c)
                    listboxCut.SelectedIndex = cnt;
                cnt++;
            }
        }

        public void updateLayer() {
            LabelLyaerCnt.Content = lm.list.Count;
            LabelTLCnt.Content = sm.list.Count;

            List<Layer> bkLList = lm.list.FindAll(layer => layer.baseId == cm.crt.linkId);
            if (lm.crt.baseId != cm.crt.linkId) lm.crt = lm.list.Find(l => l.baseId == cm.crt.linkId);
            listboxLayer.ItemsSource = bkLList;
            listboxLayer.SelectedValue = lm.crt;

            canvasPaintBase.Width = sm.crt.sw;
            canvasPaintBase.Height = sm.crt.sh;
            cm.setCanvas(canvas2);
        }

        public void update() {
            chgIventEscFlg = true;
            updateCut();
            updateLayer();
            backImageUpdate();
            chgIventEscFlg = false;
        }


        //ファイル入出力系
        //新規作成
        private void buttonFileNew_Click(object sender, RoutedEventArgs e) {
            init();
        }

        //開く
        private void buttonFileOpen_Click(object sender, RoutedEventArgs e) {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory; 
            dlg.DefaultExt = ".anime"; // Default file extension
            dlg.Filter = "Anime Files (.anime)|*.anime"; // Filter files by extension
            if (dlg.ShowDialog() == true)
            {
                FileStream fs = new FileStream(dlg.FileName, FileMode.Open, FileAccess.Read);
                BinaryFormatter f = new BinaryFormatter();
                //読み込んで逆シリアル化する
                sm = (SceneManager)f.Deserialize(fs);
                cm = sm.cm;
                InkCanvas bkic = lm.ic;
                lm = cm.lm;
                lm.list.ForEach(i => i.load());
                lm.ic = bkic;
                
                tl = new TimeLine(canvasView, sm);

                initCanvas();
                
                tl.update();
                fs.Close();

                fileName = dlg.FileName;
                this.Title = fileName;
                update();
            }
        }

        //保存処理のみ
        private void save(string path) {
            lm.list.ForEach(i => i.save());
            FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            //シリアル化して書き込む
            bf.Serialize(fs, sm);
            fs.Close();
        }

        //ダイアログから保存
        private void saveNew() {
            // Configure save file dialog box
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            dlg.FileName = "NewFile.anime"; // Default file name
            dlg.DefaultExt = ".anime"; // Default file extension
            dlg.Filter = "Anime Files (.anime)|*.anime"; // Filter files by extension

            if (dlg.ShowDialog() == true) {
                save(dlg.FileName);
                fileName = dlg.FileName;
            }
        }

        //別名保存
        private void buttonFileSaveNew_Click(object sender, RoutedEventArgs e) {
            saveNew();
        }

        //保存
        private void buttonFileSave_Click(object sender, RoutedEventArgs e) {
            if (fileName != "") { save(fileName); }
            else { saveNew(); }
        }

        //ＡＶＩファイル出力
        private void buttonSaveAvi_Click(object sender, RoutedEventArgs e) {
            ae.start(tl);
            //AviAndWave("test.avi", "test1.avi", "test.wav");
        }

        //-----描画モードやブラシ系-----//
        //編集モード
        private void buttonModePen_Click(object sender, RoutedEventArgs e) {
            labelMode.Content = "ペン";
            lm.ic.EditingMode = InkCanvasEditingMode.Ink;
        }

        private void buttonModeErase_Click(object sender, RoutedEventArgs e) {
            labelMode.Content = "消ゴム";
            lm.ic.EditingMode = InkCanvasEditingMode.EraseByPoint;
        }

        private void buttonModeSelect_Click(object sender, RoutedEventArgs e) {
            labelMode.Content = "選択";
            lm.ic.EditingMode = InkCanvasEditingMode.Select;
        }

        private void buttonModeEraseByStroke_Click(object sender, RoutedEventArgs e) {
            labelMode.Content = "線消し";
            lm.ic.EditingMode = InkCanvasEditingMode.EraseByStroke;
        }

        //マウスカーソル変更
        private void comboCursor_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (lm == null) return;
            if (comboCursor.SelectedIndex == 0)
                lm.ic.UseCustomCursor = false;
            else
                lm.ic.UseCustomCursor = true;
        }

        //色設定(ﾊﾟﾚｯﾄ)
        private void buttonColor_Click(object sender, RoutedEventArgs e) {
            SolidColorBrush b = (SolidColorBrush)((Button)e.Source).Background;
            SolidColorBrush f = (SolidColorBrush)((Button)e.Source).Foreground;
            labelColor.Background = b;
            labelColor.Foreground = f;
            labelColor.Content = ((Button)e.Source).Name.Substring(6);
            lm.ic.DefaultDrawingAttributes.Color = b.Color;
        }
        //色変更スライダー変更
        private void sliderARGB_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            labelA.Content = sliderA.Value;
            labelR.Content = sliderR.Value;
            labelG.Content = sliderG.Value;
            labelB.Content = sliderB.Value;
            Color penColor =
                Color.FromArgb(
                Convert.ToByte(sliderA.Value),
                Convert.ToByte(sliderR.Value),
                Convert.ToByte(sliderG.Value),
                Convert.ToByte(sliderB.Value)
                );
            labelColor2.Background = new SolidColorBrush(penColor);
            lm.ic.DefaultDrawingAttributes.Color = penColor;
        }

        private void buttonRgb_Click(object sender, RoutedEventArgs e) {
            Color c = ((SolidColorBrush)labelColor.Background).Color;
            sliderA.Value = c.A;
            sliderR.Value = c.R;
            sliderG.Value = c.G;
            sliderB.Value = c.B;
            canvasColor1.Visibility = System.Windows.Visibility.Collapsed;
            canvasColor2.Visibility = System.Windows.Visibility.Visible;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) {
            canvasColor1.Visibility = System.Windows.Visibility.Visible;
            canvasColor2.Visibility = System.Windows.Visibility.Collapsed;
        }

        //太さ変更
        private void sliderSize_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            if (labelSize == null) return;
            labelSize.Content = sliderSize.Value;
            lm.ic.DefaultDrawingAttributes.Width = sliderSize.Value;
            lm.ic.DefaultDrawingAttributes.Height = sliderSize.Value;
        }

        //なめらか線
        private void chkBox1_Click(object sender, RoutedEventArgs e) {
            if (chkBox1.IsChecked.Value) lm.ic.DefaultDrawingAttributes.FitToCurve = true;
            else lm.ic.DefaultDrawingAttributes.FitToCurve = false;
        }

        //背景変更処理
        private void backImageUpdate() {
            if (backImageFlg) {
                backImage.Clear();
                List<Cut> cl = cm.list.FindAll(c => c.baseId == cm.crt.baseId);
                int i = cl.FindIndex(c => c == cm.crt);
                if (i != 0) {
                    Cut j = cm.list.Find(c => c == cl[i-1]);
                    lm.createImage(backImage, j.linkId);
                }
            }
        }

        //背景変更可否変更
        private void btn1_Click(object sender, RoutedEventArgs e) {
            backImageFlg = !backImageFlg;
            if (backImageFlg) {
                backImageUpdate();
            }
            else {
                backImage.Clear();
            }
        }

        //-----プロジェクト関連-----//
        private void buttonSetSize_Click(object sender, RoutedEventArgs e) {
            int w, h;
            TimeSpan t;
            if (int.TryParse(textBoxSizeW.Text, out w) &&
                int.TryParse(textBoxSizeH.Text, out h) &&
                TimeSpan.TryParse("00:" + textboxPlayerLen.Text, out t)
                ) {
                tl.setSize(w, h);
                tl.setTime(t.TotalSeconds);

                if (comboBgCorlor.SelectedIndex == 0) canvas1.Background = Brushes.White;
                if (comboBgCorlor.SelectedIndex == 1) canvas1.Background = Brushes.Black;
                if (comboBgCorlor.SelectedIndex == 2) canvas1.Background = Brushes.Navy;
                //image2.Source = tl.rtb;
                canvas1.Width = w;
                canvas1.Height = h;
                image2.Width = w;
                image2.Height = h;
                canvasPlayer.Width = w;
                canvasPlayer.Height = h;
            }
            gridProject.Visibility = Visibility.Collapsed;
        }

        private void buttonCancelProject_Click(object sender, RoutedEventArgs e) {
            gridProject.Visibility = Visibility.Collapsed;
        }


        //-----シーン関連-----//
        //追加
        private void buttonTLAdd_Click(object sender, RoutedEventArgs e) { tl.add(); }

        //コピー
        private void buttonTLCopy_Click(object sender, RoutedEventArgs e) { tl.copy(); }

        //削除
        private void buttonTLDel_Click(object sender, RoutedEventArgs e) { tl.del(); }

        //変更
        private void listboxTL_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (e.AddedItems.Count == 0 || chgIventEscFlg) return;
            sm.changeCrt((Scene)e.AddedItems[0]);
            update();
        }

        //現在のシーンの開始時間変更
        private void textboxTLStart_TextChanged(object sender, TextChangedEventArgs e) {
            if (sm == null) return;
            double num;
            if (double.TryParse(textboxTLStart.Text, out num)) {
                sm.crt.start = num;
            }
        }

        //現在のシーンの時間変更
        private void textboxTLTime_TextChanged(object sender, TextChangedEventArgs e) {
            if (sm == null) return;
            double num;
            if (double.TryParse(textboxTLTime.Text, out num)) {
                sm.crt.end = num;
            }
        }

        //現在のシーンの時間自動設定
        private void buttonTLAuto_Click(object sender, RoutedEventArgs e) {
            int num = sm.list.FindIndex(i => sm.crt.id == i.id);
            sm.crt.end =
                sm.crt.start + cm.list.FindAll(i => sm.crt.linkId == i.baseId).Sum(i => i.time);
            tl.update();
        }

        //サイズ変更
        private void buttonSceneSize_Click(object sender, RoutedEventArgs e) {
            int h, w;
            if (int.TryParse(textBoxSceneW.Text, out w) && int.TryParse(textBoxSceneH.Text, out h)) {
                sm.crt.sw = w;
                sm.crt.sh = h;
                canvas1.Width = w;
                canvas1.Height = h;
                updateCut();
            }
        }

        //再生モード変更
        private void ComboBox_SelectionChanged_2(object sender, SelectionChangedEventArgs e) {
            if (tl == null) return;
            tl.playmode = comboPlayMode.SelectedIndex;
        }

        //プロジェクト変更画面表示
        private void buttonProjectOpen_Click(object sender, RoutedEventArgs e) {
            if (gridProject.Visibility == System.Windows.Visibility.Visible) {
                gridProject.Visibility = System.Windows.Visibility.Collapsed;
            }
            else {
                gridProject.Visibility = System.Windows.Visibility.Visible;
            }
        }

        //-----コマ関連----//
        //追加
        private void buttonCutAdd_Click(object sender, RoutedEventArgs e) { cm.add(); update(); }

        //コピー
        private void buttonCutCopy_Click(object sender, RoutedEventArgs e) { cm.copy(); update(); }

        //削除
        private void buttonCutDel_Click(object sender, RoutedEventArgs e) { cm.del(); update(); }

        //変更
        private void listboxCut_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (e.AddedItems.Count == 0 || chgIventEscFlg) return;
            cm.changeCrt(listboxCut.SelectedIndex);
            update();
        }

        //移動
        private void buttonCutUp_Click(object sender, RoutedEventArgs e) { cm.move(-1); update(); }
        private void buttonCutDown_Click(object sender, RoutedEventArgs e) { cm.move(1); update(); }

        //現在のコマの時間全設定
        private void buttonCutSetAll_Click(object sender, RoutedEventArgs e) {
            if (cm == null) return;
            double num;
            if (double.TryParse(textboxCutTime.Text, out num)) {
                cm.list.FindAll(i => i.baseId == cm.crt.baseId).ForEach(i => i.time = num);
                update();
            }
        }


        //-----レイヤー関連-----//
        //追加
        private void buttonLayerAdd_Click(object sender, RoutedEventArgs e) { lm.add(); update(); }

        //コピー
        private void buttonLayerCopy_Click(object sender, RoutedEventArgs e) { lm.copy(); update(); }

        //削除
        private void buttonLayerDel_Click(object sender, RoutedEventArgs e) { lm.del(); update(); }

        //変更
        private void listboxLayer_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (e.AddedItems.Count == 0 || chgIventEscFlg) return;
            lm.changeCrt((Layer)e.AddedItems[0]);
            update();
        }

        //移動
        private void buttonLayerUp_Click(object sender, RoutedEventArgs e) { lm.move(-1); update(); }
        private void buttonLayerDown_Click(object sender, RoutedEventArgs e) { lm.move(1); update(); }

        //表示非表示変更
        private void buttonLayerVisible_Click(object sender, RoutedEventArgs e) {
            if (lm == null) return;
            lm.crt.visible = !lm.crt.visible;
            listboxLayer.Items.Refresh();
            if (lm.crt.visible) lm.ic.Visibility = System.Windows.Visibility.Visible;
            else lm.ic.Visibility = System.Windows.Visibility.Hidden;
        }

        //現在のレイヤーの透明度設定
        private void sliderLayerAlpha_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            if (lm == null) return;
            lm.crt.alpha = (int)sliderLayerAlpha.Value;
            listboxLayer.Items.Refresh();
            labelLayerAlpha.Content = (int)sliderLayerAlpha.Value;
            crtIk.Opacity = sliderLayerAlpha.Value / 100.0;
        }

        //-----プレイヤー系の処理-----//

        //再生・停止ボタン
        private void buttonPlayerStart_Click(object sender, RoutedEventArgs e) {
            if ((string)(buttonPlayerStart.Content) == "再生") buttonPlayerStart.Content = "停止";
            else buttonPlayerStart.Content = "再生";
            tl.play();
        }

        //裏機能（モードを右クリックでキャンバスのカーソル変更）
        private void Label_MouseRightButtonDown_1(object sender, MouseButtonEventArgs e) {
            crtIk.UseCustomCursor = !crtIk.UseCustomCursor;
        }

        private void Window_KeyDown_1(object sender, KeyEventArgs e) {
            if (e.Key == Key.Tab) {
                if (mode == 0){
                    update();
                    modeChange(1);
                }
                else modeChange(0);
            }
        }


        private void buttonBmp_Click(object sender, RoutedEventArgs e) {
            tl.saveBmp();
        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e) {
            if (tl != null) {
                if (comboKeyType.SelectedIndex == 0) {
                    tl.setKeyView("rotate");
                }
                else if (comboKeyType.SelectedIndex == 3) {
                    tl.setKeyView("scaleX");
                }
                else if (comboKeyType.SelectedIndex == 4) {
                    tl.setKeyView("scaleY");
                }
                else if (comboKeyType.SelectedIndex == 1) {
                    tl.setKeyView("TranslateX");
                }
                else if (comboKeyType.SelectedIndex == 2) {
                    tl.setKeyView("TranslateY");
                }
            }
        }

        //キーフレームビューの表示切替
        private void btnKeyViewChange_Click(object sender, RoutedEventArgs e) {
            if (keyViewMode == 0) keyViewMode = 1;
            else if (keyViewMode == 1) keyViewMode = 2;
            else if (keyViewMode == 2) keyViewMode = 0;
            tl.updateKeyView();
            modeChange(0);
        }

        //---------キーフレーム設定関連-----------
        //キーフレーム追加
        private void btnAddKey_Click(object sender, RoutedEventArgs e) {
            double d;
            if (double.TryParse(textboxKey2.Text, out d)) {
                tl.addKeyFrame(d);
            }
        }

        private double bkVal1, bkVal2;


        private void rot(double p) {
            tl.setRot(p - bkVal1);
            bkVal1 = p;
            textboxUpdate();
        }

        private void move(double p1, double p2) {
            tl.setMove(p1 - bkVal1, p2 - bkVal2);
            bkVal1 = p1;
            bkVal2 = p2;
            textboxUpdate();
        }

        private void scale(double p1, double p2) {
            tl.setScale(p1 - bkVal1, p2 - bkVal2);
            bkVal1 = p1;
            bkVal2 = p2;
            textboxUpdate();
        }

        //画像の移動等用のピボット
        private void thumb_DragStarted(object sender, DragStartedEventArgs e) {
            ((Thumb)sender).Background = Brushes.Red;
            bkVal1 = 0; bkVal2 = 0;
        }

        private void thumbRot_DragDelta(object sender, DragDeltaEventArgs e) {
            rot(e.HorizontalChange);
        }

        private void thumbMove_DragDelta(object sender, DragDeltaEventArgs e) {
            move(e.HorizontalChange, e.VerticalChange);
        }

        private void thumbScale_DragDelta(object sender, DragDeltaEventArgs e) {
            scale(e.HorizontalChange, e.HorizontalChange);
        }

        private void thumb_DragCompleted(object sender, DragCompletedEventArgs e) {
            ((Thumb)sender).Background = Brushes.Lime;
        }

        private void btnKeyRot_Click(object sender, RoutedEventArgs e) {
            double d;
            if (double.TryParse(textBoxKeyRot.Text, out d)) {
                tl.addKeyFrame2(d,"rotate");
            }
        }

        private void btnKeyMoveX_Click(object sender, RoutedEventArgs e) {
            double d;
            if (double.TryParse(textBoxKeyMoveX.Text, out d)) {
                tl.addKeyFrame2(d, "TranslateX");
            }
        }

        private void btnKeyMoveY_Click(object sender, RoutedEventArgs e) {
            double d;
            if (double.TryParse(textBoxKeyMoveY.Text, out d)) {
                tl.addKeyFrame2(d, "TranslateY");
            }
        }

        private void btnKeyScaleX_Click(object sender, RoutedEventArgs e) {
            double d;
            if (double.TryParse(textBoxKeyScaleX.Text, out d)) {
                tl.addKeyFrame2(d, "scaleX");
            }
        }

        private void btnKeyScaleY_Click(object sender, RoutedEventArgs e) {
            double d;
            if (double.TryParse(textBoxKeyScaleY.Text, out d)) {
                tl.addKeyFrame2(d, "scaleY");
            }
        }

        private void btnKeyMove_Click(object sender, RoutedEventArgs e) {
            double d;
            if (double.TryParse(textBoxKeyMoveX.Text, out d)) {
                tl.addKeyFrame2(d, "TranslateX");
            }
            if (double.TryParse(textBoxKeyMoveY.Text, out d)) {
                tl.addKeyFrame2(d, "TranslateY");
            }
        }

        private void btnKeyScale_Click(object sender, RoutedEventArgs e) {
            double d;
            if (double.TryParse(textBoxKeyScaleX.Text, out d)) {
                tl.addKeyFrame2(d, "scaleX");
            }
            if (double.TryParse(textBoxKeyScaleY.Text, out d)) {
                tl.addKeyFrame2(d, "scaleY");
            }
        }

        private void textboxUpdate(){
            textBoxKeyRot.Text = "" + tl.arr[0];
            textBoxKeyMoveX.Text = "" + tl.arr[1];
            textBoxKeyMoveY.Text = "" + tl.arr[2];
            textBoxKeyScaleX.Text = "" + tl.arr[3];
            textBoxKeyScaleY.Text = "" + tl.arr[4];
            textboxKey2.Text = "" + tl.arr[comboKeyType.SelectedIndex];
            labelPlayTime.Content = "" + tl.nowTime.ToString("00.00");
        }

        private void scrollviewer_MouseMove(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) {
                textboxUpdate();
            }
        }

        private void Thumb_DragDelta_1(object sender, DragDeltaEventArgs e) {
            int i = comboKeyType.SelectedIndex;
            if (i == 0) rot(e.HorizontalChange);
            if (i == 1) move(e.HorizontalChange,0);
            if (i == 2) move(0,e.VerticalChange);
            if (i == 3) scale(e.HorizontalChange,0);
            if (i == 4) scale(0,e.VerticalChange);
        }

        private void sliderScaleW2_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            if (tl == null) return;
            tl.kfv2.setScaleW(sliderScaleW2.Value);
            tl.kfv2.init(tl.sm.crt.km);
            tl.kfv2.update();
        }

        private void sliderScaleW_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            if (tl == null) return;
            tl.kfv.setScaleW(sliderScaleW.Value);
            tl.kfv.init(tl.sm.crt.km);
            tl.kfv.update();
        }

        private void scrollViewKey2_MouseMove(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) {
                double t = tl.kfv2.line.X1 / tl.kfv2.scaleW + tl.kfv2.km.scene.start;
                tl.setNowTime(t);
                textboxUpdate();
            }
        }

        private void scrollViewKey_MouseMove(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) {
                double t = tl.kfv.line.X1 / tl.kfv.scaleW + tl.kfv.km.scene.start;
                tl.setNowTime(t);
                textboxUpdate();
            }
        }
    }
}