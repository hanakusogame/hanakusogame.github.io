﻿//入力関連モジュール(キーボード、マウス)
module MyInput

open System.Windows.Forms
open System.Drawing
open MyForm

//キーボード入力イベント取得
let noneKeyEvent = new KeyEventArgs(Keys.None)
let mutable keyEvent = new KeyEventArgs(Keys.None)
form.KeyDown.Add(fun mi -> keyEvent <- mi)
form.KeyUp.Add(fun mi -> keyEvent <- noneKeyEvent)

//------キーボード情報-------
let mutable nowKey = keyEvent
let mutable bkKey = keyEvent
let setKey() =
    bkKey <- nowKey
    nowKey <- keyEvent

let kPush k = bkKey.KeyCode <> k && nowKey.KeyCode = k
let kDown k = nowKey.KeyCode = k
let kUp k = bkKey.KeyCode = k && nowKey.KeyCode <> k

//-------マウス情報----------
let mutable bkMouse = MouseButtons.None
let mutable nowMouse = MouseButtons.None
let setMouse() =
    bkMouse <- nowMouse
    nowMouse <- Control.MouseButtons

let mPush =
    function
    |0 -> (bkMouse &&& MouseButtons.Left) <> MouseButtons.Left && (nowMouse &&& MouseButtons.Left) = MouseButtons.Left
    |1 -> (bkMouse &&& MouseButtons.Right) <> MouseButtons.Right && (nowMouse &&& MouseButtons.Right) = MouseButtons.Right
    |2 -> (bkMouse &&& MouseButtons.Middle) <> MouseButtons.Middle && (nowMouse &&& MouseButtons.Middle) = MouseButtons.Middle
    |_ -> false

let mDown =
    function
    |0 -> (nowMouse &&& MouseButtons.Left) = MouseButtons.Left
    |1 -> (nowMouse &&& MouseButtons.Right) = MouseButtons.Right
    |2 -> (nowMouse &&& MouseButtons.Middle) = MouseButtons.Middle
    |_ -> false

let mUp =
    function
    |0 -> (bkMouse &&& MouseButtons.Left) = MouseButtons.Left && (nowMouse &&& MouseButtons.Left) <> MouseButtons.Left
    |1 -> (bkMouse &&& MouseButtons.Right) = MouseButtons.Right && (nowMouse &&& MouseButtons.Right) <> MouseButtons.Right
    |2 -> (bkMouse &&& MouseButtons.Middle) = MouseButtons.Middle && (nowMouse &&& MouseButtons.Middle) <> MouseButtons.Middle
    |_ -> false

let mPos() = form.PointToClient(System.Windows.Forms.Cursor.Position)