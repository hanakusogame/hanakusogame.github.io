﻿//ゲームのメインの処理
module Main

open System.Drawing
open MyGraphics; open MyInput

let mutable p = new Point(80,220)
let mutable b = new Point(108,210)
let mutable sp = 2
let mutable mx,my = -sp,-sp
let mutable mFlg = false
let mutable sFlg = false
let mutable score = 0
let mutable status = 0
let arr = Array2D.create 7 6 1
let update() =
    if sFlg then
        p.X <- mPos().X - 32
        if p.X < 0 then p.X <- 0
        if p.X > 160 then p.X <- 160

        if mFlg then

            if b.X + mx < 0   then mx <- sp  ; b.X <- 0
            if b.X + mx > 208 then mx <- -sp ; b.X <- 207
            if b.Y + my < 0   then my <- sp  ; b.Y <- 0

            if b.Y + mx > 230 then
                sFlg <- false; status <- 2//死亡

            if (b.Y + my)/16 < 6 then
                if arr.[(b.X + mx)/32, (b.Y + my)/16] = 1 then
                    arr.[(b.X + mx)/32, (b.Y + my)/16] <- 0
                    score <- score + 10
                    if (b.X + mx)/32 > b.X/32 then mx <- -sp
                    if (b.X + mx)/32 < b.X/32 then mx <- +sp
                    if (b.Y + my)/32 > b.Y/32 then my <- -sp
                    if (b.Y + my)/32 < b.Y/32 then my <- +sp

            if b.X+8 > p.X && b.X+8 < p.X+64 && b.Y+8 > 220 then my <- -sp

            b.X <- b.X + mx; b.Y <- b.Y + my
            if mPush(0) then sp <- sp+1
            
            //全部消えているかどうかチェック
            let chk = ref false
            Array2D.iter(fun i -> if i = 1 then chk := true)arr
            if not(!chk) then sFlg <- false ; status <- 1//クリア
        else
            b.Y <- 210
            b.X <- p.X + 28
            if mPush(0) then mFlg <- true
    else
        if mPush(0) then
            sFlg <- true
            Array2D.iteri(fun x y i -> arr.[x,y] <- 1) arr
            sp <- 2 ; mx <- -sp; my <- -sp
            score <- 0 ; mFlg <- false ; status <- 0

    //背景設定
    g.Clear(Color.Black)

    setColor(Color.Red); fRect b.X b.Y 10 10

    match status with
    |1 -> setColor(Color.Yellow); dStr 224 100 "クリア！"
    |2 -> setColor(Color.Red); dStr 224 100 "死亡"
    |_ -> setColor(Color.Lime)
    
    fRect p.X p.Y 64 16
    Array2D.iteri( fun x y i -> if i = 1 then fRect (x*32) (y*16) 31 15 ) arr
    dRect 0 0 224 240

    dStr 224 0 "ブロック"
    dStr 260 20 "くずし"
    dStr 224 40 ( "速度" + sp.ToString() )
    dStr 224 60 ( "点数" + score.ToString() )