﻿//グラフィックス関連モジュール
module MyGraphics
open System.Windows.Forms
open System.Drawing
open MyForm

let currentContext = BufferedGraphicsManager.Current 
let myBuffer = currentContext.Allocate(form.CreateGraphics(),form.DisplayRectangle)
let g = myBuffer.Graphics
let mutable color = Color.White
let mutable fontSize = 12

let setColor c = color <- c

//文字列表示
let dStr x y str =
    g.DrawString(str.ToString(), new Font("ＭＳ ゴシック", float32(fontSize)), new SolidBrush(color), float32(x), float32(y))

//矩形表示
let dRect x y w h =
    g.DrawRectangle(new Pen(color), float32(x), float32(y), float32(w-1), float32(h-1))

//矩形表示(塗りつぶし)
let fRect x y w h =
    g.FillRectangle(new SolidBrush(color), float32(x), float32(y), float32(w), float32(h))

//正方形表示
let dBox x y size = dRect x y size size

//正方形表示(塗りつぶし)
let fBox x y size = fRect x y size size